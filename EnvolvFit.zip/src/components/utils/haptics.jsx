// Haptic feedback utilities for iOS-like experience

export const haptics = {
  // Light tap feedback
  light: () => {
    if (window.navigator.vibrate) {
      window.navigator.vibrate(5);
    }
  },

  // Medium impact feedback
  medium: () => {
    if (window.navigator.vibrate) {
      window.navigator.vibrate(10);
    }
  },

  // Heavy impact feedback
  heavy: () => {
    if (window.navigator.vibrate) {
      window.navigator.vibrate(15);
    }
  },

  // Success feedback
  success: () => {
    if (window.navigator.vibrate) {
      window.navigator.vibrate([5, 30, 5]);
    }
  },

  // Error feedback
  error: () => {
    if (window.navigator.vibrate) {
      window.navigator.vibrate([10, 50, 10]);
    }
  },

  // Selection changed feedback
  selection: () => {
    if (window.navigator.vibrate) {
      window.navigator.vibrate(3);
    }
  },
};