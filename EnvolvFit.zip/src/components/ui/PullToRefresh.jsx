import React, { useState, useRef } from 'react';
import { motion, useMotionValue, useTransform } from 'framer-motion';
import { RefreshCw } from 'lucide-react';
import { haptics } from '@/components/utils/haptics';

export default function PullToRefresh({ onRefresh, children }) {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isPulling, setIsPulling] = useState(false);
  const startY = useRef(0);
  const pullDistance = useMotionValue(0);
  const opacity = useTransform(pullDistance, [0, 80], [0, 1]);
  const rotate = useTransform(pullDistance, [0, 80], [0, 180]);
  const threshold = 80;

  const handleTouchStart = (e) => {
    if (window.scrollY === 0) {
      startY.current = e.touches[0].clientY;
      setIsPulling(true);
    }
  };

  const handleTouchMove = (e) => {
    if (!isPulling || isRefreshing) return;

    const currentY = e.touches[0].clientY;
    const distance = currentY - startY.current;

    if (distance > 0) {
      pullDistance.set(Math.min(distance, threshold + 20));
      if (distance > threshold) {
        haptics.light();
      }
    }
  };

  const handleTouchEnd = async () => {
    if (!isPulling) return;

    if (pullDistance.get() >= threshold) {
      setIsRefreshing(true);
      haptics.medium();
      
      try {
        await onRefresh();
      } finally {
        setIsRefreshing(false);
        pullDistance.set(0);
      }
    } else {
      pullDistance.set(0);
    }
    
    setIsPulling(false);
  };

  return (
    <div
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      className="relative"
    >
      {/* Pull indicator */}
      <motion.div
        style={{ opacity, height: pullDistance }}
        className="flex items-center justify-center"
      >
        <motion.div
          style={{ rotate }}
          className="text-emerald-500"
        >
          <RefreshCw 
            className={`h-6 w-6 ${isRefreshing ? 'animate-spin' : ''}`} 
          />
        </motion.div>
      </motion.div>

      {children}
    </div>
  );
}