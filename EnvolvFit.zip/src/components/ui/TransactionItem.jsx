import React from 'react';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Repeat } from 'lucide-react';
import CategoryIcon, { getCategoryLabel, getCategoryConfig } from './CategoryIcon';
import { cn } from '@/lib/utils';
import { haptics } from '@/components/utils/haptics';

export default function TransactionItem({ transaction, onClick, currency = 'BRL' }) {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: currency,
    }).format(value || 0);
  };

  const handleClick = () => {
    haptics.light();
    onClick();
  };

  const isIncome = transaction.type === 'income';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.01, y: -2 }}
      whileTap={{ scale: 0.98 }}
      onClick={handleClick}
      className="flex items-center gap-3 p-3 bg-white rounded-2xl border border-slate-100 hover:shadow-lg hover:border-slate-200 transition-all cursor-pointer group"
    >
      {/* Category Icon with Animation */}
      <motion.div
        whileHover={{ rotate: [0, -10, 10, -10, 0] }}
        transition={{ duration: 0.5 }}
      >
        <CategoryIcon category={transaction.category} size="md" />
      </motion.div>
      
      {/* Transaction Details */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-0.5">
          <p className="font-semibold text-sm text-slate-800 truncate group-hover:text-slate-900">
            {transaction.description || getCategoryLabel(transaction.category)}
          </p>
          {transaction.is_recurring && (
            <motion.div
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-0.5 bg-violet-100 rounded-md"
            >
              <Repeat className="h-2.5 w-2.5 text-violet-600" />
            </motion.div>
          )}
        </div>
        <p className="text-[11px] text-slate-500 font-medium">
          {format(new Date(transaction.date), "d 'de' MMM", { locale: ptBR })}
        </p>
      </div>

      {/* Amount */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="text-right"
      >
        <p className={cn(
          "font-bold text-base",
          isIncome ? "text-emerald-600" : "text-slate-800"
        )}>
          {isIncome ? '+' : '-'} {formatCurrency(transaction.amount)}
        </p>
      </motion.div>
    </motion.div>
  );
}