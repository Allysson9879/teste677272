import React from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle } from 'lucide-react';
import CategoryIcon, { getCategoryLabel } from './CategoryIcon';
import { cn } from '@/lib/utils';

export default function BudgetProgress({ budget, spent, currency = 'BRL' }) {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: currency,
    }).format(value || 0);
  };

  const percentage = budget.limit > 0 ? Math.min((spent / budget.limit) * 100, 100) : 0;
  const remaining = budget.limit - spent;
  const isOverBudget = spent > budget.limit;
  const isNearLimit = percentage >= (budget.alert_percentage || 80);

  return (
    <div className="p-4 bg-white rounded-2xl border border-slate-100">
      <div className="flex items-center justify-between mb-3">
        <CategoryIcon category={budget.category} size="sm" showLabel />
        
        <div className="flex items-center gap-2">
          {isNearLimit && !isOverBudget && (
            <AlertTriangle className="h-4 w-4 text-amber-500" />
          )}
          {isOverBudget && (
            <AlertTriangle className="h-4 w-4 text-red-500" />
          )}
          <span className={cn(
            "text-sm font-semibold",
            isOverBudget ? "text-red-600" : isNearLimit ? "text-amber-600" : "text-slate-600"
          )}>
            {percentage.toFixed(0)}%
          </span>
        </div>
      </div>

      <div className="h-2 bg-slate-100 rounded-full overflow-hidden mb-2">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className={cn(
            "h-full rounded-full",
            isOverBudget ? "bg-red-500" : isNearLimit ? "bg-amber-500" : "bg-emerald-500"
          )}
        />
      </div>

      <div className="flex justify-between text-xs">
        <span className="text-slate-500">
          {formatCurrency(spent)} de {formatCurrency(budget.limit)}
        </span>
        <span className={cn(
          "font-medium",
          isOverBudget ? "text-red-600" : "text-emerald-600"
        )}>
          {isOverBudget ? 'Excedido: ' : 'Restam: '}
          {formatCurrency(Math.abs(remaining))}
        </span>
      </div>
    </div>
  );
}