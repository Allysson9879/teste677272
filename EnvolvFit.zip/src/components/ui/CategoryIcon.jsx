import React from 'react';
import {
  Briefcase,
  Laptop,
  TrendingUp,
  Gift,
  Utensils,
  Car,
  Home,
  Zap,
  Heart,
  GraduationCap,
  Film,
  ShoppingBag,
  Plane,
  CreditCard,
  MoreHorizontal
} from 'lucide-react';
import { cn } from '@/lib/utils';

const categoryConfig = {
  // Income
  salary: { icon: Briefcase, color: 'bg-blue-500', label: 'Salário' },
  freelance: { icon: Laptop, color: 'bg-purple-500', label: 'Freelance' },
  investments: { icon: TrendingUp, color: 'bg-emerald-500', label: 'Investimentos' },
  other_income: { icon: Gift, color: 'bg-amber-500', label: 'Outros' },
  
  // Expenses
  food: { icon: Utensils, color: 'bg-orange-500', label: 'Alimentação' },
  transport: { icon: Car, color: 'bg-sky-500', label: 'Transporte' },
  housing: { icon: Home, color: 'bg-indigo-500', label: 'Moradia' },
  utilities: { icon: Zap, color: 'bg-yellow-500', label: 'Contas' },
  health: { icon: Heart, color: 'bg-red-500', label: 'Saúde' },
  education: { icon: GraduationCap, color: 'bg-cyan-500', label: 'Educação' },
  entertainment: { icon: Film, color: 'bg-pink-500', label: 'Lazer' },
  shopping: { icon: ShoppingBag, color: 'bg-rose-500', label: 'Compras' },
  travel: { icon: Plane, color: 'bg-teal-500', label: 'Viagens' },
  subscriptions: { icon: CreditCard, color: 'bg-violet-500', label: 'Assinaturas' },
  other_expense: { icon: MoreHorizontal, color: 'bg-slate-500', label: 'Outros' },
};

export function getCategoryConfig(category) {
  return categoryConfig[category] || categoryConfig.other_expense;
}

export function getCategoryLabel(category) {
  return getCategoryConfig(category).label;
}

export default function CategoryIcon({ category, size = 'md', showLabel = false }) {
  const config = getCategoryConfig(category);
  const Icon = config.icon;
  
  const sizeClasses = {
    sm: 'h-8 w-8',
    md: 'h-10 w-10',
    lg: 'h-12 w-12',
  };
  
  const iconSizes = {
    sm: 'h-4 w-4',
    md: 'h-5 w-5',
    lg: 'h-6 w-6',
  };

  return (
    <div className={cn("flex items-center gap-3", showLabel && "min-w-0")}>
      <div className={cn(
        "flex items-center justify-center rounded-xl text-white",
        config.color,
        sizeClasses[size]
      )}>
        <Icon className={iconSizes[size]} />
      </div>
      {showLabel && (
        <span className="text-sm font-medium text-slate-700 truncate">
          {config.label}
        </span>
      )}
    </div>
  );
}