import React from 'react';
import { motion, useSpring, useTransform } from 'framer-motion';
import { TrendingUp, TrendingDown, Eye, EyeOff, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';
import { haptics } from '@/components/utils/haptics';

export default function BalanceCard({ balance, income, expenses, currency = 'BRL' }) {
  const [showBalance, setShowBalance] = React.useState(true);

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: currency,
    }).format(value || 0);
  };

  const toggleBalance = () => {
    setShowBalance(!showBalance);
    haptics.light();
  };

  const isPositive = balance >= 0;
  const balanceGradient = isPositive 
    ? 'from-emerald-500 via-emerald-500 to-teal-600' 
    : 'from-red-500 via-red-500 to-rose-600';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ 
        duration: 0.6, 
        ease: [0.34, 1.56, 0.64, 1],
        type: "spring"
      }}
      className={cn(
        "relative overflow-hidden rounded-3xl bg-gradient-to-br p-6 text-white shadow-2xl",
        balanceGradient
      )}
    >
      {/* Animated Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute -top-20 -right-20 w-60 h-60 bg-white rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1, 1.1, 1],
            opacity: [0.2, 0.4, 0.2],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1
          }}
          className="absolute -bottom-20 -left-20 w-60 h-60 bg-white rounded-full blur-3xl"
        />
      </div>
      
      <div className="relative z-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <motion.div 
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="flex items-center gap-2"
          >
            <Sparkles className="h-4 w-4 opacity-90" />
            <span className="text-sm font-semibold opacity-90">Saldo do Mês</span>
          </motion.div>
          <motion.button
            whileHover={{ scale: 1.1, rotate: 180 }}
            whileTap={{ scale: 0.9 }}
            onClick={toggleBalance}
            className="p-2.5 hover:bg-white/20 rounded-xl transition-all backdrop-blur-sm"
          >
            {showBalance ? (
              <Eye className="h-4 w-4" />
            ) : (
              <EyeOff className="h-4 w-4" />
            )}
          </motion.button>
        </div>

        {/* Balance Amount */}
        <motion.div
          key={showBalance ? 'visible' : 'hidden'}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="mb-6"
        >
          <h2 className="text-[2.75rem] font-bold tracking-tight leading-none mb-2">
            {showBalance ? formatCurrency(balance) : 'R$ ••••••'}
          </h2>
          {showBalance && income > 0 && (
            <motion.div
              initial={{ opacity: 0, width: 0 }}
              animate={{ opacity: 1, width: '100%' }}
              transition={{ delay: 0.3, duration: 0.6 }}
              className="h-1.5 bg-white/25 rounded-full overflow-hidden"
            >
              <motion.div
                initial={{ x: '-100%' }}
                animate={{ x: 0 }}
                transition={{ delay: 0.4, duration: 0.9, ease: 'easeOut' }}
                className="h-full bg-white/70 rounded-full shadow-lg"
                style={{ width: `${Math.min((balance / income) * 100, 100)}%` }}
              />
            </motion.div>
          )}
        </motion.div>

        {/* Income & Expenses Cards */}
        <div className="grid grid-cols-2 gap-3">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            whileHover={{ scale: 1.03, y: -2 }}
            className="bg-white/15 backdrop-blur-md rounded-2xl p-4 border border-white/20 shadow-lg"
          >
            <div className="flex items-center gap-2 mb-2">
              <div className="p-1.5 bg-white/25 rounded-lg backdrop-blur-sm">
                <TrendingUp className="h-3.5 w-3.5" strokeWidth={2.5} />
              </div>
              <span className="text-xs text-white/95 font-semibold">Receitas</span>
            </div>
            <p className="text-lg font-bold">
              {showBalance ? formatCurrency(income) : '••••'}
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
            whileHover={{ scale: 1.03, y: -2 }}
            className="bg-white/15 backdrop-blur-md rounded-2xl p-4 border border-white/20 shadow-lg"
          >
            <div className="flex items-center gap-2 mb-2">
              <div className="p-1.5 bg-white/25 rounded-lg backdrop-blur-sm">
                <TrendingDown className="h-3.5 w-3.5" strokeWidth={2.5} />
              </div>
              <span className="text-xs text-white/95 font-semibold">Despesas</span>
            </div>
            <p className="text-lg font-bold">
              {showBalance ? formatCurrency(expenses) : '••••'}
            </p>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}