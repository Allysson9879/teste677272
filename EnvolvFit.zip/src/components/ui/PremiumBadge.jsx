import React from 'react';
import { Crown } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function PremiumBadge({ className }) {
  return (
    <span className={cn(
      "inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-400 to-orange-500 text-white text-[10px] font-semibold uppercase tracking-wide",
      className
    )}>
      <Crown className="h-3 w-3" />
      Premium
    </span>
  );
}