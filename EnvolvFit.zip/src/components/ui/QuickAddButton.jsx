import React from 'react';
import { motion } from 'framer-motion';
import { Plus } from 'lucide-react';
import { haptics } from '@/components/utils/haptics';

export default function QuickAddButton({ onClick }) {
  const handleClick = () => {
    haptics.medium();
    onClick();
  };

  return (
    <motion.button
      initial={{ scale: 0, opacity: 0, rotate: -180 }}
      animate={{ scale: 1, opacity: 1, rotate: 0 }}
      transition={{ 
        type: "spring",
        stiffness: 260,
        damping: 20,
        delay: 0.6
      }}
      whileHover={{ 
        scale: 1.1,
        boxShadow: "0 20px 40px rgba(16, 185, 129, 0.4)",
        rotate: 90
      }}
      whileTap={{ scale: 0.9 }}
      onClick={handleClick}
      className="fixed bottom-24 right-6 h-14 w-14 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 shadow-2xl flex items-center justify-center text-white z-40 hover:shadow-emerald-500/50 active:shadow-emerald-500/70 transition-shadow border-2 border-white/20"
    >
      <motion.div
        animate={{ 
          rotate: [0, 90, 0],
          scale: [1, 1.1, 1]
        }}
        transition={{ 
          duration: 2,
          repeat: Infinity,
          repeatDelay: 3,
          ease: "easeInOut"
        }}
      >
        <Plus className="h-6 w-6" strokeWidth={3} />
      </motion.div>

      {/* Ripple Effect */}
      <motion.div
        className="absolute inset-0 rounded-2xl bg-emerald-400"
        initial={{ scale: 1, opacity: 0.5 }}
        animate={{ scale: 1.5, opacity: 0 }}
        transition={{
          duration: 1.5,
          repeat: Infinity,
          ease: "easeOut"
        }}
      />
    </motion.button>
  );
}