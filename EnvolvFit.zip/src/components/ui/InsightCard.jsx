import React from 'react';
import { motion } from 'framer-motion';
import { Lightbulb, AlertCircle, Trophy, TrendingUp, X } from 'lucide-react';
import { cn } from '@/lib/utils';

const insightConfig = {
  tip: {
    icon: Lightbulb,
    color: 'bg-amber-50 border-amber-200',
    iconColor: 'text-amber-500',
    title: 'Dica'
  },
  alert: {
    icon: AlertCircle,
    color: 'bg-red-50 border-red-200',
    iconColor: 'text-red-500',
    title: 'Alerta'
  },
  achievement: {
    icon: Trophy,
    color: 'bg-emerald-50 border-emerald-200',
    iconColor: 'text-emerald-500',
    title: 'Conquista'
  },
  pattern: {
    icon: TrendingUp,
    color: 'bg-blue-50 border-blue-200',
    iconColor: 'text-blue-500',
    title: 'Padrão'
  }
};

export default function InsightCard({ insight, onDismiss }) {
  const config = insightConfig[insight.type] || insightConfig.tip;
  const Icon = config.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -100 }}
      className={cn(
        "relative p-4 rounded-2xl border",
        config.color
      )}
    >
      {onDismiss && (
        <button
          onClick={() => onDismiss(insight.id)}
          className="absolute top-3 right-3 p-1 rounded-full hover:bg-black/5 transition-colors"
        >
          <X className="h-4 w-4 text-slate-400" />
        </button>
      )}

      <div className="flex gap-3">
        <div className={cn(
          "flex-shrink-0 h-10 w-10 rounded-xl flex items-center justify-center bg-white shadow-sm",
          config.iconColor
        )}>
          <Icon className="h-5 w-5" />
        </div>

        <div className="flex-1 min-w-0 pr-6">
          <div className="flex items-center gap-2 mb-1">
            <span className={cn("text-xs font-medium uppercase tracking-wide", config.iconColor)}>
              {config.title}
            </span>
            {insight.priority === 'high' && (
              <span className="text-[10px] bg-red-100 text-red-600 px-1.5 py-0.5 rounded-full font-medium">
                Importante
              </span>
            )}
          </div>
          
          <h4 className="font-semibold text-slate-800 mb-1">
            {insight.title}
          </h4>
          
          <p className="text-sm text-slate-600 leading-relaxed">
            {insight.message}
          </p>

          {insight.potential_savings > 0 && (
            <div className="mt-2 inline-flex items-center gap-1 text-xs font-medium text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full">
              <TrendingUp className="h-3 w-3" />
              Economia potencial: R$ {insight.potential_savings.toFixed(2)}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}