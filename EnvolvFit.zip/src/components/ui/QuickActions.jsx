import React from 'react';
import { motion } from 'framer-motion';
import { Plus, TrendingUp, TrendingDown, Repeat } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function QuickActions({ onAddIncome, onAddExpense, onAddRecurring }) {
  const actions = [
    {
      icon: TrendingUp,
      label: 'Receita',
      color: 'from-emerald-500 to-teal-600',
      onClick: onAddIncome,
    },
    {
      icon: TrendingDown,
      label: 'Despesa',
      color: 'from-red-500 to-rose-600',
      onClick: onAddExpense,
    },
    {
      icon: Repeat,
      label: 'Recorrente',
      color: 'from-violet-500 to-purple-600',
      onClick: onAddRecurring,
    },
  ];

  return (
    <div className="grid grid-cols-3 gap-3">
      {actions.map((action, index) => {
        const Icon = action.icon;
        return (
          <motion.button
            key={action.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            whileTap={{ scale: 0.95 }}
            onClick={action.onClick}
            className={cn(
              'bg-gradient-to-br text-white p-4 rounded-2xl shadow-sm active:shadow-md transition-shadow',
              action.color
            )}
          >
            <Icon className="h-5 w-5 mx-auto mb-1" />
            <p className="text-xs font-medium">{action.label}</p>
          </motion.button>
        );
      })}
    </div>
  );
}