import React from 'react';
import { motion } from 'framer-motion';

export function BalanceCardSkeleton() {
  return (
    <div className="bg-gradient-to-br from-slate-300 to-slate-400 rounded-3xl p-6 shadow-lg animate-pulse">
      <div className="h-4 w-24 bg-white/30 rounded mb-4" />
      <div className="h-10 w-40 bg-white/40 rounded-lg mb-6" />
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white/20 rounded-2xl p-4 h-20" />
        <div className="bg-white/20 rounded-2xl p-4 h-20" />
      </div>
    </div>
  );
}

export function TransactionItemSkeleton() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="bg-white rounded-2xl p-4 border border-slate-100"
    >
      <div className="flex items-center gap-4">
        <div className="h-12 w-12 rounded-xl bg-slate-200 animate-pulse" />
        <div className="flex-1">
          <div className="h-4 w-32 bg-slate-200 rounded animate-pulse mb-2" />
          <div className="h-3 w-20 bg-slate-100 rounded animate-pulse" />
        </div>
        <div className="h-5 w-20 bg-slate-200 rounded animate-pulse" />
      </div>
    </motion.div>
  );
}

export function QuickActionSkeleton() {
  return (
    <div className="grid grid-cols-3 gap-3">
      {[1, 2, 3].map((i) => (
        <div key={i} className="bg-slate-200 rounded-2xl p-4 h-24 animate-pulse" />
      ))}
    </div>
  );
}

export function CardSkeleton() {
  return (
    <div className="bg-white rounded-2xl p-4 border border-slate-100">
      <div className="flex items-center gap-3 mb-3">
        <div className="h-10 w-10 rounded-xl bg-slate-200 animate-pulse" />
        <div className="flex-1">
          <div className="h-4 w-24 bg-slate-200 rounded animate-pulse mb-2" />
          <div className="h-3 w-16 bg-slate-100 rounded animate-pulse" />
        </div>
      </div>
      <div className="h-6 w-28 bg-slate-200 rounded animate-pulse" />
    </div>
  );
}