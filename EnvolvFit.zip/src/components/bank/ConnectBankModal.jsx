import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { X, Shield, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import SwipeableModal from '@/components/ui/SwipeableModal';

const banks = [
  { value: 'nubank', label: 'Nubank' },
  { value: 'inter', label: 'Banco Inter' },
  { value: 'itau', label: 'Itaú' },
  { value: 'bradesco', label: 'Bradesco' },
  { value: 'santander', label: 'Santander' },
  { value: 'caixa', label: 'Caixa' },
  { value: 'bb', label: 'Banco do Brasil' },
  { value: 'c6', label: 'C6 Bank' },
  { value: 'picpay', label: 'PicPay' },
  { value: 'neon', label: 'Neon' },
  { value: 'other', label: 'Outro' },
];

const accountTypes = [
  { value: 'checking', label: 'Conta Corrente' },
  { value: 'savings', label: 'Poupança' },
  { value: 'credit', label: 'Cartão de Crédito' },
];

const syncFrequencies = [
  { value: 'manual', label: 'Manual' },
  { value: 'daily', label: 'Diária' },
  { value: 'weekly', label: 'Semanal' },
];

export default function ConnectBankModal({ onClose, bankAccounts }) {
  const queryClient = useQueryClient();
  const [bank, setBank] = useState('');
  const [accountType, setAccountType] = useState('');
  const [syncFrequency, setSyncFrequency] = useState('daily');
  const [autoImport, setAutoImport] = useState(true);
  const [linkedAccountId, setLinkedAccountId] = useState('');
  const [isConnecting, setIsConnecting] = useState(false);

  const connectMutation = useMutation({
    mutationFn: async (connectionData) => {
      // First, initiate the Open Finance connection
      const response = await base44.functions.invoke('connectBank', {
        bank: connectionData.bank,
        accountType: connectionData.accountType,
      });
      
      return response.data;
    },
    onSuccess: async (data) => {
      // If OAuth URL is returned, redirect to it
      if (data.authUrl) {
        window.location.href = data.authUrl;
      } else {
        // Otherwise, create the connection record
        await base44.entities.BankConnection.create({
          bank,
          account_type: accountType,
          account_name: `${banks.find(b => b.value === bank)?.label} - ${accountTypes.find(a => a.value === accountType)?.label}`,
          sync_frequency: syncFrequency,
          auto_import: autoImport,
          linked_bank_account_id: linkedAccountId || null,
          consent_id: data.consentId,
        });
        
        queryClient.invalidateQueries({ queryKey: ['bank-connections'] });
        onClose();
      }
    },
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsConnecting(true);
    
    try {
      await connectMutation.mutateAsync({
        bank,
        accountType,
        syncFrequency,
        autoImport,
        linkedAccountId,
      });
    } catch (error) {
      console.error('Error connecting bank:', error);
      setIsConnecting(false);
    }
  };

  return (
    <SwipeableModal
      isOpen={true}
      onClose={onClose}
      title="Conectar Conta Bancária"
    >
      <div className="p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Info Banner */}
          <div className="bg-blue-50 border border-blue-200 p-4 rounded-xl">
            <div className="flex items-start gap-3">
              <Shield className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-medium text-blue-900 mb-1">Conexão Segura</h4>
                <p className="text-xs text-blue-700">
                  Você será redirecionado ao seu banco para autorizar o acesso via Open Finance.
                  Seus dados de login não são compartilhados conosco.
                </p>
              </div>
            </div>
          </div>

          {/* Bank Selection */}
          <div className="space-y-2">
            <Label>Banco *</Label>
            <Select value={bank} onValueChange={setBank} required>
              <SelectTrigger className="h-12 rounded-xl">
                <SelectValue placeholder="Selecione o banco" />
              </SelectTrigger>
              <SelectContent>
                {banks.map((b) => (
                  <SelectItem key={b.value} value={b.value}>
                    {b.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Account Type */}
          <div className="space-y-2">
            <Label>Tipo de Conta *</Label>
            <Select value={accountType} onValueChange={setAccountType} required>
              <SelectTrigger className="h-12 rounded-xl">
                <SelectValue placeholder="Selecione o tipo" />
              </SelectTrigger>
              <SelectContent>
                {accountTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Link to existing account */}
          {bankAccounts.length > 0 && (
            <div className="space-y-2">
              <Label>Vincular à Conta Existente (opcional)</Label>
              <Select value={linkedAccountId} onValueChange={setLinkedAccountId}>
                <SelectTrigger className="h-12 rounded-xl">
                  <SelectValue placeholder="Nenhuma" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>Nenhuma</SelectItem>
                  {bankAccounts.map((account) => (
                    <SelectItem key={account.id} value={account.id}>
                      {account.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Sync Frequency */}
          <div className="space-y-2">
            <Label>Frequência de Sincronização</Label>
            <Select value={syncFrequency} onValueChange={setSyncFrequency}>
              <SelectTrigger className="h-12 rounded-xl">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {syncFrequencies.map((freq) => (
                  <SelectItem key={freq.value} value={freq.value}>
                    {freq.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Auto Import Toggle */}
          <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
            <div>
              <p className="font-medium text-slate-800">Importação Automática</p>
              <p className="text-xs text-slate-500">
                Criar transações automaticamente ao sincronizar
              </p>
            </div>
            <Switch checked={autoImport} onCheckedChange={setAutoImport} />
          </div>

          {/* Warning */}
          <div className="bg-amber-50 border border-amber-200 p-3 rounded-xl">
            <div className="flex items-start gap-2">
              <AlertCircle className="h-4 w-4 text-amber-600 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-amber-700">
                O consentimento expira após 12 meses. Você precisará renovar a conexão.
              </p>
            </div>
          </div>

          {/* Submit Button */}
          <Button
            type="submit"
            disabled={!bank || !accountType || isConnecting}
            className="w-full h-12 bg-emerald-500 hover:bg-emerald-600"
          >
            {isConnecting ? 'Conectando...' : 'Conectar com Banco'}
          </Button>
        </form>
      </div>
    </SwipeableModal>
  );
}