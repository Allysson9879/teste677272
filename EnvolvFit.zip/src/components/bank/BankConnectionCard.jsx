import React from 'react';
import { motion } from 'framer-motion';
import { RefreshCw, Trash2, AlertCircle, CheckCircle2, Clock } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';

const bankLogos = {
  nubank: 'https://logodownload.org/wp-content/uploads/2019/08/nubank-logo.png',
  inter: 'https://upload.wikimedia.org/wikipedia/commons/7/7c/Banco_Inter_logo.svg',
};

const bankColors = {
  nubank: 'from-purple-600 to-purple-700',
  inter: 'from-orange-500 to-orange-600',
  other: 'from-slate-600 to-slate-700',
};

const accountTypeLabels = {
  checking: 'Conta Corrente',
  savings: 'Poupança',
  credit: 'Cartão de Crédito',
};

const syncFrequencyLabels = {
  manual: 'Manual',
  daily: 'Diária',
  weekly: 'Semanal',
};

export default function BankConnectionCard({ 
  connection, 
  onToggle, 
  onSync, 
  onDelete,
  isSyncing 
}) {
  const isExpiringSoon = connection.consent_expires_at && 
    new Date(connection.consent_expires_at) < new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "bg-white rounded-2xl border overflow-hidden",
        connection.is_active ? "border-slate-200" : "border-slate-100 opacity-60"
      )}
    >
      {/* Header with Bank Info */}
      <div className={cn(
        "bg-gradient-to-r p-4 text-white",
        bankColors[connection.bank] || bankColors.other
      )}>
        <div className="flex items-start justify-between mb-2">
          <div className="flex items-center gap-3">
            {bankLogos[connection.bank] && (
              <div className="h-10 w-10 rounded-lg bg-white flex items-center justify-center">
                <img 
                  src={bankLogos[connection.bank]} 
                  alt={connection.bank}
                  className="h-6 w-6 object-contain"
                />
              </div>
            )}
            <div>
              <h3 className="font-semibold">{connection.account_name}</h3>
              <p className="text-xs opacity-80">
                {accountTypeLabels[connection.account_type]}
              </p>
            </div>
          </div>
          <Switch
            checked={connection.is_active}
            onCheckedChange={onToggle}
            className="data-[state=checked]:bg-white/30"
          />
        </div>

        {connection.last_sync && (
          <div className="flex items-center gap-2 text-xs opacity-90">
            <Clock className="h-3 w-3" />
            Última sync: {formatDistanceToNow(new Date(connection.last_sync), {
              addSuffix: true,
              locale: ptBR,
            })}
          </div>
        )}
      </div>

      {/* Body with Details */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div>
            <p className="text-xs text-slate-500">Sincronização</p>
            <p className="text-sm font-medium text-slate-800">
              {syncFrequencyLabels[connection.sync_frequency]}
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500">Importação Auto</p>
            <p className="text-sm font-medium text-slate-800">
              {connection.auto_import ? 'Ativa' : 'Desativada'}
            </p>
          </div>
        </div>

        {/* Warnings */}
        {isExpiringSoon && (
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 mb-3">
            <div className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-amber-600" />
              <p className="text-xs text-amber-700">
                Consentimento expira em breve. Reconecte a conta.
              </p>
            </div>
          </div>
        )}

        {connection.is_active && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 mb-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
              <p className="text-xs text-emerald-700">
                Conexão ativa e funcionando
              </p>
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-2">
          {onSync && connection.is_active && (
            <Button
              size="sm"
              variant="outline"
              onClick={onSync}
              disabled={isSyncing}
              className="flex-1"
            >
              <RefreshCw className={cn("h-4 w-4 mr-2", isSyncing && "animate-spin")} />
              Sincronizar
            </Button>
          )}
          <Button
            size="sm"
            variant="outline"
            onClick={onDelete}
            className="text-red-600 border-red-200 hover:bg-red-50"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}