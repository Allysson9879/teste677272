import React, { createContext, useContext, useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import LoadingScreen from '@/components/ui/LoadingScreen';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const authData = localStorage.getItem('customAuth');
      if (authData) {
        const { userId } = JSON.parse(authData);
        const users = await base44.entities.AuthUser.filter({ id: userId });
        if (users.length > 0) {
          setUser(users[0]);
        } else {
          localStorage.removeItem('customAuth');
        }
      }
    } catch (error) {
      console.error('Auth check failed:', error);
      localStorage.removeItem('customAuth');
    } finally {
      setLoading(false);
    }
  };

  const login = async (email, password) => {
    const users = await base44.entities.AuthUser.filter({ email, password });
    
    if (users.length === 0) {
      throw new Error('Email ou senha incorretos');
    }

    const user = users[0];
    if (!user.is_active) {
      throw new Error('Usuário inativo');
    }

    localStorage.setItem('customAuth', JSON.stringify({ userId: user.id }));
    setUser(user);
    return user;
  };

  const register = async (data) => {
    const existingUsers = await base44.entities.AuthUser.filter({ email: data.email });
    
    if (existingUsers.length > 0) {
      throw new Error('Email já cadastrado');
    }

    const newUser = await base44.entities.AuthUser.create(data);
    localStorage.setItem('customAuth', JSON.stringify({ userId: newUser.id }));
    setUser(newUser);
    return newUser;
  };

  const logout = () => {
    localStorage.removeItem('customAuth');
    setUser(null);
  };

  const updateUser = async (updates) => {
    const updated = await base44.entities.AuthUser.update(user.id, updates);
    setUser(updated);
    return updated;
  };

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}