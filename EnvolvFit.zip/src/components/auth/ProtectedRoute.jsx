import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from './AuthProvider';
import { createPageUrl } from '@/utils';
import LoadingScreen from '@/components/ui/LoadingScreen';

export default function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();

  if (loading) {
    return <LoadingScreen />;
  }

  if (!user) {
    return <Navigate to={createPageUrl('Login')} replace />;
  }

  return children;
}