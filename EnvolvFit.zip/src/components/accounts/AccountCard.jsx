import React from 'react';
import { motion } from 'framer-motion';
import { Building2, Wallet, TrendingUp, Eye, EyeOff } from 'lucide-react';
import { cn } from '@/lib/utils';

const bankColors = {
  nubank: 'from-purple-600 to-purple-700',
  inter: 'from-orange-500 to-orange-600',
  itau: 'from-blue-600 to-blue-700',
  bradesco: 'from-red-600 to-red-700',
  santander: 'from-red-500 to-red-600',
  caixa: 'from-blue-500 to-blue-600',
  bb: 'from-yellow-500 to-yellow-600',
  c6: 'from-slate-700 to-slate-800',
  picpay: 'from-green-500 to-green-600',
  neon: 'from-blue-400 to-blue-500',
  other: 'from-slate-600 to-slate-700',
};

const bankLogos = {
  nubank: 'https://logodownload.org/wp-content/uploads/2020/02/nubank-logo-3.png',
  inter: 'https://logodownload.org/wp-content/uploads/2020/02/inter-logo-1.png',
};

const accountTypeIcons = {
  checking: Wallet,
  savings: Building2,
  investment: TrendingUp,
};

const accountTypeLabels = {
  checking: 'Conta Corrente',
  savings: 'Poupança',
  investment: 'Investimento',
};

export default function AccountCard({ account, balance, onClick, isSmall }) {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value || 0);
  };

  const gradient = bankColors[account.bank] || bankColors.other;
  const logo = bankLogos[account.bank];
  const Icon = accountTypeIcons[account.account_type] || Wallet;

  if (isSmall) {
    return (
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={onClick}
        className={cn(
          "w-20 h-20 rounded-2xl bg-gradient-to-br shadow-lg flex items-center justify-center",
          gradient
        )}
      >
        <Icon className="h-8 w-8 text-white" />
      </motion.button>
    );
  }

  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={cn(
        "w-full h-44 rounded-3xl bg-gradient-to-br shadow-xl p-6 flex flex-col justify-between text-left relative overflow-hidden",
        gradient
      )}
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white rounded-full -translate-y-32 translate-x-32" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-white rounded-full translate-y-24 -translate-x-24" />
      </div>

      {/* Content */}
      <div className="relative z-10">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-2">
            {logo ? (
              <img src={logo} alt={account.bank} className="h-6 w-6 object-contain bg-white rounded p-0.5" />
            ) : (
              <Icon className="h-6 w-6 text-white" />
            )}
            <span className="text-white/90 text-sm font-medium">
              {accountTypeLabels[account.account_type]}
            </span>
          </div>
          {!account.is_active && (
            <EyeOff className="h-5 w-5 text-white/70" />
          )}
        </div>

        <div>
          <p className="text-white/80 text-sm mb-1">{account.name}</p>
          <p className="text-white text-2xl font-bold">
            {formatCurrency(balance)}
          </p>
        </div>
      </div>
    </motion.button>
  );
}