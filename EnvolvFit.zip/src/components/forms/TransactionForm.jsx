import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, TrendingUp, TrendingDown, Calendar, FileText, Repeat } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { getCategoryConfig } from '@/components/ui/CategoryIcon';
import SwipeableModal from '@/components/ui/SwipeableModal';
import { haptics } from '@/components/utils/haptics';

const incomeCategories = ['salary', 'freelance', 'investments', 'other_income'];
const expenseCategories = ['food', 'transport', 'housing', 'utilities', 'health', 'education', 'entertainment', 'shopping', 'travel', 'subscriptions', 'other_expense'];

export default function TransactionForm({ onSubmit, onClose, initialData }) {
  const [type, setType] = useState(initialData?.type || initialData?.type || 'expense');
  const [amount, setAmount] = useState(initialData?.amount?.toString() || '');
  const [category, setCategory] = useState(initialData?.category || '');
  const [description, setDescription] = useState(initialData?.description || '');
  const [date, setDate] = useState(initialData?.date || new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState(initialData?.notes || '');
  const [isRecurring, setIsRecurring] = useState(initialData?.is_recurring || false);
  const [recurringDay, setRecurringDay] = useState(initialData?.recurring_day || new Date().getDate());
  const [cardId, setCardId] = useState(initialData?.card_id || '');
  const [bankAccountId, setBankAccountId] = useState(initialData?.bank_account_id || '');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data: cards = [] } = useQuery({
    queryKey: ['cards'],
    queryFn: () => base44.entities.Card.filter({ is_active: true }, '-created_date', 50),
  });

  const { data: bankAccounts = [] } = useQuery({
    queryKey: ['bankAccounts'],
    queryFn: () => base44.entities.BankAccount.filter({ is_active: true }, '-created_date', 50),
  });

  const categories = type === 'income' ? incomeCategories : expenseCategories;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    haptics.medium();
    
    try {
      await onSubmit({
        type,
        amount: parseFloat(amount),
        category,
        description,
        date,
        notes,
        is_recurring: isRecurring,
        recurring_day: isRecurring ? recurringDay : null,
        card_id: cardId || null,
        bank_account_id: bankAccountId || null,
      });
      haptics.success();
    } catch (error) {
      haptics.error();
      setIsSubmitting(false);
    }
  };

  return (
    <SwipeableModal
      isOpen={true}
      onClose={onClose}
      title={initialData ? 'Editar Transação' : 'Nova Transação'}
    >
      <div className="p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Type Toggle */}
          <div className="flex gap-3">
            <button
              type="button"
              onClick={() => { setType('income'); setCategory(''); }}
              className={cn(
                "flex-1 flex items-center justify-center gap-2 p-4 rounded-2xl border-2 transition-all font-medium",
                type === 'income'
                  ? "border-emerald-500 bg-emerald-50 text-emerald-700"
                  : "border-slate-200 text-slate-500 hover:border-slate-300"
              )}
            >
              <TrendingUp className="h-5 w-5" />
              Receita
            </button>
            <button
              type="button"
              onClick={() => { setType('expense'); setCategory(''); }}
              className={cn(
                "flex-1 flex items-center justify-center gap-2 p-4 rounded-2xl border-2 transition-all font-medium",
                type === 'expense'
                  ? "border-red-500 bg-red-50 text-red-700"
                  : "border-slate-200 text-slate-500 hover:border-slate-300"
              )}
            >
              <TrendingDown className="h-5 w-5" />
              Despesa
            </button>
          </div>

          {/* Amount */}
          <div className="space-y-2">
            <Label htmlFor="amount" className="text-slate-700">Valor</Label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-medium">
                R$
              </span>
              <Input
                id="amount"
                type="number"
                step="0.01"
                min="0"
                placeholder="0,00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="pl-12 h-14 text-2xl font-bold rounded-2xl border-slate-200"
                required
              />
            </div>
          </div>

          {/* Category */}
          <div className="space-y-2">
            <Label className="text-slate-700">Categoria</Label>
            <Select value={category} onValueChange={setCategory} required>
              <SelectTrigger className="h-14 rounded-2xl border-slate-200">
                <SelectValue placeholder="Selecione uma categoria" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => {
                  const config = getCategoryConfig(cat);
                  return (
                    <SelectItem key={cat} value={cat}>
                      <div className="flex items-center gap-2">
                        <div className={cn("h-6 w-6 rounded-lg flex items-center justify-center text-white", config.color)}>
                          <config.icon className="h-3 w-3" />
                        </div>
                        {config.label}
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description" className="text-slate-700">
              <FileText className="h-4 w-4 inline mr-2" />
              Descrição (opcional)
            </Label>
            <Input
              id="description"
              placeholder="Ex: Supermercado, Uber, Netflix..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="h-12 rounded-2xl border-slate-200"
            />
          </div>

          {/* Date */}
          <div className="space-y-2">
            <Label htmlFor="date" className="text-slate-700">
              <Calendar className="h-4 w-4 inline mr-2" />
              Data
            </Label>
            <Input
              id="date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="h-12 rounded-2xl border-slate-200"
              required
            />
          </div>

          {/* Recurring */}
          <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
            <div className="flex items-center gap-3">
              <Repeat className="h-5 w-5 text-slate-500" />
              <div>
                <p className="font-medium text-slate-700">Transação recorrente</p>
                <p className="text-xs text-slate-500">Repete todo mês</p>
              </div>
            </div>
            <Switch
              checked={isRecurring}
              onCheckedChange={setIsRecurring}
            />
          </div>

          {isRecurring && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="space-y-2"
            >
              <Label htmlFor="recurringDay" className="text-slate-700">Dia do mês</Label>
              <Select value={recurringDay.toString()} onValueChange={(v) => setRecurringDay(parseInt(v))}>
                <SelectTrigger className="h-12 rounded-2xl border-slate-200">
                  <SelectValue placeholder="Selecione o dia" />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 31 }, (_, i) => i + 1).map((day) => (
                    <SelectItem key={day} value={day.toString()}>
                      Dia {day}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </motion.div>
          )}

          {/* Bank Account Selection */}
          {bankAccounts.length > 0 && (
            <div className="space-y-2">
              <Label className="text-slate-700">Conta Bancária (opcional)</Label>
              <Select value={bankAccountId || 'none'} onValueChange={(v) => setBankAccountId(v === 'none' ? '' : v)}>
                <SelectTrigger className="h-12 rounded-2xl border-slate-200">
                  <SelectValue placeholder="Selecione a conta" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Nenhuma</SelectItem>
                  {bankAccounts.map(account => (
                    <SelectItem key={account.id} value={account.id}>
                      {account.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Card Selection */}
          {type === 'expense' && cards.length > 0 && (
            <div className="space-y-2">
              <Label className="text-slate-700">Cartão (opcional)</Label>
              <Select value={cardId || 'none'} onValueChange={(v) => setCardId(v === 'none' ? '' : v)}>
                <SelectTrigger className="h-12 rounded-2xl border-slate-200">
                  <SelectValue placeholder="Selecione um cartão" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Nenhum</SelectItem>
                  {cards.map(card => (
                    <SelectItem key={card.id} value={card.id}>
                      {card.nickname} {card.last_digits ? `(••${card.last_digits})` : ''}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes" className="text-slate-700">Observações (opcional)</Label>
            <Textarea
              id="notes"
              placeholder="Anotações adicionais..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="rounded-2xl border-slate-200 min-h-[80px]"
            />
          </div>

          {/* Submit */}
          <Button
            type="submit"
            disabled={isSubmitting || !amount || !category}
            className={cn(
              "w-full h-14 rounded-2xl text-lg font-semibold transition-all",
              type === 'income'
                ? "bg-emerald-500 hover:bg-emerald-600"
                : "bg-slate-800 hover:bg-slate-900"
            )}
          >
            {isSubmitting ? 'Salvando...' : (initialData ? 'Atualizar' : 'Adicionar')}
          </Button>
        </form>
      </div>
    </SwipeableModal>
  );
}