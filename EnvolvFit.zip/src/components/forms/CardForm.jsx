import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import CardVisual from '@/components/cards/CardVisual';

const banks = [
  { value: 'nubank', label: 'Nubank' },
  { value: 'inter', label: 'Inter' },
  { value: 'itau', label: 'Itaú' },
  { value: 'bradesco', label: 'Bradesco' },
  { value: 'santander', label: 'Santander' },
  { value: 'caixa', label: 'Caixa' },
  { value: 'bb', label: 'Banco do Brasil' },
  { value: 'c6', label: 'C6 Bank' },
  { value: 'picpay', label: 'PicPay' },
  { value: 'neon', label: 'Neon' },
  { value: 'other', label: 'Outro' },
];

export default function CardForm({ card, onSubmit, onClose }) {
  const [formData, setFormData] = useState(card || {
    bank_account_id: '',
    bank: 'nubank',
    nickname: '',
    last_digits: '',
    card_type: 'credit',
    limit: '',
    closing_day: '',
    due_day: '',
    is_active: true,
  });

  const { data: bankAccounts = [] } = useQuery({
    queryKey: ['bankAccounts'],
    queryFn: () => base44.entities.BankAccount.filter({ is_active: true }, '-created_date', 50),
  });

  const handleAccountChange = (accountId) => {
    const selectedAccount = bankAccounts.find(acc => acc.id === accountId);
    if (selectedAccount) {
      setFormData({ 
        ...formData, 
        bank_account_id: accountId,
        bank: selectedAccount.bank 
      });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 100 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 100 }}
        className="bg-white rounded-t-3xl sm:rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto"
      >
        <div className="sticky top-0 bg-white border-b border-slate-100 px-6 py-4 flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-800">
            {card ? 'Editar Cartão' : 'Novo Cartão'}
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
            <X className="h-5 w-5 text-slate-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Card Preview */}
          <div className="flex justify-center">
            <CardVisual card={formData} />
          </div>

          {/* Form Fields */}
          <div className="space-y-4">
            <div>
              <Label>Conta Bancária *</Label>
              <Select 
                value={formData.bank_account_id} 
                onValueChange={handleAccountChange}
                required
              >
                <SelectTrigger className="rounded-xl">
                  <SelectValue placeholder="Selecione a conta" />
                </SelectTrigger>
                <SelectContent>
                  {bankAccounts.length === 0 ? (
                    <SelectItem value="none" disabled>Nenhuma conta cadastrada</SelectItem>
                  ) : (
                    bankAccounts.map(account => (
                      <SelectItem key={account.id} value={account.id}>
                        {account.name} - {account.bank}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
              {bankAccounts.length === 0 && (
                <p className="text-xs text-amber-600 mt-1">
                  ⚠️ Cadastre uma conta bancária primeiro
                </p>
              )}
            </div>

            <div>
              <Label>Banco</Label>
              <Select value={formData.bank} onValueChange={(value) => setFormData({ ...formData, bank: value })} disabled>
                <SelectTrigger className="rounded-xl bg-slate-50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {banks.map(bank => (
                    <SelectItem key={bank.value} value={bank.value}>{bank.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-slate-500 mt-1">
                O banco é definido automaticamente pela conta selecionada
              </p>
            </div>

            <div>
              <Label>Apelido do Cartão *</Label>
              <Input
                placeholder="Ex: Cartão Principal, Reserva..."
                value={formData.nickname}
                onChange={(e) => setFormData({ ...formData, nickname: e.target.value })}
                className="rounded-xl"
                required
              />
            </div>

            <div>
              <Label>Últimos 4 Dígitos</Label>
              <Input
                placeholder="0000"
                maxLength={4}
                value={formData.last_digits}
                onChange={(e) => setFormData({ ...formData, last_digits: e.target.value.replace(/\D/g, '') })}
                className="rounded-xl"
              />
            </div>

            <div>
              <Label>Tipo</Label>
              <Select value={formData.card_type} onValueChange={(value) => setFormData({ ...formData, card_type: value })}>
                <SelectTrigger className="rounded-xl">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="credit">Crédito</SelectItem>
                  <SelectItem value="debit">Débito</SelectItem>
                  <SelectItem value="both">Crédito e Débito</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {(formData.card_type === 'credit' || formData.card_type === 'both') && (
              <>
                <div>
                  <Label>Limite de Crédito</Label>
                  <Input
                    type="number"
                    placeholder="0.00"
                    step="0.01"
                    value={formData.limit}
                    onChange={(e) => setFormData({ ...formData, limit: e.target.value })}
                    className="rounded-xl"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Dia Fechamento</Label>
                    <Input
                      type="number"
                      min="1"
                      max="31"
                      placeholder="10"
                      value={formData.closing_day}
                      onChange={(e) => setFormData({ ...formData, closing_day: e.target.value })}
                      className="rounded-xl"
                    />
                  </div>
                  <div>
                    <Label>Dia Vencimento</Label>
                    <Input
                      type="number"
                      min="1"
                      max="31"
                      placeholder="17"
                      value={formData.due_day}
                      onChange={(e) => setFormData({ ...formData, due_day: e.target.value })}
                      className="rounded-xl"
                    />
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1 rounded-xl">
              Cancelar
            </Button>
            <Button 
              type="submit" 
              className="flex-1 rounded-xl bg-emerald-500 hover:bg-emerald-600"
              disabled={!formData.nickname || !formData.bank_account_id || bankAccounts.length === 0}
            >
              {card ? 'Atualizar' : 'Adicionar'}
            </Button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}