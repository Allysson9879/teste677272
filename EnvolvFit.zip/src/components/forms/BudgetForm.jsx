import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Wallet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { getCategoryConfig } from '@/components/ui/CategoryIcon';

const expenseCategories = ['food', 'transport', 'housing', 'utilities', 'health', 'education', 'entertainment', 'shopping', 'travel', 'subscriptions', 'other_expense'];

export default function BudgetForm({ onSubmit, onClose, initialData, existingCategories = [] }) {
  const [category, setCategory] = useState(initialData?.category || '');
  const [limit, setLimit] = useState(initialData?.limit?.toString() || '');
  const [alertPercentage, setAlertPercentage] = useState(initialData?.alert_percentage || 80);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const availableCategories = expenseCategories.filter(
    cat => !existingCategories.includes(cat) || cat === initialData?.category
  );

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    const currentMonth = new Date().toISOString().slice(0, 7);
    
    await onSubmit({
      category,
      limit: parseFloat(limit),
      alert_percentage: alertPercentage,
      month: currentMonth,
    });
    
    setIsSubmitting(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-end sm:items-center justify-center"
      onClick={onClose}
    >
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg bg-white rounded-t-3xl sm:rounded-3xl"
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-violet-100 flex items-center justify-center">
              <Wallet className="h-5 w-5 text-violet-600" />
            </div>
            <h2 className="text-xl font-bold text-slate-800">
              {initialData ? 'Editar Orçamento' : 'Novo Orçamento'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-slate-100 transition-colors"
          >
            <X className="h-5 w-5 text-slate-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Category */}
          <div className="space-y-2">
            <Label className="text-slate-700">Categoria</Label>
            <Select value={category} onValueChange={setCategory} required>
              <SelectTrigger className="h-14 rounded-2xl border-slate-200">
                <SelectValue placeholder="Selecione uma categoria" />
              </SelectTrigger>
              <SelectContent>
                {availableCategories.map((cat) => {
                  const config = getCategoryConfig(cat);
                  return (
                    <SelectItem key={cat} value={cat}>
                      <div className="flex items-center gap-2">
                        <div className={cn("h-6 w-6 rounded-lg flex items-center justify-center text-white", config.color)}>
                          <config.icon className="h-3 w-3" />
                        </div>
                        {config.label}
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>

          {/* Limit */}
          <div className="space-y-2">
            <Label htmlFor="limit" className="text-slate-700">Limite Mensal</Label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-medium">
                R$
              </span>
              <Input
                id="limit"
                type="number"
                step="0.01"
                min="0"
                placeholder="0,00"
                value={limit}
                onChange={(e) => setLimit(e.target.value)}
                className="pl-12 h-14 text-2xl font-bold rounded-2xl border-slate-200"
                required
              />
            </div>
          </div>

          {/* Alert Percentage */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label className="text-slate-700">Alerta quando atingir</Label>
              <span className="text-lg font-bold text-violet-600">{alertPercentage}%</span>
            </div>
            <Slider
              value={[alertPercentage]}
              onValueChange={([value]) => setAlertPercentage(value)}
              min={50}
              max={100}
              step={5}
              className="w-full"
            />
            <p className="text-xs text-slate-500">
              Você receberá um alerta quando gastar {alertPercentage}% do limite definido.
            </p>
          </div>

          {/* Submit */}
          <Button
            type="submit"
            disabled={isSubmitting || !limit || !category}
            className="w-full h-14 rounded-2xl text-lg font-semibold bg-violet-600 hover:bg-violet-700"
          >
            {isSubmitting ? 'Salvando...' : (initialData ? 'Atualizar' : 'Criar Orçamento')}
          </Button>
        </form>
      </motion.div>
    </motion.div>
  );
}