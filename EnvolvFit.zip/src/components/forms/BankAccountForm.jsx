import React, { useState } from 'react';
import { X, Building2, Wallet, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';
import SwipeableModal from '@/components/ui/SwipeableModal';
import { haptics } from '@/components/utils/haptics';

const banks = [
  { value: 'nubank', label: 'Nubank' },
  { value: 'inter', label: 'Inter' },
  { value: 'itau', label: 'Itaú' },
  { value: 'bradesco', label: 'Bradesco' },
  { value: 'santander', label: 'Santander' },
  { value: 'caixa', label: 'Caixa' },
  { value: 'bb', label: 'Banco do Brasil' },
  { value: 'c6', label: 'C6 Bank' },
  { value: 'picpay', label: 'PicPay' },
  { value: 'neon', label: 'Neon' },
  { value: 'other', label: 'Outro' },
];

const accountTypes = [
  { value: 'checking', label: 'Conta Corrente', icon: Wallet },
  { value: 'savings', label: 'Poupança', icon: Building2 },
  { value: 'investment', label: 'Investimento', icon: TrendingUp },
];

export default function BankAccountForm({ account, onSubmit, onClose }) {
  const [name, setName] = useState(account?.name || '');
  const [bank, setBank] = useState(account?.bank || '');
  const [accountType, setAccountType] = useState(account?.account_type || 'checking');
  const [initialBalance, setInitialBalance] = useState(account?.initial_balance?.toString() || '0');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    haptics.medium();

    try {
      await onSubmit({
        name,
        bank,
        account_type: accountType,
        initial_balance: parseFloat(initialBalance),
      });
      haptics.success();
    } catch (error) {
      haptics.error();
      setIsSubmitting(false);
    }
  };

  return (
    <SwipeableModal
      isOpen={true}
      onClose={onClose}
      title={account ? 'Editar Conta' : 'Nova Conta Bancária'}
    >
      <div className="p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Nome */}
          <div className="space-y-2">
            <Label htmlFor="name">Nome da Conta</Label>
            <Input
              id="name"
              placeholder="Ex: Conta Principal, Reserva..."
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="h-12 rounded-2xl border-slate-200"
              required
            />
          </div>

          {/* Banco */}
          <div className="space-y-2">
            <Label>Banco</Label>
            <Select value={bank} onValueChange={setBank} required>
              <SelectTrigger className="h-12 rounded-2xl border-slate-200">
                <SelectValue placeholder="Selecione o banco" />
              </SelectTrigger>
              <SelectContent>
                {banks.map((b) => (
                  <SelectItem key={b.value} value={b.value}>
                    {b.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Tipo de Conta */}
          <div className="space-y-2">
            <Label>Tipo de Conta</Label>
            <div className="grid grid-cols-3 gap-2">
              {accountTypes.map((type) => {
                const Icon = type.icon;
                return (
                  <button
                    key={type.value}
                    type="button"
                    onClick={() => {
                      haptics.selection();
                      setAccountType(type.value);
                    }}
                    className={cn(
                      "flex flex-col items-center gap-2 p-3 rounded-xl border-2 transition-all",
                      accountType === type.value
                        ? "border-emerald-500 bg-emerald-50"
                        : "border-slate-200 hover:border-slate-300"
                    )}
                  >
                    <Icon className={cn(
                      "h-5 w-5",
                      accountType === type.value ? "text-emerald-600" : "text-slate-400"
                    )} />
                    <span className={cn(
                      "text-xs font-medium",
                      accountType === type.value ? "text-emerald-700" : "text-slate-600"
                    )}>
                      {type.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Saldo Inicial */}
          <div className="space-y-2">
            <Label htmlFor="balance">Saldo Inicial</Label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-medium">
                R$
              </span>
              <Input
                id="balance"
                type="number"
                step="0.01"
                placeholder="0,00"
                value={initialBalance}
                onChange={(e) => setInitialBalance(e.target.value)}
                className="pl-12 h-14 text-xl font-bold rounded-2xl border-slate-200"
                required
              />
            </div>
            <p className="text-xs text-slate-500">
              Informe o saldo atual da conta para começar o controle
            </p>
          </div>

          {/* Submit */}
          <Button
            type="submit"
            disabled={isSubmitting || !name || !bank}
            className="w-full h-14 rounded-2xl text-lg font-semibold bg-emerald-500 hover:bg-emerald-600"
          >
            {isSubmitting ? 'Salvando...' : (account ? 'Atualizar' : 'Adicionar Conta')}
          </Button>
        </form>
      </div>
    </SwipeableModal>
  );
}