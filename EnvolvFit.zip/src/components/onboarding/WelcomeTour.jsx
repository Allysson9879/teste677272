import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ArrowRight, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import confetti from 'canvas-confetti';

const tourSteps = [
  {
    title: 'Bem-vindo! 👋',
    description: 'Vamos fazer um tour rápido para você conhecer as principais funcionalidades do app',
    image: '💰',
  },
  {
    title: 'Visualize Seu Saldo',
    description: 'Aqui você acompanha seu saldo mensal: receitas, despesas e quanto você economizou',
    image: '📊',
    highlight: 'balance',
  },
  {
    title: 'Ações Rápidas',
    description: 'Use os botões para adicionar receitas e despesas de forma rápida e prática',
    image: '⚡',
    highlight: 'quick-actions',
  },
  {
    title: 'Insights com IA',
    description: 'Receba análises inteligentes sobre seus hábitos financeiros e dicas personalizadas',
    image: '✨',
    highlight: 'insights',
  },
  {
    title: 'Controle de Orçamentos',
    description: 'Defina limites por categoria e acompanhe seus gastos para não estourar o orçamento',
    image: '🎯',
    highlight: 'budgets',
  },
  {
    title: 'Pronto para Começar! 🚀',
    description: 'Agora você está pronto para tomar controle total das suas finanças!',
    image: '🎉',
  },
];

export default function WelcomeTour({ onComplete }) {
  const [currentStep, setCurrentStep] = useState(0);

  const handleNext = () => {
    if (currentStep < tourSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
      setTimeout(() => onComplete(), 300);
    }
  };

  const handleSkip = () => {
    onComplete();
  };

  const step = tourSteps[currentStep];
  const isLastStep = currentStep === tourSteps.length - 1;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-end sm:items-center justify-center p-4"
      onClick={handleSkip}
    >
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl"
      >
        {/* Close Button */}
        <button
          onClick={handleSkip}
          className="absolute top-4 right-4 p-2 hover:bg-slate-100 rounded-full transition-colors"
        >
          <X className="h-4 w-4 text-slate-400" />
        </button>

        {/* Content */}
        <div className="text-center mb-6">
          {step.image && (
            <div className="text-6xl mb-4">{step.image}</div>
          )}
          <h2 className="text-2xl font-bold text-slate-800 mb-2">
            {step.title}
          </h2>
          <p className="text-slate-600">
            {step.description}
          </p>
        </div>

        {/* Progress */}
        <div className="flex gap-2 justify-center mb-6">
          {tourSteps.map((_, index) => (
            <div
              key={index}
              className={`h-1.5 rounded-full transition-all ${
                index === currentStep
                  ? 'w-8 bg-emerald-500'
                  : index < currentStep
                  ? 'w-6 bg-emerald-300'
                  : 'w-6 bg-slate-200'
              }`}
            />
          ))}
        </div>

        {/* Actions */}
        <div className="flex gap-3">
          {!isLastStep && (
            <Button
              variant="outline"
              onClick={handleSkip}
              className="flex-1 h-12 rounded-xl"
            >
              Pular
            </Button>
          )}
          <Button
            onClick={handleNext}
            className="flex-1 h-12 rounded-xl bg-emerald-500 hover:bg-emerald-600"
          >
            {isLastStep ? (
              <>
                <Check className="h-5 w-5 mr-2" />
                Começar
              </>
            ) : (
              <>
                Próximo
                <ArrowRight className="h-5 w-5 ml-2" />
              </>
            )}
          </Button>
        </div>
      </motion.div>
    </motion.div>
  );
}