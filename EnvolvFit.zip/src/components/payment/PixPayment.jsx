import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Copy, CheckCircle2, Upload, QrCode, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';

export default function PixPayment({ amount, planType, paymentData, onSubmitProof }) {
  const PIX_KEY = paymentData?.pix_copy_paste || '19998847987';
  const [copied, setCopied] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [proofFile, setProofFile] = useState(null);
  const [notes, setNotes] = useState('');

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value || 0);
  };

  const copyPixKey = () => {
    navigator.clipboard.writeText(PIX_KEY);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProofFile(file);
    }
  };

  const handleSubmit = async () => {
    if (!proofFile) return;
    
    setUploading(true);
    await onSubmitProof(proofFile, notes);
    setUploading(false);
  };

  return (
    <div className="space-y-6">
      {/* Amount */}
      <div className="bg-gradient-to-r from-emerald-500 to-teal-600 p-6 rounded-2xl text-white text-center">
        <p className="text-sm opacity-80 mb-1">Valor a pagar</p>
        <p className="text-4xl font-bold">{formatCurrency(amount)}</p>
        <p className="text-sm opacity-80 mt-2">
          Plano {planType === 'monthly' ? 'Mensal' : 'Anual'}
        </p>
      </div>

      {/* QR Code */}
      <div className="bg-white p-6 rounded-2xl border-2 border-slate-200 text-center">
        {paymentData?.qr_code_base64 ? (
          <div>
            <img 
              src={`data:image/png;base64,${paymentData.qr_code_base64}`}
              alt="QR Code PIX"
              className="h-48 w-48 mx-auto mb-3"
            />
            <p className="text-xs text-emerald-600 font-medium mb-1">✓ QR Code Gerado</p>
            <p className="text-xs text-slate-500">
              Escaneie com o app do seu banco
            </p>
          </div>
        ) : (
          <div>
            <div className="h-48 w-48 mx-auto bg-slate-100 rounded-xl flex items-center justify-center mb-3">
              <QrCode className="h-20 w-20 text-slate-400" />
            </div>
            <p className="text-xs text-slate-500">
              Escaneie o QR Code com o app do seu banco
            </p>
          </div>
        )}
      </div>

      {/* PIX Key */}
      <div>
        <Label className="text-slate-700 mb-2 block">Ou copie a chave PIX</Label>
        <div className="flex gap-2">
          <Input
            value={PIX_KEY}
            readOnly
            className="flex-1 h-12 rounded-xl font-mono text-center text-lg font-semibold"
          />
          <Button
            onClick={copyPixKey}
            className={cn(
              "h-12 w-12 rounded-xl transition-all",
              copied ? "bg-emerald-500 hover:bg-emerald-600" : "bg-slate-800 hover:bg-slate-900"
            )}
          >
            {copied ? (
              <CheckCircle2 className="h-5 w-5" />
            ) : (
              <Copy className="h-5 w-5" />
            )}
          </Button>
        </div>
        {copied && (
          <motion.p
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-sm text-emerald-600 mt-2 text-center"
          >
            ✓ Chave PIX copiada!
          </motion.p>
        )}
      </div>

      {/* Instructions */}
      <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100">
        <div className="flex items-start gap-3">
          <AlertCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="font-semibold text-blue-800 mb-1">Como funciona?</h4>
            <ol className="text-sm text-blue-700 space-y-1 list-decimal list-inside">
              <li>Faça o pagamento via PIX {paymentData?.qr_code_base64 ? 'escaneando o QR Code ou usando' : 'usando'} a chave acima</li>
              {paymentData?.manual ? (
                <>
                  <li>Envie o comprovante de pagamento abaixo</li>
                  <li>Aguarde a confirmação manual (até 24 horas)</li>
                </>
              ) : (
                <li>O pagamento é confirmado automaticamente em segundos!</li>
              )}
              <li>Seu acesso Premium será liberado {paymentData?.manual ? 'após confirmação' : 'automaticamente'}!</li>
            </ol>
          </div>
        </div>
      </div>

      {/* Upload Proof */}
      <div className="space-y-4">
        <div>
          <Label htmlFor="proof" className="text-slate-700 mb-2 block">
            Enviar comprovante de pagamento *
          </Label>
          <input
            id="proof"
            type="file"
            accept="image/*,.pdf"
            onChange={handleFileUpload}
            className="hidden"
          />
          <label
            htmlFor="proof"
            className="flex items-center justify-center gap-2 h-12 px-4 rounded-xl border-2 border-dashed border-slate-300 hover:border-slate-400 transition-colors cursor-pointer bg-white"
          >
            <Upload className="h-5 w-5 text-slate-500" />
            <span className="text-sm text-slate-600">
              {proofFile ? proofFile.name : 'Escolher arquivo'}
            </span>
          </label>
          {proofFile && (
            <p className="text-xs text-emerald-600 mt-2">✓ Arquivo selecionado</p>
          )}
        </div>

        <div>
          <Label htmlFor="notes" className="text-slate-700 mb-2 block">
            Observações (opcional)
          </Label>
          <Input
            id="notes"
            placeholder="Ex: Paguei pelo app Nubank"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="h-12 rounded-xl"
          />
        </div>

        <Button
          onClick={handleSubmit}
          disabled={!proofFile || uploading}
          className="w-full h-14 bg-emerald-500 hover:bg-emerald-600 rounded-xl text-base font-semibold"
        >
          {uploading ? (
            'Enviando...'
          ) : (
            <>
              <CheckCircle2 className="h-5 w-5 mr-2" />
              Enviar Comprovante
            </>
          )}
        </Button>
      </div>

      <p className="text-xs text-center text-slate-500">
        Após o envio, você receberá uma confirmação por e-mail quando seu pagamento for aprovado.
      </p>
    </div>
  );
}