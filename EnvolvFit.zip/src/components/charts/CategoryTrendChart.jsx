import React from 'react';
import { motion } from 'framer-motion';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { getCategoryConfig } from '@/components/ui/CategoryIcon';

export default function CategoryTrendChart({ data, categories }) {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 rounded-xl shadow-lg border border-slate-200">
          <p className="text-sm font-semibold text-slate-800 mb-2">{label}</p>
          {payload.map((entry, index) => {
            const config = getCategoryConfig(entry.dataKey);
            return (
              <div key={index} className="flex items-center gap-2 text-sm">
                <div 
                  className="w-2 h-2 rounded-full" 
                  style={{ backgroundColor: entry.fill }}
                />
                <span className="text-slate-600">{config.label}:</span>
                <span className="font-semibold" style={{ color: entry.fill }}>
                  {formatCurrency(entry.value)}
                </span>
              </div>
            );
          })}
        </div>
      );
    }
    return null;
  };

  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 text-slate-400">
        Dados insuficientes para gerar o gráfico
      </div>
    );
  }

  const colors = {
    food: '#f97316',
    transport: '#0ea5e9',
    housing: '#6366f1',
    utilities: '#eab308',
    health: '#ef4444',
    education: '#06b6d4',
    entertainment: '#ec4899',
    shopping: '#f43f5e',
    travel: '#14b8a6',
    subscriptions: '#8b5cf6',
    other_expense: '#64748b',
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="w-full h-80"
    >
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
          <XAxis 
            dataKey="period" 
            stroke="#94a3b8" 
            style={{ fontSize: '12px' }}
          />
          <YAxis 
            stroke="#94a3b8" 
            style={{ fontSize: '12px' }}
            tickFormatter={formatCurrency}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend 
            wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }}
            iconType="circle"
          />
          {categories.map((category) => (
            <Bar 
              key={category}
              dataKey={category} 
              name={getCategoryConfig(category).label}
              fill={colors[category] || '#64748b'}
              radius={[4, 4, 0, 0]}
            />
          ))}
        </BarChart>
      </ResponsiveContainer>
    </motion.div>
  );
}