import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { motion } from 'framer-motion';
import { getCategoryLabel } from '@/components/ui/CategoryIcon';

const COLORS = [
  '#8b5cf6', '#6366f1', '#3b82f6', '#0ea5e9', '#06b6d4',
  '#14b8a6', '#10b981', '#84cc16', '#eab308', '#f59e0b',
  '#f97316', '#ef4444', '#ec4899', '#d946ef', '#a855f7'
];

export default function AdvancedCategoryChart({ data, currency = 'BRL' }) {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: currency,
    }).format(value || 0);
  };

  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 text-slate-400">
        Sem dados para exibir
      </div>
    );
  }

  const total = data.reduce((sum, item) => sum + (item.value || 0), 0);

  const chartData = data.map((item, index) => ({
    name: getCategoryLabel(item.name),
    value: item.value,
    percentage: ((item.value / total) * 100).toFixed(1),
    color: COLORS[index % COLORS.length],
  }));

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const data = payload[0];
      return (
        <div className="bg-white p-3 rounded-lg shadow-lg border border-slate-200">
          <p className="font-semibold text-slate-800">{data.name}</p>
          <p className="text-sm text-slate-600">
            {formatCurrency(data.value)} ({data.payload.percentage}%)
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-4"
    >
      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Pie
            data={chartData}
            cx="50%"
            cy="50%"
            labelLine={false}
            outerRadius={100}
            fill="#8884d8"
            dataKey="value"
            label={({ percentage }) => `${percentage}%`}
          >
            {chartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          <Tooltip content={<CustomTooltip />} />
        </PieChart>
      </ResponsiveContainer>

      {/* Legend with details */}
      <div className="space-y-2">
        {chartData.map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.05 }}
            className="flex items-center justify-between p-3 bg-slate-50 rounded-xl hover:bg-slate-100 transition-colors"
          >
            <div className="flex items-center gap-3 flex-1 min-w-0">
              <div
                className="h-3 w-3 rounded-full flex-shrink-0"
                style={{ backgroundColor: item.color }}
              />
              <span className="text-sm text-slate-700 truncate">{item.name}</span>
            </div>
            <div className="text-right">
              <p className="text-sm font-semibold text-slate-800">
                {formatCurrency(item.value)}
              </p>
              <p className="text-xs text-slate-500">{item.percentage}%</p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="bg-violet-50 p-4 rounded-xl border border-violet-200">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-violet-800">Total Gasto</span>
          <span className="text-lg font-bold text-violet-900">{formatCurrency(total)}</span>
        </div>
      </div>
    </motion.div>
  );
}