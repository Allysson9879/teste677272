import { useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { format, isAfter, isBefore, addDays, startOfMonth, endOfMonth } from 'date-fns';

export function useNotificationManager() {
  const queryClient = useQueryClient();

  const { data: transactions = [] } = useQuery({
    queryKey: ['transactions-notifications'],
    queryFn: () => base44.entities.Transaction.list('-date', 500),
  });

  const { data: budgets = [] } = useQuery({
    queryKey: ['budgets-notifications'],
    queryFn: () => {
      const currentMonth = format(new Date(), 'yyyy-MM');
      return base44.entities.Budget.filter({ month: currentMonth });
    },
  });

  const { data: insights = [] } = useQuery({
    queryKey: ['insights-notifications'],
    queryFn: () => base44.entities.FinancialInsight.list('-created_date', 50),
  });

  const { data: existingNotifications = [] } = useQuery({
    queryKey: ['notifications'],
    queryFn: () => base44.entities.Notification.list('-created_date', 100),
  });

  const createNotification = useMutation({
    mutationFn: (notification) => base44.entities.Notification.create(notification),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  // Check for bill reminders (recurring transactions coming up)
  useEffect(() => {
    if (transactions.length === 0) return;

    const today = new Date();
    const nextWeek = addDays(today, 7);

    const recurringTransactions = transactions.filter(t => t.is_recurring && t.type === 'expense');

    recurringTransactions.forEach(transaction => {
      if (!transaction.recurring_day) return;

      const nextDueDate = new Date(
        today.getFullYear(),
        today.getMonth(),
        transaction.recurring_day
      );

      // If the date has passed this month, check next month
      if (isBefore(nextDueDate, today)) {
        nextDueDate.setMonth(nextDueDate.getMonth() + 1);
      }

      // If due within the next 7 days
      if (isAfter(nextDueDate, today) && isBefore(nextDueDate, nextWeek)) {
        const notificationExists = existingNotifications.some(
          n => n.type === 'bill_reminder' && 
          n.related_entity_id === transaction.id &&
          n.metadata?.month === format(nextDueDate, 'yyyy-MM')
        );

        if (!notificationExists) {
          createNotification.mutate({
            title: 'Conta a Pagar em Breve',
            message: `${transaction.description || 'Despesa recorrente'} vence em ${format(nextDueDate, 'dd/MM')}`,
            type: 'bill_reminder',
            priority: 'medium',
            related_entity_id: transaction.id,
            metadata: {
              month: format(nextDueDate, 'yyyy-MM'),
              dueDate: format(nextDueDate, 'yyyy-MM-dd'),
            },
          });
        }
      }
    });
  }, [transactions, existingNotifications]);

  // Check for budget alerts
  useEffect(() => {
    if (budgets.length === 0 || transactions.length === 0) return;

    const currentMonth = format(new Date(), 'yyyy-MM');
    const monthStart = format(startOfMonth(new Date()), 'yyyy-MM-dd');
    const monthEnd = format(endOfMonth(new Date()), 'yyyy-MM-dd');

    const currentMonthTransactions = transactions.filter(
      t => t.date >= monthStart && t.date <= monthEnd && t.type === 'expense'
    );

    budgets.forEach(budget => {
      const categorySpending = currentMonthTransactions
        .filter(t => t.category === budget.category)
        .reduce((sum, t) => sum + (t.amount || 0), 0);

      const percentUsed = (categorySpending / budget.limit) * 100;
      const alertThreshold = budget.alert_percentage || 80;

      if (percentUsed >= alertThreshold) {
        const notificationExists = existingNotifications.some(
          n => n.type === 'budget_alert' && 
          n.related_entity_id === budget.id &&
          n.metadata?.month === currentMonth
        );

        if (!notificationExists) {
          createNotification.mutate({
            title: percentUsed >= 100 ? 'Orçamento Excedido!' : 'Atenção ao Orçamento',
            message: `Você já gastou ${percentUsed.toFixed(0)}% do orçamento de ${budget.category}`,
            type: 'budget_alert',
            priority: percentUsed >= 100 ? 'high' : 'medium',
            related_entity_id: budget.id,
            metadata: {
              month: currentMonth,
              percentUsed: percentUsed.toFixed(2),
            },
          });
        }
      }
    });
  }, [budgets, transactions, existingNotifications]);

  // Check for new insights
  useEffect(() => {
    if (insights.length === 0) return;

    const recentInsights = insights.filter(insight => {
      const createdAt = new Date(insight.created_date);
      const daysSinceCreated = (new Date() - createdAt) / (1000 * 60 * 60 * 24);
      return daysSinceCreated <= 1; // Last 24 hours
    });

    recentInsights.forEach(insight => {
      const notificationExists = existingNotifications.some(
        n => n.type === 'insight_ready' && n.related_entity_id === insight.id
      );

      if (!notificationExists && !insight.is_read) {
        createNotification.mutate({
          title: 'Novo Insight Disponível',
          message: insight.title,
          type: 'insight_ready',
          priority: insight.priority || 'medium',
          related_entity_id: insight.id,
          action_url: '/Insights',
        });
      }
    });
  }, [insights, existingNotifications]);
}