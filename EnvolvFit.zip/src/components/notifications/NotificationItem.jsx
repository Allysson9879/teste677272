import React from 'react';
import { motion } from 'framer-motion';
import { 
  Bell, 
  AlertTriangle, 
  CheckCircle, 
  Sparkles, 
  Info,
  TrendingUp,
  Calendar,
  Trash2,
  Check
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const notificationConfig = {
  bill_reminder: {
    icon: Calendar,
    color: 'text-blue-600',
    bg: 'bg-blue-50',
    borderColor: 'border-blue-200',
  },
  budget_alert: {
    icon: AlertTriangle,
    color: 'text-amber-600',
    bg: 'bg-amber-50',
    borderColor: 'border-amber-200',
  },
  transaction_confirm: {
    icon: CheckCircle,
    color: 'text-emerald-600',
    bg: 'bg-emerald-50',
    borderColor: 'border-emerald-200',
  },
  insight_ready: {
    icon: Sparkles,
    color: 'text-purple-600',
    bg: 'bg-purple-50',
    borderColor: 'border-purple-200',
  },
  app_update: {
    icon: TrendingUp,
    color: 'text-indigo-600',
    bg: 'bg-indigo-50',
    borderColor: 'border-indigo-200',
  },
  general: {
    icon: Info,
    color: 'text-slate-600',
    bg: 'bg-slate-50',
    borderColor: 'border-slate-200',
  },
};

export default function NotificationItem({ notification, onMarkAsRead, onDelete }) {
  const config = notificationConfig[notification.type] || notificationConfig.general;
  const Icon = config.icon;

  const handleClick = () => {
    if (!notification.is_read) {
      onMarkAsRead();
    }
  };

  const content = (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      className={cn(
        "bg-white p-4 rounded-2xl border transition-all",
        notification.is_read ? "border-slate-100" : config.borderColor,
        !notification.is_read && "shadow-sm"
      )}
      onClick={handleClick}
    >
      <div className="flex items-start gap-3">
        <div className={cn(
          "h-10 w-10 rounded-xl flex items-center justify-center flex-shrink-0",
          config.bg
        )}>
          <Icon className={cn("h-5 w-5", config.color)} />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-1">
            <h3 className={cn(
              "font-semibold text-sm",
              notification.is_read ? "text-slate-600" : "text-slate-800"
            )}>
              {notification.title}
            </h3>
            {!notification.is_read && (
              <div className="h-2 w-2 rounded-full bg-emerald-500 flex-shrink-0 mt-1" />
            )}
          </div>

          <p className={cn(
            "text-sm mb-2",
            notification.is_read ? "text-slate-400" : "text-slate-600"
          )}>
            {notification.message}
          </p>

          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400">
              {formatDistanceToNow(new Date(notification.created_date), {
                addSuffix: true,
                locale: ptBR,
              })}
            </span>

            <div className="flex items-center gap-2">
              {!notification.is_read && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    e.preventDefault();
                    onMarkAsRead();
                  }}
                  className="p-1.5 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  <Check className="h-4 w-4 text-slate-500" />
                </button>
              )}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  e.preventDefault();
                  onDelete();
                }}
                className="p-1.5 hover:bg-red-50 rounded-lg transition-colors"
              >
                <Trash2 className="h-4 w-4 text-red-500" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {notification.priority === 'high' && !notification.is_read && (
        <div className="mt-3 pt-3 border-t border-slate-100">
          <div className="flex items-center gap-2 text-xs text-red-600 font-medium">
            <AlertTriangle className="h-3 w-3" />
            Prioridade Alta
          </div>
        </div>
      )}
    </motion.div>
  );

  if (notification.action_url) {
    return (
      <Link to={notification.action_url}>
        {content}
      </Link>
    );
  }

  return content;
}