import React from 'react';
import { CreditCard, Smartphone } from 'lucide-react';
import { motion } from 'framer-motion';

const bankLogos = {
  nubank: 'https://logodownload.org/wp-content/uploads/2019/08/nubank-logo-1.png',
  inter: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/Banco_Inter_logo.svg/2560px-Banco_Inter_logo.svg.png',
  itau: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/af/Banco_Ita%C3%BA_logo.svg/2560px-Banco_Ita%C3%BA_logo.svg.png',
  bradesco: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Banco_Bradesco_logo.svg/2560px-Banco_Bradesco_logo.svg.png',
  c6: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2d/C6_Bank_logo.svg/2560px-C6_Bank_logo.svg.png',
  picpay: 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/PicPay_logo.svg/2560px-PicPay_logo.svg.png',
};

const bankColors = {
  nubank: 'linear-gradient(135deg, #820AD1, #A05FE3)',
  inter: 'linear-gradient(135deg, #FF7A00, #FF9D3D)',
  itau: 'linear-gradient(135deg, #003D7A, #0057B8)',
  bradesco: 'linear-gradient(135deg, #CC092F, #E63946)',
  santander: 'linear-gradient(135deg, #EC0000, #FF4444)',
  caixa: 'linear-gradient(135deg, #005CA9, #0077CC)',
  bb: 'linear-gradient(135deg, #FFCC00, #FFD700)',
  c6: 'linear-gradient(135deg, #000000, #2D2D2D)',
  picpay: 'linear-gradient(135deg, #11C76F, #1BE88B)',
  neon: 'linear-gradient(135deg, #00D9A3, #00F5C4)',
  other: 'linear-gradient(135deg, #64748b, #94a3b8)',
};

const getBankName = (bank) => {
  const names = {
    nubank: 'Nubank',
    inter: 'Inter',
    itau: 'Itaú',
    bradesco: 'Bradesco',
    santander: 'Santander',
    caixa: 'Caixa',
    bb: 'Banco do Brasil',
    c6: 'C6 Bank',
    picpay: 'PicPay',
    neon: 'Neon',
    other: 'Outro',
  };
  return names[bank] || bank;
};

export default function CardVisual({ card, onClick, isSmall = false }) {
  const cardStyle = {
    background: card.color || bankColors[card.bank] || bankColors.other,
  };

  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={`relative rounded-2xl text-white overflow-hidden shadow-xl ${
        isSmall ? 'h-32 w-52' : 'h-48 w-80'
      }`}
      style={cardStyle}
    >
      {/* Card Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white rounded-full -translate-y-16 translate-x-16" />
        <div className="absolute bottom-0 left-0 w-40 h-40 bg-white rounded-full translate-y-20 -translate-x-20" />
      </div>

      {/* Content */}
      <div className="relative h-full p-5 flex flex-col justify-between">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            {bankLogos[card.bank] ? (
              <img 
                src={bankLogos[card.bank]} 
                alt={getBankName(card.bank)}
                className={`${isSmall ? 'h-6' : 'h-8'} object-contain filter brightness-0 invert`}
              />
            ) : (
              <div className="flex items-center gap-2">
                <CreditCard className={isSmall ? 'h-5 w-5' : 'h-6 w-6'} />
                <span className={`font-semibold ${isSmall ? 'text-sm' : 'text-base'}`}>
                  {getBankName(card.bank)}
                </span>
              </div>
            )}
          </div>
          <div className={`${isSmall ? 'h-6 w-10' : 'h-8 w-12'} bg-white/30 rounded backdrop-blur-sm`} />
        </div>

        {/* Card Number */}
        {!isSmall && (
          <div className="flex gap-3 text-lg tracking-wider font-mono">
            <span>••••</span>
            <span>••••</span>
            <span>••••</span>
            <span>{card.last_digits || '0000'}</span>
          </div>
        )}

        {/* Footer */}
        <div className="flex items-end justify-between">
          <div>
            <p className={`${isSmall ? 'text-xs' : 'text-sm'} opacity-80`}>
              {card.card_type === 'credit' ? 'Crédito' : card.card_type === 'debit' ? 'Débito' : 'Crédito/Débito'}
            </p>
            <p className={`font-semibold ${isSmall ? 'text-sm' : 'text-base'}`}>
              {card.nickname}
            </p>
            {isSmall && card.last_digits && (
              <p className="text-xs opacity-80 mt-0.5">•••• {card.last_digits}</p>
            )}
          </div>
          <Smartphone className={isSmall ? 'h-6 w-6' : 'h-8 w-8'} />
        </div>
      </div>
    </motion.button>
  );
}