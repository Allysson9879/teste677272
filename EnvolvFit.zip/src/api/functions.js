import { base44 } from './base44Client';


export const createPixPayment = base44.functions.createPixPayment;

export const webhookMercadoPago = base44.functions.webhookMercadoPago;

export const connectBank = base44.functions.connectBank;

export const syncTransactions = base44.functions.syncTransactions;

