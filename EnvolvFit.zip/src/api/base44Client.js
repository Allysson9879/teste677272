import { createClient } from '@base44/sdk';

const appId = import.meta.env.VITE_BASE44_APP_ID || "69497132e0666aa4038bcc74";
const requiresAuth = typeof import.meta.env.VITE_BASE44_REQUIRES_AUTH !== 'undefined'
  ? import.meta.env.VITE_BASE44_REQUIRES_AUTH !== 'false'
  : true;
// Prefer explicit env var, otherwise in development default to public API endpoint
const baseUrl = import.meta.env.VITE_BASE44_API_URL || (import.meta.env.DEV ? 'https://api.base44.com' : undefined);

let base44;
try {
  // createClient may throw synchronously if misconfigured
  base44 = createClient({
    appId,
    requiresAuth,
    ...(baseUrl ? { baseUrl } : {}),
  });
} catch (err) {
  // eslint-disable-next-line no-console
  console.error('[Base44] createClient failed', err);
  // provide a safe fallback so the app doesn't crash; operations will be no-ops
  const noopAsync = async () => [];
  const noopResolve = () => Promise.resolve([]);
  const makeEntityStub = () => ({
    list: noopAsync,
    filter: noopAsync,
    create: async () => ({}),
    update: async () => ({}),
    delete: async () => ({}),
  });

  base44 = {
    entities: {
      Notification: makeEntityStub(),
      Transaction: makeEntityStub(),
      Card: makeEntityStub(),
      BankAccount: makeEntityStub(),
      Budget: makeEntityStub(),
      // generic proxy for unknown entities
      __proto__: new Proxy({}, {
        get: () => makeEntityStub()
      })
    },
    functions: new Proxy({}, { get: () => async () => ({}) }),
    integrations: new Proxy({}, { get: () => ({}) }),
    auth: {},
  };
}
export { base44 };

// Helpful debug info for diagnosing 404s during development
try {
  // eslint-disable-next-line no-console
  console.log('Base44 client initialized', {
    appId,
    requiresAuth,
    baseUrl,
    dev: import.meta.env.DEV,
    location: typeof window !== 'undefined' ? window.location.href : undefined,
  });
} catch (e) {}

// Listen for global fetch failures to detect 404s from Base44 endpoints in dev
if (import.meta.env.DEV && typeof window !== 'undefined') {
  const origFetch = window.fetch.bind(window);
  window.fetch = async (input, init) => {
    try {
      const res = await origFetch(input, init);
      if (res && res.status === 404 && typeof input === 'string' && input.includes('base44')) {
        // eslint-disable-next-line no-console
        console.warn('[Base44] received 404 for', input, { appId, baseUrl, location: window.location.href });
      }
      return res;
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error('[Base44] fetch error', err, { input, init });
      throw err;
    }
  };
}
