
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  Home,
  Receipt,
  BarChart3,
  Wallet,
  Settings,
  Bell,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useNotificationManager } from '@/components/notifications/NotificationManager';

const navItems = [
  { name: 'Home', icon: Home, page: 'Home' },
  { name: 'Transações', icon: Receipt, page: 'Transactions' },
  { name: 'Carteira', icon: Wallet, page: 'Wallet' },
  { name: 'Análises', icon: BarChart3, page: 'Analytics' },
  { name: 'Config', icon: Settings, page: 'Settings' },
];

const pagesWithoutNav = ['Premium', 'Notifications', 'Insights', 'Checkout', 'AdminPayments', 'FinancialChat', 'Projections', 'Reports', 'Cards', 'Accounts', 'Budgets'];

export default function Layout({ children, currentPageName }) {
  const showNav = !pagesWithoutNav.includes(currentPageName);
  
  // Initialize notification manager
  useNotificationManager();

  // Fetch unread notifications count
  const { data: notifications = [] } = useQuery({
    queryKey: ['notifications'],
    queryFn: () => base44.entities.Notification.list('-created_date', 100),
    refetchInterval: 60000, // Refetch every minute
  });

  const unreadCount = notifications.filter(n => !n.is_read).length;

  return (
    <div className="min-h-screen bg-slate-50">
      <style>{`
        :root {
          --emerald-500: #10b981;
          --emerald-600: #059669;
          --slate-50: #f8fafc;
          --slate-100: #f1f5f9;
          --slate-800: #1e293b;
        }
        
        body {
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          -webkit-font-smoothing: antialiased;
          -moz-osx-font-smoothing: grayscale;
        }

        /* Custom scrollbar */
        ::-webkit-scrollbar {
          width: 6px;
          height: 6px;
        }
        ::-webkit-scrollbar-track {
          background: transparent;
        }
        ::-webkit-scrollbar-thumb {
          background: #cbd5e1;
          border-radius: 3px;
        }
        ::-webkit-scrollbar-thumb:hover {
          background: #94a3b8;
        }

        /* Safe area for mobile */
        @supports (padding-bottom: env(safe-area-inset-bottom)) {
          .nav-safe-area {
            padding-bottom: env(safe-area-inset-bottom);
          }
        }

        /* iOS smooth scroll */
        * {
          -webkit-overflow-scrolling: touch;
        }

        /* Prevent iOS zoom on input focus */
        input[type="text"],
        input[type="number"],
        input[type="email"],
        input[type="tel"],
        input[type="date"],
        select,
        textarea {
          font-size: 16px !important;
        }

        /* iOS tap highlight */
        * {
          -webkit-tap-highlight-color: transparent;
        }
        `}</style>

      {/* Notification Bell - Fixed Position - Only on Home */}
      {currentPageName === 'Home' && (
        <Link
          to={createPageUrl('Notifications')}
          className="fixed top-6 right-6 z-50"
        >
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="relative h-11 w-11 rounded-full bg-white shadow-lg border border-slate-200 flex items-center justify-center"
          >
            <Bell className="h-5 w-5 text-slate-600" />
            {unreadCount > 0 && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-red-500 flex items-center justify-center"
              >
                <span className="text-[10px] font-bold text-white">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              </motion.div>
            )}
          </motion.button>
        </Link>
      )}

      {/* Main Content */}
      <main className={cn(showNav && "pb-20")}>
        {children}
      </main>

      {/* Bottom Navigation */}
      {showNav && (
        <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-100 z-50 nav-safe-area">
          <div className="flex items-center justify-around h-16 max-w-lg mx-auto">
            {navItems.map((item) => {
              const isActive = currentPageName === item.page;
              const Icon = item.icon;

              return (
                <Link
                  key={item.page}
                  to={createPageUrl(item.page)}
                  className={cn(
                    "flex flex-col items-center justify-center w-16 h-full transition-all relative group",
                    isActive ? "text-emerald-600" : "text-slate-400 hover:text-slate-600 active:scale-95"
                  )}
                >
                  {isActive && (
                    <motion.div
                      layoutId="activeTab"
                      className="absolute -top-0.5 left-1/2 -translate-x-1/2 w-8 h-1 bg-gradient-to-r from-emerald-400 to-teal-500 rounded-full shadow-lg"
                      transition={{ type: "spring", stiffness: 500, damping: 30 }}
                    />
                  )}
                  <motion.div
                    whileTap={{ scale: 0.9 }}
                    className={cn(
                      "flex flex-col items-center transition-transform",
                      !isActive && "group-active:scale-90"
                    )}
                  >
                    <Icon className={cn(
                      "h-5 w-5 transition-all",
                      isActive && "scale-110"
                    )} />
                    <span className={cn(
                      "text-[10px] mt-1 font-medium transition-all",
                      isActive && "font-semibold"
                    )}>
                      {item.name}
                    </span>
                  </motion.div>
                </Link>
              );
            })}
          </div>
        </nav>
      )}
    </div>
  );
}
