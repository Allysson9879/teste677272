import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, CreditCard, Building2, MoreVertical, Edit2, Trash2, Eye, EyeOff, TrendingUp, TrendingDown, Wallet as WalletIcon, Receipt, AlertTriangle, PieChart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import CardVisual from '@/components/cards/CardVisual';
import CardForm from '@/components/forms/CardForm';
import AccountCard from '@/components/accounts/AccountCard';
import BankAccountForm from '@/components/forms/BankAccountForm';
import CardUsageChart from '@/components/charts/CardUsageChart';
import EmptyState from '@/components/ui/EmptyState';
import { getCategoryLabel } from '@/components/ui/CategoryIcon';
import { format, startOfMonth, endOfMonth } from 'date-fns';

export default function Wallet() {
  const [activeTab, setActiveTab] = useState('cards');
  const [showCardForm, setShowCardForm] = useState(false);
  const [showAccountForm, setShowAccountForm] = useState(false);
  const [editingCard, setEditingCard] = useState(null);
  const [editingAccount, setEditingAccount] = useState(null);
  const [deletingItem, setDeletingItem] = useState(null);
  const [selectedCard, setSelectedCard] = useState(null);
  const [selectedAccount, setSelectedAccount] = useState(null);

  const queryClient = useQueryClient();

  const { data: cards = [] } = useQuery({
    queryKey: ['cards'],
    queryFn: () => base44.entities.Card.list('-created_date', 50),
  });

  const { data: bankAccounts = [] } = useQuery({
    queryKey: ['bankAccounts'],
    queryFn: () => base44.entities.BankAccount.list('-created_date', 50),
  });

  const currentMonth = format(new Date(), 'yyyy-MM');
  const startDate = format(startOfMonth(new Date()), 'yyyy-MM-dd');
  const endDate = format(endOfMonth(new Date()), 'yyyy-MM-dd');

  const { data: transactions = [] } = useQuery({
    queryKey: ['transactions', currentMonth],
    queryFn: () => base44.entities.Transaction.filter({
      date: { $gte: startDate, $lte: endDate }
    }, '-date', 500),
  });

  const createCardMutation = useMutation({
    mutationFn: (data) => base44.entities.Card.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['cards']);
      setShowCardForm(false);
      setEditingCard(null);
    },
  });

  const updateCardMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Card.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['cards']);
      setShowCardForm(false);
      setEditingCard(null);
    },
  });

  const deleteCardMutation = useMutation({
    mutationFn: (id) => base44.entities.Card.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['cards']);
      setDeletingItem(null);
    },
  });

  const createAccountMutation = useMutation({
    mutationFn: (data) => base44.entities.BankAccount.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['bankAccounts']);
      setShowAccountForm(false);
      setEditingAccount(null);
    },
  });

  const updateAccountMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.BankAccount.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['bankAccounts']);
      setShowAccountForm(false);
      setEditingAccount(null);
    },
  });

  const deleteAccountMutation = useMutation({
    mutationFn: (id) => base44.entities.BankAccount.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['bankAccounts']);
      setDeletingItem(null);
    },
  });

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value || 0);
  };

  const getCardExpenses = (cardId) => {
    return transactions
      .filter(t => t.type === 'expense' && t.card_id === cardId)
      .reduce((sum, t) => sum + (t.amount || 0), 0);
  };

  const getAccountBalance = (accountId) => {
    const account = bankAccounts.find(a => a.id === accountId);
    if (!account) return 0;

    const accountTransactions = transactions.filter(t => t.bank_account_id === accountId);
    const transactionTotal = accountTransactions.reduce((sum, t) => {
      return sum + (t.type === 'income' ? t.amount : -t.amount);
    }, 0);

    // Subtract card expenses from this account
    const accountCards = cards.filter(c => c.bank_account_id === accountId);
    const cardExpenses = accountCards.reduce((sum, card) => {
      return sum + getCardExpenses(card.id);
    }, 0);

    return (account.initial_balance || 0) + transactionTotal - cardExpenses;
  };

  const getCardCategoryBreakdown = (cardId) => {
    const cardTransactions = transactions.filter(t => t.type === 'expense' && t.card_id === cardId);
    return cardTransactions.reduce((acc, t) => {
      acc[t.category] = (acc[t.category] || 0) + (t.amount || 0);
      return acc;
    }, {});
  };

  const getCardTransactions = (cardId) => {
    return transactions.filter(t => t.card_id === cardId);
  };

  const activeCards = cards.filter(c => c.is_active);
  const activeAccounts = bankAccounts.filter(a => a.is_active);
  
  const totalCardLimit = activeCards.reduce((sum, c) => sum + (c.limit || 0), 0);
  const totalCardSpent = transactions.filter(t => t.type === 'expense' && t.card_id).reduce((sum, t) => sum + (t.amount || 0), 0);
  const totalAccountsBalance = activeAccounts.reduce((sum, acc) => sum + getAccountBalance(acc.id), 0);

  return (
    <div className="min-h-screen bg-slate-50 pb-32">
      {/* Header */}
      <div className="bg-gradient-to-br from-violet-600 via-purple-600 to-indigo-700 px-6 pt-6 pb-32 text-white">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">Minha Carteira</h1>
        </div>
        <p className="text-white/80 text-sm">
          Gerencie seus cartões e contas bancárias
        </p>
      </div>

      {/* Summary Cards */}
      <div className="px-6 -mt-24 mb-6">
        <div className="grid grid-cols-2 gap-3 mb-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-2xl p-4 border border-slate-100">
            <div className="flex items-center gap-2 mb-2">
              <CreditCard className="h-4 w-4 text-violet-600" />
              <p className="text-xs text-slate-500">Cartões</p>
            </div>
            <p className="text-lg font-bold text-slate-800">{formatCurrency(totalCardLimit - totalCardSpent)}</p>
            <p className="text-xs text-slate-500 mt-1">Disponível</p>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="bg-white rounded-2xl p-4 border border-slate-100">
            <div className="flex items-center gap-2 mb-2">
              <Building2 className="h-4 w-4 text-emerald-600" />
              <p className="text-xs text-slate-500">Contas</p>
            </div>
            <p className="text-lg font-bold text-slate-800">{formatCurrency(totalAccountsBalance)}</p>
            <p className="text-xs text-slate-500 mt-1">Saldo total</p>
          </motion.div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-white rounded-2xl p-1 mb-6">
            <TabsTrigger value="cards" className="rounded-xl">
              <CreditCard className="h-4 w-4 mr-2" />
              Cartões
            </TabsTrigger>
            <TabsTrigger value="accounts" className="rounded-xl">
              <Building2 className="h-4 w-4 mr-2" />
              Contas
            </TabsTrigger>
          </TabsList>

          {/* Cards Tab */}
          <TabsContent value="cards" className="mt-0">
            <div className="flex justify-end mb-4">
              <Button
                onClick={() => {
                  setEditingCard(null);
                  setShowCardForm(true);
                }}
                size="sm"
                className="bg-violet-600 hover:bg-violet-700 rounded-xl"
                disabled={activeAccounts.length === 0}
              >
                <Plus className="h-4 w-4 mr-2" />
                Novo Cartão
              </Button>
            </div>

            {activeAccounts.length === 0 ? (
            <div className="bg-white rounded-2xl p-8">
            <EmptyState
              icon={Building2}
              title="Cadastre uma conta primeiro"
              description="Para adicionar cartões, você precisa ter pelo menos uma conta bancária"
              actionLabel="Ir para Contas"
              onAction={() => setActiveTab('accounts')}
            />
            </div>
            ) : activeCards.length === 0 ? (
            <div className="bg-white rounded-2xl p-8">
            <EmptyState
              icon={CreditCard}
              title="Nenhum cartão cadastrado"
              description="Adicione seus cartões para melhor controle"
              actionLabel="Adicionar Cartão"
              onAction={() => setShowCardForm(true)}
            />
            </div>
            ) : (
              <>
                <div className="overflow-x-auto pb-4 -mx-6 px-6 hide-scrollbar mb-6">
                  <div className="flex gap-4">
                    {activeCards.map((card) => {
                      const spent = getCardExpenses(card.id);
                      const limit = card.limit || 0;
                      const percentage = limit > 0 ? (spent / limit) * 100 : 0;
                      const isNearLimit = percentage >= 80;
                      
                      return (
                        <div key={card.id} className="flex-shrink-0 relative">
                          <CardVisual
                            card={card}
                            onClick={() => setSelectedCard(selectedCard?.id === card.id ? null : card)}
                          />
                          {isNearLimit && card.card_type !== 'debit' && (
                            <div className="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full animate-pulse">
                              {percentage.toFixed(0)}%
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {selectedCard && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white rounded-2xl p-6 border border-slate-100 mb-6"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-slate-800">Detalhes</h3>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => { setEditingCard(selectedCard); setShowCardForm(true); }}>
                            <Edit2 className="h-4 w-4 mr-2" />
                            Editar
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => setDeletingItem({ type: 'card', item: selectedCard })}
                            className="text-red-600"
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Excluir
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div className="bg-slate-50 rounded-xl p-3">
                        <p className="text-xs text-slate-500 mb-1">Limite</p>
                        <p className="font-semibold text-slate-800">{formatCurrency(selectedCard.limit)}</p>
                      </div>
                      <div className="bg-slate-50 rounded-xl p-3">
                        <p className="text-xs text-slate-500 mb-1">Gasto</p>
                        <p className="font-semibold text-red-600">{formatCurrency(getCardExpenses(selectedCard.id))}</p>
                      </div>
                    </div>

                    {Object.keys(getCardCategoryBreakdown(selectedCard.id)).length > 0 && (
                      <div className="pt-4 border-t border-slate-100">
                        <h4 className="text-sm font-semibold text-slate-800 mb-3">Top Categorias</h4>
                        <div className="space-y-2">
                          {Object.entries(getCardCategoryBreakdown(selectedCard.id))
                            .sort(([, a], [, b]) => b - a)
                            .slice(0, 3)
                            .map(([category, amount]) => (
                              <div key={category} className="flex items-center justify-between text-sm">
                                <span className="text-slate-600">{getCategoryLabel(category)}</span>
                                <span className="font-semibold text-slate-800">{formatCurrency(amount)}</span>
                              </div>
                            ))}
                        </div>
                      </div>
                    )}
                  </motion.div>
                )}

                {activeCards.length > 1 && (
                  <div className="bg-white rounded-2xl p-6 border border-slate-100">
                    <h3 className="font-semibold text-slate-800 mb-4">Comparativo</h3>
                    <CardUsageChart cards={activeCards} transactions={transactions} />
                  </div>
                )}
              </>
            )}
          </TabsContent>

          {/* Accounts Tab */}
          <TabsContent value="accounts" className="mt-0">
            <div className="flex justify-end mb-4">
              <Button
                onClick={() => {
                  setEditingAccount(null);
                  setShowAccountForm(true);
                }}
                size="sm"
                className="bg-emerald-600 hover:bg-emerald-700 rounded-xl"
              >
                <Plus className="h-4 w-4 mr-2" />
                Nova Conta
              </Button>
            </div>

            {activeAccounts.length === 0 ? (
              <div className="bg-white rounded-2xl p-8">
                <EmptyState
                  icon={Building2}
                  title="Nenhuma conta cadastrada"
                  description="Adicione suas contas para controlar seu dinheiro"
                  actionLabel="Adicionar Conta"
                  onAction={() => setShowAccountForm(true)}
                />
              </div>
            ) : (
              <>
                <div className="overflow-x-auto pb-4 -mx-6 px-6 hide-scrollbar mb-6">
                  <div className="flex gap-4">
                    {activeAccounts.map((account) => (
                      <div key={account.id} className="flex-shrink-0 w-72">
                        <AccountCard
                          account={account}
                          balance={getAccountBalance(account.id)}
                          onClick={() => setSelectedAccount(selectedAccount?.id === account.id ? null : account)}
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {selectedAccount && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white rounded-2xl p-6 border border-slate-100"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-slate-800">Detalhes</h3>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => { setEditingAccount(selectedAccount); setShowAccountForm(true); }}>
                            <Edit2 className="h-4 w-4 mr-2" />
                            Editar
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => setDeletingItem({ type: 'account', item: selectedAccount })}
                            className="text-red-600"
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Excluir
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>

                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div className="bg-slate-50 rounded-xl p-3">
                          <p className="text-xs text-slate-500 mb-1">Saldo Total</p>
                          <p className="font-semibold text-slate-800 text-sm">{formatCurrency(getAccountBalance(selectedAccount.id))}</p>
                        </div>
                        <div className="bg-violet-50 rounded-xl p-3">
                          <p className="text-xs text-violet-600 mb-1">Cartões</p>
                          <p className="font-semibold text-violet-700 text-sm">
                            {cards.filter(c => c.bank_account_id === selectedAccount.id).length}
                          </p>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="bg-emerald-50 rounded-xl p-3">
                          <p className="text-xs text-emerald-600 mb-1">Receitas</p>
                          <p className="font-semibold text-emerald-700 text-sm">
                            {formatCurrency(
                              transactions
                                .filter(t => t.bank_account_id === selectedAccount.id && t.type === 'income')
                                .reduce((sum, t) => sum + t.amount, 0)
                            )}
                          </p>
                        </div>
                        <div className="bg-red-50 rounded-xl p-3">
                          <p className="text-xs text-red-600 mb-1">Despesas</p>
                          <p className="font-semibold text-red-700 text-sm">
                            {formatCurrency(
                              transactions
                                .filter(t => t.bank_account_id === selectedAccount.id && t.type === 'expense')
                                .reduce((sum, t) => sum + t.amount, 0)
                              +
                              cards
                                .filter(c => c.bank_account_id === selectedAccount.id)
                                .reduce((sum, card) => sum + getCardExpenses(card.id), 0)
                            )}
                          </p>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Forms */}
      <AnimatePresence>
        {showCardForm && (
          <CardForm
            card={editingCard}
            onSubmit={(data) => {
              if (editingCard) {
                updateCardMutation.mutate({ id: editingCard.id, data });
              } else {
                createCardMutation.mutate(data);
              }
            }}
            onClose={() => {
              setShowCardForm(false);
              setEditingCard(null);
            }}
          />
        )}

        {showAccountForm && (
          <BankAccountForm
            account={editingAccount}
            onSubmit={(data) => {
              if (editingAccount) {
                updateAccountMutation.mutate({ id: editingAccount.id, data });
              } else {
                createAccountMutation.mutate(data);
              }
            }}
            onClose={() => {
              setShowAccountForm(false);
              setEditingAccount(null);
            }}
          />
        )}
      </AnimatePresence>

      {/* Delete Dialog */}
      <AlertDialog open={!!deletingItem} onOpenChange={() => setDeletingItem(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir {deletingItem?.type === 'card' ? 'cartão' : 'conta'}?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (deletingItem?.type === 'card') {
                  deleteCardMutation.mutate(deletingItem.item.id);
                } else {
                  deleteAccountMutation.mutate(deletingItem.item.id);
                }
              }}
              className="bg-red-600 hover:bg-red-700"
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <style>{`
        .hide-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .hide-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}