import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { format, startOfMonth, endOfMonth, subMonths } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { 
  Sparkles, 
  RefreshCw, 
  Lock, 
  Lightbulb, 
  AlertCircle, 
  Trophy, 
  TrendingUp,
  CheckCircle2,
  ArrowLeft 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

import InsightCard from '@/components/ui/InsightCard';
import EmptyState from '@/components/ui/EmptyState';
import PremiumBadge from '@/components/ui/PremiumBadge';
import { getCategoryLabel } from '@/components/ui/CategoryIcon';

export default function Insights() {
  const [user, setUser] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  const isPremium = user?.plan === 'premium';

  const currentDate = new Date();
  const startDate = format(startOfMonth(currentDate), 'yyyy-MM-dd');
  const endDate = format(endOfMonth(currentDate), 'yyyy-MM-dd');

  const { data: insights = [], isLoading } = useQuery({
    queryKey: ['insights', 'all'],
    queryFn: () => base44.entities.FinancialInsight.filter({}, '-created_date', 50),
  });

  const { data: transactions = [] } = useQuery({
    queryKey: ['transactions', startDate, endDate],
    queryFn: () => base44.entities.Transaction.filter({
      date: { $gte: startDate, $lte: endDate }
    }, '-date', 500),
  });

  const { data: previousTransactions = [] } = useQuery({
    queryKey: ['transactions-previous'],
    queryFn: async () => {
      const prevStart = format(startOfMonth(subMonths(currentDate, 1)), 'yyyy-MM-dd');
      const prevEnd = format(endOfMonth(subMonths(currentDate, 1)), 'yyyy-MM-dd');
      return base44.entities.Transaction.filter({
        date: { $gte: prevStart, $lte: prevEnd }
      }, '-date', 500);
    },
  });

  const createInsight = useMutation({
    mutationFn: (data) => base44.entities.FinancialInsight.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['insights'] });
    },
  });

  const dismissInsight = useMutation({
    mutationFn: (id) => base44.entities.FinancialInsight.update(id, { is_read: true }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['insights'] });
    },
  });

  const generateInsights = async () => {
    if (!isPremium) return;
    
    setIsGenerating(true);

    // Calculate financial data
    const currentTotals = transactions.reduce(
      (acc, t) => {
        if (t.type === 'income') acc.income += t.amount || 0;
        else acc.expenses += t.amount || 0;
        return acc;
      },
      { income: 0, expenses: 0 }
    );

    const previousTotals = previousTransactions.reduce(
      (acc, t) => {
        if (t.type === 'income') acc.income += t.amount || 0;
        else acc.expenses += t.amount || 0;
        return acc;
      },
      { income: 0, expenses: 0 }
    );

    const categoryTotals = transactions
      .filter(t => t.type === 'expense')
      .reduce((acc, t) => {
        acc[t.category] = (acc[t.category] || 0) + (t.amount || 0);
        return acc;
      }, {});

    const prevCategoryTotals = previousTransactions
      .filter(t => t.type === 'expense')
      .reduce((acc, t) => {
        acc[t.category] = (acc[t.category] || 0) + (t.amount || 0);
        return acc;
      }, {});

    // Get user goals for better insights
    const userGoals = {
      monthly_income_goal: user?.monthly_income_goal || 0,
      savings_goal: user?.savings_goal || 0,
    };

    const balance = currentTotals.income - currentTotals.expenses;
    const prevBalance = previousTotals.income - previousTotals.expenses;
    const balanceChange = balance - prevBalance;
    const savingsRate = currentTotals.income > 0 ? (balance / currentTotals.income) * 100 : 0;

    const prompt = `
Analise os dados financeiros abaixo e forneça insights AVANÇADOS e PROATIVOS em português do Brasil.
Seja direto, amigável e use linguagem simples (sem termos técnicos).

DADOS FINANCEIROS ATUAIS:
- Mês atual: Receitas R$ ${currentTotals.income.toFixed(2)}, Despesas R$ ${currentTotals.expenses.toFixed(2)}, Saldo R$ ${balance.toFixed(2)}
- Mês anterior: Receitas R$ ${previousTotals.income.toFixed(2)}, Despesas R$ ${previousTotals.expenses.toFixed(2)}, Saldo R$ ${prevBalance.toFixed(2)}
- Mudança no saldo: R$ ${balanceChange.toFixed(2)} (${balanceChange >= 0 ? 'melhor' : 'pior'})
- Taxa de poupança atual: ${savingsRate.toFixed(1)}%

METAS DO USUÁRIO:
- Meta de receita mensal: R$ ${userGoals.monthly_income_goal.toFixed(2)}
- Meta de economia mensal: R$ ${userGoals.savings_goal.toFixed(2)}

GASTOS POR CATEGORIA:
Este mês: ${Object.entries(categoryTotals).map(([cat, val]) => `${getCategoryLabel(cat)}: R$ ${val.toFixed(2)}`).join(', ')}
Mês anterior: ${Object.entries(prevCategoryTotals).map(([cat, val]) => `${getCategoryLabel(cat)}: R$ ${val.toFixed(2)}`).join(', ')}

ANÁLISE REQUERIDA:
1. DETECÇÃO PROATIVA: Identifique gastos INCOMUNS ou PICOS anormais comparando com o mês anterior (variação >30%)
2. OTIMIZAÇÃO DE ORÇAMENTO: Sugira ajustes baseados nas tendências e metas do usuário
3. PROJEÇÃO: Calcule onde o usuário estará em 3-6 meses se continuar assim
4. ALERTAS INTELIGENTES: Avise sobre categorias fora de controle ou riscos

Gere 3 a 5 insights. Cada insight deve ter:
- type: "tip" (dica de economia), "alert" (alerta crítico), "achievement" (conquista), ou "pattern" (padrão identificado)
- title: título curto e impactante
- message: explicação clara e ACIONÁVEL em até 2 frases
- priority: "low", "medium" ou "high"
- category: categoria relacionada (se aplicável)
- potential_savings: valor numérico de economia potencial (se aplicável, senão 0)

Seja ESPECÍFICO com números e percentuais. Inclua PROJEÇÕES quando relevante.
`;

    const response = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          insights: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                type: { type: 'string' },
                title: { type: 'string' },
                message: { type: 'string' },
                priority: { type: 'string' },
                category: { type: 'string' },
                potential_savings: { type: 'number' }
              }
            }
          }
        }
      }
    });

    // Save insights
    for (const insight of response.insights || []) {
      await createInsight.mutateAsync({
        ...insight,
        month: format(currentDate, 'yyyy-MM'),
        is_read: false,
      });
    }

    setIsGenerating(false);
  };

  const unreadInsights = insights.filter(i => !i.is_read);
  const readInsights = insights.filter(i => i.is_read);

  const insightCounts = {
    tip: insights.filter(i => i.type === 'tip').length,
    alert: insights.filter(i => i.type === 'alert').length,
    achievement: insights.filter(i => i.type === 'achievement').length,
    pattern: insights.filter(i => i.type === 'pattern').length,
  };

  if (!isPremium) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white p-8 rounded-3xl shadow-lg text-center max-w-md"
        >
          <div className="h-16 w-16 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 flex items-center justify-center mx-auto mb-4">
            <Sparkles className="h-8 w-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Insights com IA</h2>
          <p className="text-slate-500 mb-6">
            Desbloqueie análises inteligentes dos seus hábitos financeiros e receba dicas personalizadas para economizar.
          </p>
          <Link to={createPageUrl('Premium')}>
            <Button className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700">
              <Lock className="h-4 w-4 mr-2" />
              Desbloquear Premium
            </Button>
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-40">
      {/* Header */}
      <div className="bg-white px-6 pt-6 pb-4 sticky top-0 z-20 shadow-sm">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <Link to={createPageUrl('Home')}>
              <button className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                <ArrowLeft className="h-5 w-5 text-slate-600" />
              </button>
            </Link>
            <Sparkles className="h-5 w-5 text-violet-500" />
            <h1 className="text-xl font-bold text-slate-800">Insights IA</h1>
          </div>
          <PremiumBadge />
        </div>
        <p className="text-sm text-slate-500">
          Análises personalizadas da sua vida financeira
        </p>
      </div>

      {/* Generate Button */}
      <div className="px-6 mt-4">
        <Button
          onClick={generateInsights}
          disabled={isGenerating}
          className="w-full h-14 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 rounded-2xl text-base font-semibold"
        >
          {isGenerating ? (
            <>
              <RefreshCw className="h-5 w-5 mr-2 animate-spin" />
              Analisando seus dados...
            </>
          ) : (
            <>
              <Sparkles className="h-5 w-5 mr-2" />
              Gerar Novos Insights
            </>
          )}
        </Button>
      </div>

      {/* Stats */}
      <div className="px-6 mt-4 grid grid-cols-4 gap-2">
        <div className="bg-amber-50 p-3 rounded-xl text-center">
          <Lightbulb className="h-5 w-5 text-amber-500 mx-auto mb-1" />
          <p className="text-lg font-bold text-amber-700">{insightCounts.tip}</p>
          <p className="text-[10px] text-amber-600">Dicas</p>
        </div>
        <div className="bg-red-50 p-3 rounded-xl text-center">
          <AlertCircle className="h-5 w-5 text-red-500 mx-auto mb-1" />
          <p className="text-lg font-bold text-red-700">{insightCounts.alert}</p>
          <p className="text-[10px] text-red-600">Alertas</p>
        </div>
        <div className="bg-emerald-50 p-3 rounded-xl text-center">
          <Trophy className="h-5 w-5 text-emerald-500 mx-auto mb-1" />
          <p className="text-lg font-bold text-emerald-700">{insightCounts.achievement}</p>
          <p className="text-[10px] text-emerald-600">Conquistas</p>
        </div>
        <div className="bg-blue-50 p-3 rounded-xl text-center">
          <TrendingUp className="h-5 w-5 text-blue-500 mx-auto mb-1" />
          <p className="text-lg font-bold text-blue-700">{insightCounts.pattern}</p>
          <p className="text-[10px] text-blue-600">Padrões</p>
        </div>
      </div>

      {/* Insights List */}
      <div className="px-6 mt-6">
        <Tabs defaultValue="new" className="w-full">
          <TabsList className="w-full bg-slate-100 rounded-xl p-1">
            <TabsTrigger value="new" className="flex-1 rounded-lg">
              Novos ({unreadInsights.length})
            </TabsTrigger>
            <TabsTrigger value="read" className="flex-1 rounded-lg">
              <CheckCircle2 className="h-4 w-4 mr-1" />
              Lidos ({readInsights.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="new" className="mt-4">
            {isLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-24 bg-white rounded-2xl animate-pulse" />
                ))}
              </div>
            ) : unreadInsights.length === 0 ? (
              <EmptyState
                icon={Sparkles}
                title="Nenhum insight novo"
                description="Clique em 'Gerar Novos Insights' para analisar seus dados"
              />
            ) : (
              <div className="space-y-3">
                <AnimatePresence>
                  {unreadInsights.map((insight) => (
                    <InsightCard
                      key={insight.id}
                      insight={insight}
                      onDismiss={() => dismissInsight.mutate(insight.id)}
                    />
                  ))}
                </AnimatePresence>
              </div>
            )}
          </TabsContent>

          <TabsContent value="read" className="mt-4">
            {readInsights.length === 0 ? (
              <EmptyState
                icon={CheckCircle2}
                title="Nenhum insight lido"
                description="Os insights que você marcar como lidos aparecerão aqui"
              />
            ) : (
              <div className="space-y-3 opacity-60">
                {readInsights.map((insight) => (
                  <InsightCard key={insight.id} insight={insight} />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}