import Layout from "./Layout.jsx";

import Accounts from "./Accounts";

import AdminPayments from "./AdminPayments";

import Analytics from "./Analytics";

import BankIntegration from "./BankIntegration";

import Budgets from "./Budgets";

import Cards from "./Cards";

import Checkout from "./Checkout";

import FinancialChat from "./FinancialChat";

import Home from "./Home";

import Insights from "./Insights";

import Notifications from "./Notifications";

import Premium from "./Premium";

import Projections from "./Projections";

import Reports from "./Reports";

import Settings from "./Settings";

import Transactions from "./Transactions";

import Wallet from "./Wallet";

import Register from "./Register";

import Auth from "./Auth";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Accounts: Accounts,
    
    AdminPayments: AdminPayments,
    
    Analytics: Analytics,
    
    BankIntegration: BankIntegration,
    
    Budgets: Budgets,
    
    Cards: Cards,
    
    Checkout: Checkout,
    
    FinancialChat: FinancialChat,
    
    Home: Home,
    
    Insights: Insights,
    
    Notifications: Notifications,
    
    Premium: Premium,
    
    Projections: Projections,
    
    Reports: Reports,
    
    Settings: Settings,
    
    Transactions: Transactions,
    
    Wallet: Wallet,
    
    Register: Register,
    
    Auth: Auth,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Accounts />} />
                
                
                <Route path="/Accounts" element={<Accounts />} />
                
                <Route path="/AdminPayments" element={<AdminPayments />} />
                
                <Route path="/Analytics" element={<Analytics />} />
                
                <Route path="/BankIntegration" element={<BankIntegration />} />
                
                <Route path="/Budgets" element={<Budgets />} />
                
                <Route path="/Cards" element={<Cards />} />
                
                <Route path="/Checkout" element={<Checkout />} />
                
                <Route path="/FinancialChat" element={<FinancialChat />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/Insights" element={<Insights />} />
                
                <Route path="/Notifications" element={<Notifications />} />
                
                <Route path="/Premium" element={<Premium />} />
                
                <Route path="/Projections" element={<Projections />} />
                
                <Route path="/Reports" element={<Reports />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/Transactions" element={<Transactions />} />
                
                <Route path="/Wallet" element={<Wallet />} />
                
                <Route path="/Register" element={<Register />} />
                
                <Route path="/Auth" element={<Auth />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}