import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Plus, 
  Smartphone, 
  Shield, 
  RefreshCw,
  Check,
  AlertCircle,
  Link as LinkIcon,
  Unlink,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import BankConnectionCard from '@/components/bank/BankConnectionCard';
import ConnectBankModal from '@/components/bank/ConnectBankModal';
import EmptyState from '@/components/ui/EmptyState';

export default function BankIntegration() {
  const [showConnectModal, setShowConnectModal] = useState(false);
  const queryClient = useQueryClient();

  const { data: connections = [], isLoading } = useQuery({
    queryKey: ['bank-connections'],
    queryFn: () => base44.entities.BankConnection.list('-created_date', 50),
  });

  const { data: bankAccounts = [] } = useQuery({
    queryKey: ['bankAccounts'],
    queryFn: () => base44.entities.BankAccount.filter({ is_active: true }),
  });

  const toggleConnectionMutation = useMutation({
    mutationFn: ({ id, isActive }) => 
      base44.entities.BankConnection.update(id, { is_active: !isActive }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bank-connections'] });
    },
  });

  const syncMutation = useMutation({
    mutationFn: async (connectionId) => {
      const response = await base44.functions.invoke('syncTransactions', { connectionId });
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      queryClient.invalidateQueries({ queryKey: ['bank-connections'] });
    },
  });

  const deleteConnectionMutation = useMutation({
    mutationFn: (id) => base44.entities.BankConnection.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bank-connections'] });
    },
  });

  const activeConnections = connections.filter(c => c.is_active);
  const inactiveConnections = connections.filter(c => !c.is_active);

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-br from-emerald-500 to-teal-600 px-6 pt-6 pb-8">
        <div className="flex items-center gap-4 mb-6">
          <Link to={createPageUrl('Settings')}>
            <button className="p-2 hover:bg-white/10 rounded-full transition-colors">
              <ArrowLeft className="h-5 w-5 text-white" />
            </button>
          </Link>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-white">Integração Bancária</h1>
            <p className="text-sm text-white/80">Open Finance Brasil</p>
          </div>
        </div>

        {/* Info Cards */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white/10 backdrop-blur-sm p-3 rounded-xl">
            <div className="flex items-center gap-2 mb-1">
              <Shield className="h-4 w-4 text-white" />
              <span className="text-xs text-white/80">Seguro</span>
            </div>
            <p className="text-sm font-semibold text-white">Criptografia End-to-End</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm p-3 rounded-xl">
            <div className="flex items-center gap-2 mb-1">
              <RefreshCw className="h-4 w-4 text-white" />
              <span className="text-xs text-white/80">Automático</span>
            </div>
            <p className="text-sm font-semibold text-white">Sync Diária</p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 -mt-4">
        {/* How it works */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-blue-50 border border-blue-200 p-4 rounded-2xl mb-6"
        >
          <div className="flex items-start gap-3">
            <div className="h-8 w-8 rounded-lg bg-blue-500 flex items-center justify-center flex-shrink-0">
              <Smartphone className="h-4 w-4 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-blue-900 mb-1">Como Funciona</h3>
              <p className="text-sm text-blue-700">
                Conecte suas contas bancárias via Open Finance para importar transações automaticamente.
                Seus dados são protegidos por criptografia e você controla tudo.
              </p>
            </div>
          </div>
        </motion.div>

        {/* Add Connection Button */}
        <Button
          onClick={() => setShowConnectModal(true)}
          className="w-full mb-6 bg-emerald-500 hover:bg-emerald-600 h-12"
        >
          <Plus className="h-5 w-5 mr-2" />
          Conectar Nova Conta
        </Button>

        {/* Active Connections */}
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2].map((i) => (
              <div key={i} className="bg-white p-4 rounded-2xl animate-pulse">
                <div className="h-4 bg-slate-200 rounded w-3/4 mb-2" />
                <div className="h-3 bg-slate-200 rounded w-1/2" />
              </div>
            ))}
          </div>
        ) : activeConnections.length === 0 ? (
          <EmptyState
            icon={LinkIcon}
            title="Nenhuma Conexão Ativa"
            description="Conecte suas contas bancárias para importar transações automaticamente"
            actionLabel="Conectar Conta"
            onAction={() => setShowConnectModal(true)}
          />
        ) : (
          <>
            <h3 className="font-semibold text-slate-800 mb-3">Conexões Ativas</h3>
            <div className="space-y-3 mb-6">
              {activeConnections.map((connection) => (
                <BankConnectionCard
                  key={connection.id}
                  connection={connection}
                  onToggle={() => toggleConnectionMutation.mutate({ 
                    id: connection.id, 
                    isActive: connection.is_active 
                  })}
                  onSync={() => syncMutation.mutate(connection.id)}
                  onDelete={() => deleteConnectionMutation.mutate(connection.id)}
                  isSyncing={syncMutation.isPending}
                />
              ))}
            </div>
          </>
        )}

        {/* Inactive Connections */}
        {inactiveConnections.length > 0 && (
          <>
            <h3 className="font-semibold text-slate-800 mb-3 mt-6">Conexões Inativas</h3>
            <div className="space-y-3">
              {inactiveConnections.map((connection) => (
                <BankConnectionCard
                  key={connection.id}
                  connection={connection}
                  onToggle={() => toggleConnectionMutation.mutate({ 
                    id: connection.id, 
                    isActive: connection.is_active 
                  })}
                  onDelete={() => deleteConnectionMutation.mutate(connection.id)}
                />
              ))}
            </div>
          </>
        )}

        {/* Security Notice */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="bg-slate-100 p-4 rounded-2xl mt-6"
        >
          <div className="flex items-start gap-3">
            <Shield className="h-5 w-5 text-slate-500 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-medium text-slate-800 mb-1">Seus Dados Estão Seguros</h4>
              <p className="text-sm text-slate-600">
                Utilizamos o Open Finance Brasil, regulado pelo Banco Central. 
                Seus dados são criptografados e você pode revogar o acesso a qualquer momento.
              </p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Connect Modal */}
      {showConnectModal && (
        <ConnectBankModal
          onClose={() => setShowConnectModal(false)}
          bankAccounts={bankAccounts}
        />
      )}
    </div>
  );
}