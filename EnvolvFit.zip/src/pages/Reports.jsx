import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { format, startOfMonth, endOfMonth, subMonths } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { 
  FileText, 
  Lock,
  Download,
  Calendar,
  Filter,
  CheckCircle2,
  Loader2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import PremiumBadge from '@/components/ui/PremiumBadge';
import { getCategoryLabel } from '@/components/ui/CategoryIcon';

export default function Reports() {
  const [user, setUser] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [periodType, setPeriodType] = useState('monthly'); // monthly, quarterly, yearly
  const [selectedMonth, setSelectedMonth] = useState(format(new Date(), 'yyyy-MM'));
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [includeCharts, setIncludeCharts] = useState(true);
  const [includeInsights, setIncludeInsights] = useState(true);
  const [includeComparison, setIncludeComparison] = useState(true);

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  const isPremium = user?.plan === 'premium';

  const categories = [
    'food', 'transport', 'housing', 'utilities', 'health',
    'education', 'entertainment', 'shopping', 'travel', 
    'subscriptions', 'other_expense'
  ];

  const getDateRange = () => {
    const [year, month] = selectedMonth.split('-');
    const date = new Date(parseInt(year), parseInt(month) - 1, 1);
    
    if (periodType === 'monthly') {
      return {
        start: format(startOfMonth(date), 'yyyy-MM-dd'),
        end: format(endOfMonth(date), 'yyyy-MM-dd'),
      };
    } else if (periodType === 'quarterly') {
      const quarterStart = new Date(date);
      quarterStart.setMonth(Math.floor(date.getMonth() / 3) * 3);
      const quarterEnd = new Date(quarterStart);
      quarterEnd.setMonth(quarterStart.getMonth() + 3);
      quarterEnd.setDate(0);
      return {
        start: format(startOfMonth(quarterStart), 'yyyy-MM-dd'),
        end: format(endOfMonth(quarterEnd), 'yyyy-MM-dd'),
      };
    } else { // yearly
      const yearStart = new Date(date.getFullYear(), 0, 1);
      const yearEnd = new Date(date.getFullYear(), 11, 31);
      return {
        start: format(yearStart, 'yyyy-MM-dd'),
        end: format(yearEnd, 'yyyy-MM-dd'),
      };
    }
  };

  const monthOptions = Array.from({ length: 12 }, (_, i) => {
    const date = subMonths(new Date(), i);
    return {
      value: format(date, 'yyyy-MM'),
      label: format(date, "MMMM 'de' yyyy", { locale: ptBR }),
    };
  });

  const { data: transactions = [] } = useQuery({
    queryKey: ['transactions', selectedMonth, periodType, selectedCategories],
    queryFn: async () => {
      const { start, end } = getDateRange();
      
      let filters = { date: { $gte: start, $lte: end } };
      
      // Apply category filter
      if (selectedCategories.length > 0) {
        filters.category = { $in: selectedCategories };
      }
      
      return base44.entities.Transaction.filter(filters, '-date', 1000);
    },
    enabled: isPremium,
  });

  const generatePDF = async () => {
    setIsGenerating(true);

    try {
      const { start, end } = getDateRange();
      
      // Calculate totals
      const totals = transactions.reduce(
        (acc, t) => {
          if (t.type === 'income') acc.income += t.amount || 0;
          else acc.expenses += t.amount || 0;
          return acc;
        },
        { income: 0, expenses: 0 }
      );

      const categoryTotals = transactions
        .filter(t => t.type === 'expense')
        .reduce((acc, t) => {
          acc[t.category] = (acc[t.category] || 0) + (t.amount || 0);
          return acc;
        }, {});

      // Group by month for comparison
      const monthlyData = {};
      transactions.forEach(t => {
        const monthKey = format(new Date(t.date), 'MMM/yy', { locale: ptBR });
        if (!monthlyData[monthKey]) {
          monthlyData[monthKey] = { income: 0, expenses: 0 };
        }
        if (t.type === 'income') monthlyData[monthKey].income += t.amount || 0;
        else monthlyData[monthKey].expenses += t.amount || 0;
      });

      const periodLabel = periodType === 'monthly' 
        ? format(new Date(selectedMonth), "MMMM 'de' yyyy", { locale: ptBR })
        : periodType === 'quarterly'
        ? `Trimestre de ${format(new Date(start), "MMMM", { locale: ptBR })} a ${format(new Date(end), "MMMM 'de' yyyy", { locale: ptBR })}`
        : `Ano de ${format(new Date(start), "yyyy")}`;

      // Generate AI report if enabled
      const reportContent = includeInsights ? await base44.integrations.Core.InvokeLLM({
        prompt: `Crie um relatório financeiro DETALHADO e PROFISSIONAL para o período: ${periodLabel}.

DADOS FINANCEIROS:
- Receitas totais: R$ ${totals.income.toFixed(2)}
- Despesas totais: R$ ${totals.expenses.toFixed(2)}
- Saldo final: R$ ${(totals.income - totals.expenses).toFixed(2)}
- Total de transações: ${transactions.length}
- Taxa de economia: ${totals.income > 0 ? ((totals.income - totals.expenses) / totals.income * 100).toFixed(1) : 0}%

DISTRIBUIÇÃO MENSAL:
${Object.entries(monthlyData).map(([month, data]) => 
  `${month}: Receitas R$ ${data.income.toFixed(2)}, Despesas R$ ${data.expenses.toFixed(2)}, Saldo R$ ${(data.income - data.expenses).toFixed(2)}`
).join('\n')}

GASTOS POR CATEGORIA:
${Object.entries(categoryTotals).map(([cat, val]) => `${getCategoryLabel(cat)}: R$ ${val.toFixed(2)} (${totals.expenses > 0 ? ((val / totals.expenses) * 100).toFixed(1) : 0}%)`).join('\n')}

FORNEÇA:
1. Resumo Executivo (3-4 frases sobre desempenho geral)
2. Análise de Receitas (tendências e observações)
3. Análise de Despesas (principais categorias e padrões)
4. Principais Destaques (4-5 pontos importantes)
5. Recomendações Estratégicas (3 ações concretas)

Seja profissional, analítico e forneça insights ACIONÁVEIS.`,
      }) : null;

      // Generate HTML for charts if enabled
      const chartHTML = includeCharts ? `
<div style="page-break-inside: avoid; margin: 20px 0;">
  <h3>Distribuição de Gastos por Categoria</h3>
  ${Object.entries(categoryTotals).map(([cat, val]) => `
    <div style="margin: 10px 0;">
      <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
        <span>${getCategoryLabel(cat)}</span>
        <span>${formatCurrency(val)} (${totals.expenses > 0 ? ((val / totals.expenses) * 100).toFixed(1) : 0}%)</span>
      </div>
      <div style="background: #e2e8f0; height: 8px; border-radius: 4px; overflow: hidden;">
        <div style="background: linear-gradient(to right, #8b5cf6, #6366f1); height: 100%; width: ${totals.expenses > 0 ? ((val / totals.expenses) * 100) : 0}%;"></div>
      </div>
    </div>
  `).join('')}
</div>

${includeComparison && Object.keys(monthlyData).length > 1 ? `
<div style="page-break-inside: avoid; margin: 20px 0;">
  <h3>Evolução Mensal</h3>
  <table style="width: 100%; border-collapse: collapse;">
    <thead>
      <tr style="background: #f1f5f9;">
        <th style="padding: 10px; text-align: left; border: 1px solid #e2e8f0;">Mês</th>
        <th style="padding: 10px; text-align: right; border: 1px solid #e2e8f0;">Receitas</th>
        <th style="padding: 10px; text-align: right; border: 1px solid #e2e8f0;">Despesas</th>
        <th style="padding: 10px; text-align: right; border: 1px solid #e2e8f0;">Saldo</th>
      </tr>
    </thead>
    <tbody>
      ${Object.entries(monthlyData).map(([month, data]) => `
        <tr>
          <td style="padding: 10px; border: 1px solid #e2e8f0;">${month}</td>
          <td style="padding: 10px; text-align: right; border: 1px solid #e2e8f0; color: #10b981;">${formatCurrency(data.income)}</td>
          <td style="padding: 10px; text-align: right; border: 1px solid #e2e8f0; color: #ef4444;">${formatCurrency(data.expenses)}</td>
          <td style="padding: 10px; text-align: right; border: 1px solid #e2e8f0; font-weight: bold;">${formatCurrency(data.income - data.expenses)}</td>
        </tr>
      `).join('')}
    </tbody>
  </table>
</div>
` : ''}
      ` : '';

      // Create comprehensive HTML report
      const htmlContent = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Relatório Financeiro Completo - ${periodLabel}</title>
  <style>
    @media print {
      body { padding: 20px; }
      .no-print { display: none; }
      .page-break { page-break-before: always; }
    }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; padding: 40px; max-width: 900px; margin: 0 auto; background: #f8fafc; }
    .container { background: white; padding: 40px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
    h1 { color: #1e293b; border-bottom: 4px solid #8b5cf6; padding-bottom: 15px; font-size: 32px; margin: 0 0 10px 0; }
    h2 { color: #475569; margin-top: 40px; font-size: 24px; border-bottom: 2px solid #e2e8f0; padding-bottom: 8px; }
    h3 { color: #64748b; margin-top: 25px; font-size: 18px; }
    .header-meta { color: #64748b; font-size: 13px; margin-bottom: 30px; }
    .summary { background: linear-gradient(135deg, #8b5cf6, #6366f1); color: white; padding: 35px; border-radius: 16px; margin: 25px 0; box-shadow: 0 8px 16px rgba(139, 92, 246, 0.3); }
    .summary-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 25px; margin-top: 25px; }
    .summary-item { text-align: center; padding: 15px; background: rgba(255,255,255,0.1); border-radius: 12px; }
    .summary-item .label { font-size: 11px; opacity: 0.9; text-transform: uppercase; letter-spacing: 1px; }
    .summary-item .value { font-size: 28px; font-weight: bold; margin-top: 8px; }
    .metrics-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin: 20px 0; }
    .metric { background: #f8fafc; padding: 20px; border-radius: 12px; border-left: 4px solid #8b5cf6; }
    .metric .metric-label { font-size: 12px; color: #64748b; text-transform: uppercase; margin-bottom: 5px; }
    .metric .metric-value { font-size: 20px; font-weight: bold; color: #1e293b; }
    .highlight { background: #fef3c7; padding: 25px; border-radius: 12px; border-left: 4px solid #f59e0b; margin: 20px 0; }
    .highlight h3 { margin-top: 0; color: #92400e; }
    .insight-box { background: linear-gradient(135deg, #fef3c7, #fde68a); padding: 25px; border-radius: 12px; margin: 20px 0; border: 2px solid #f59e0b; }
    .footer { margin-top: 60px; padding-top: 25px; border-top: 2px solid #e2e8f0; text-align: center; color: #64748b; }
    .print-button { background: #8b5cf6; color: white; padding: 12px 24px; border: none; border-radius: 8px; cursor: pointer; font-size: 14px; margin: 20px 0; }
    .print-button:hover { background: #7c3aed; }
  </style>
</head>
<body>
  <button onclick="window.print()" class="print-button no-print">🖨️ Imprimir / Salvar como PDF</button>
  <div class="container">
  <h1>Relatório Financeiro Completo</h1>
  <div class="header-meta">
    <strong>Período:</strong> ${periodLabel}<br>
    <strong>Gerado em:</strong> ${format(new Date(), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}<br>
    <strong>Tipo de Relatório:</strong> ${periodType === 'monthly' ? 'Mensal' : periodType === 'quarterly' ? 'Trimestral' : 'Anual'}
  </div>
  
  <div class="summary">
    <h2 style="color: white; margin: 0 0 10px 0;">Resumo Financeiro</h2>
    <div class="summary-grid">
      <div class="summary-item">
        <div class="label">Receitas</div>
        <div class="value">${formatCurrency(totals.income)}</div>
      </div>
      <div class="summary-item">
        <div class="label">Despesas</div>
        <div class="value">${formatCurrency(totals.expenses)}</div>
      </div>
      <div class="summary-item">
        <div class="label">Saldo</div>
        <div class="value">${formatCurrency(totals.income - totals.expenses)}</div>
      </div>
    </div>
  </div>

  <div class="metrics-grid">
    <div class="metric">
      <div class="metric-label">Total de Transações</div>
      <div class="metric-value">${transactions.length}</div>
    </div>
    <div class="metric">
      <div class="metric-label">Taxa de Poupança</div>
      <div class="metric-value" style="color: ${totals.income > 0 && ((totals.income - totals.expenses) / totals.income * 100) >= 20 ? '#10b981' : '#ef4444'};">
        ${totals.income > 0 ? ((totals.income - totals.expenses) / totals.income * 100).toFixed(1) : 0}%
      </div>
    </div>
    <div class="metric">
      <div class="metric-label">Ticket Médio</div>
      <div class="metric-value">${formatCurrency(transactions.length > 0 ? transactions.reduce((sum, t) => sum + (t.amount || 0), 0) / transactions.length : 0)}</div>
    </div>
    <div class="metric">
      <div class="metric-label">Saldo Final</div>
      <div class="metric-value" style="color: ${totals.income - totals.expenses >= 0 ? '#10b981' : '#ef4444'};">
        ${formatCurrency(totals.income - totals.expenses)}
      </div>
    </div>
  </div>

  ${includeInsights ? `
    <div class="page-break"></div>
    <div class="insight-box">
      <h3 style="margin-top: 0; color: #92400e;">📊 Análise Financeira Inteligente</h3>
      <div style="white-space: pre-line; line-height: 1.8; color: #78350f; font-size: 14px;">${reportContent}</div>
    </div>
  ` : ''}

  ${chartHTML}

  <div class="footer">
    <p style="font-size: 14px; margin-bottom: 10px;"><strong>Relatório Financeiro Premium</strong></p>
    <p>Gerado automaticamente pela plataforma de Controle Financeiro com IA</p>
    <p>Este documento é confidencial e destinado exclusivamente ao uso pessoal</p>
    <p style="margin-top: 15px; font-size: 11px; opacity: 0.7;">
      Para imprimir ou salvar como PDF: Use Ctrl+P (Windows) ou Cmd+P (Mac) e selecione "Salvar como PDF"
    </p>
  </div>
  </div>
</body>
</html>
      `;

      // Download HTML
      const blob = new Blob([htmlContent], { type: 'text/html' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `relatorio-financeiro-${periodType}-${selectedMonth}.html`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();

    } catch (error) {
      console.error('Erro ao gerar relatório:', error);
    }

    setIsGenerating(false);
  };

  if (!isPremium) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white p-8 rounded-3xl shadow-lg text-center max-w-md"
        >
          <div className="h-16 w-16 rounded-2xl bg-gradient-to-r from-violet-500 to-purple-600 flex items-center justify-center mx-auto mb-4">
            <FileText className="h-8 w-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Relatórios Personalizados</h2>
          <p className="text-slate-500 mb-6">
            Gere relatórios detalhados em PDF com filtros avançados, gráficos e análises profissionais das suas finanças.
          </p>
          <Link to={createPageUrl('Premium')}>
            <Button className="w-full bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700">
              <Lock className="h-4 w-4 mr-2" />
              Desbloquear Premium
            </Button>
          </Link>
        </motion.div>
      </div>
    );
  }

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value || 0);
  };

  const totals = transactions.reduce(
    (acc, t) => {
      if (t.type === 'income') acc.income += t.amount || 0;
      else acc.expenses += t.amount || 0;
      return acc;
    },
    { income: 0, expenses: 0 }
  );

  return (
    <div className="min-h-screen bg-slate-50 pb-32">
      {/* Header */}
      <div className="bg-white px-6 pt-6 pb-4 sticky top-0 z-20 shadow-sm">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-violet-500" />
            <h1 className="text-xl font-bold text-slate-800">Relatórios</h1>
          </div>
          <PremiumBadge />
        </div>
        <p className="text-sm text-slate-500">
          Gere relatórios personalizados em PDF
        </p>
      </div>

      <div className="px-6 mt-6 space-y-6">
        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-5 rounded-2xl border border-slate-100 space-y-4"
        >
          <div className="flex items-center gap-2 mb-3">
            <Filter className="h-5 w-5 text-violet-500" />
            <h3 className="font-semibold text-slate-800">Filtros</h3>
          </div>

          {/* Period Type */}
          <div className="space-y-2">
            <Label className="text-slate-700">Tipo de Período</Label>
            <Select value={periodType} onValueChange={setPeriodType}>
              <SelectTrigger className="rounded-xl">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="monthly">Mensal</SelectItem>
                <SelectItem value="quarterly">Trimestral</SelectItem>
                <SelectItem value="yearly">Anual</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Month Selection */}
          <div className="space-y-2">
            <Label className="text-slate-700">
              {periodType === 'monthly' ? 'Mês' : periodType === 'quarterly' ? 'Trimestre' : 'Ano'}
            </Label>
            <Select value={selectedMonth} onValueChange={setSelectedMonth}>
              <SelectTrigger className="rounded-xl">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {monthOptions.map(option => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Category Selection */}
          <div className="space-y-2">
            <Label className="text-slate-700">Categorias (opcional)</Label>
            <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto p-2 bg-slate-50 rounded-xl">
              {categories.map(cat => (
                <div key={cat} className="flex items-center gap-2">
                  <Checkbox
                    id={cat}
                    checked={selectedCategories.includes(cat)}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        setSelectedCategories([...selectedCategories, cat]);
                      } else {
                        setSelectedCategories(selectedCategories.filter(c => c !== cat));
                      }
                    }}
                  />
                  <Label htmlFor={cat} className="text-xs text-slate-600 cursor-pointer">
                    {getCategoryLabel(cat)}
                  </Label>
                </div>
              ))}
            </div>
            {selectedCategories.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedCategories([])}
                className="text-xs"
              >
                Limpar seleção
              </Button>
            )}
          </div>

          {/* Options */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <div className="flex items-center gap-2">
              <Checkbox
                id="charts"
                checked={includeCharts}
                onCheckedChange={setIncludeCharts}
              />
              <Label htmlFor="charts" className="text-sm text-slate-700 cursor-pointer">
                Incluir gráficos e visualizações
              </Label>
            </div>
            <div className="flex items-center gap-2">
              <Checkbox
                id="insights"
                checked={includeInsights}
                onCheckedChange={setIncludeInsights}
              />
              <Label htmlFor="insights" className="text-sm text-slate-700 cursor-pointer">
                Incluir análise detalhada com IA
              </Label>
            </div>
            <div className="flex items-center gap-2">
              <Checkbox
                id="comparison"
                checked={includeComparison}
                onCheckedChange={setIncludeComparison}
              />
              <Label htmlFor="comparison" className="text-sm text-slate-700 cursor-pointer">
                Incluir comparativo mensal
              </Label>
            </div>
          </div>
        </motion.div>

        {/* Preview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white p-5 rounded-2xl border border-slate-100"
        >
          <h3 className="font-semibold text-slate-800 mb-4">Prévia</h3>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center p-3 bg-slate-50 rounded-xl">
              <span className="text-sm text-slate-600">Receitas</span>
              <span className="font-semibold text-emerald-600">{formatCurrency(totals.income)}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-slate-50 rounded-xl">
              <span className="text-sm text-slate-600">Despesas</span>
              <span className="font-semibold text-red-600">{formatCurrency(totals.expenses)}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-slate-50 rounded-xl">
              <span className="text-sm text-slate-600">Saldo</span>
              <span className="font-semibold text-slate-800">
                {formatCurrency(totals.income - totals.expenses)}
              </span>
            </div>
            <div className="flex justify-between items-center p-3 bg-slate-50 rounded-xl">
              <span className="text-sm text-slate-600">Transações</span>
              <span className="font-semibold text-slate-800">{transactions.length}</span>
            </div>
          </div>
        </motion.div>

        {/* Generate Button */}
        <Button
          onClick={generatePDF}
          disabled={isGenerating || transactions.length === 0}
          className="w-full h-14 bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 rounded-2xl text-base font-semibold"
        >
          {isGenerating ? (
            <>
              <Loader2 className="h-5 w-5 mr-2 animate-spin" />
              Gerando relatório...
            </>
          ) : (
            <>
              <Download className="h-5 w-5 mr-2" />
              Gerar Relatório PDF
            </>
          )}
        </Button>

        <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100">
          <p className="text-xs text-blue-700">
            💡 O relatório será gerado em formato HTML interativo com gráficos e análises. 
            Você pode abri-lo em qualquer navegador e convertê-lo para PDF usando a função de impressão (Ctrl+P).
          </p>
        </div>
      </div>
    </div>
  );
}