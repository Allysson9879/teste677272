import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { format, startOfMonth, endOfMonth, addMonths, subMonths } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { 
  TrendingUp, 
  Lock,
  Target,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  Sparkles,
  ArrowLeft,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import PremiumBadge from '@/components/ui/PremiumBadge';

export default function Projections() {
  const [user, setUser] = useState(null);
  const [projectionData, setProjectionData] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  const isPremium = user?.plan === 'premium';

  const currentDate = new Date();

  // Get last 3 months of data
  const { data: last3MonthsData } = useQuery({
    queryKey: ['transactions-history-3months'],
    queryFn: async () => {
      const months = [];
      for (let i = 0; i < 3; i++) {
        const date = subMonths(currentDate, i);
        const start = format(startOfMonth(date), 'yyyy-MM-dd');
        const end = format(endOfMonth(date), 'yyyy-MM-dd');
        
        const transactions = await base44.entities.Transaction.filter({
          date: { $gte: start, $lte: end }
        }, '-date', 500);

        const totals = transactions.reduce(
          (acc, t) => {
            if (t.type === 'income') acc.income += t.amount || 0;
            else acc.expenses += t.amount || 0;
            return acc;
          },
          { income: 0, expenses: 0 }
        );

        months.push({
          month: format(date, 'MMM/yy', { locale: ptBR }),
          ...totals,
          balance: totals.income - totals.expenses,
        });
      }
      return months.reverse();
    },
    enabled: isPremium,
  });

  const generateProjections = async () => {
    if (!isPremium || !last3MonthsData) return;
    
    setIsGenerating(true);

    const avgIncome = last3MonthsData.reduce((sum, m) => sum + m.income, 0) / last3MonthsData.length;
    const avgExpenses = last3MonthsData.reduce((sum, m) => sum + m.expenses, 0) / last3MonthsData.length;
    const avgBalance = avgIncome - avgExpenses;

    const userGoals = {
      monthly_income_goal: user?.monthly_income_goal || 0,
      savings_goal: user?.savings_goal || 0,
    };

    const prompt = `
Você é um especialista em planejamento financeiro. Analise os dados abaixo e crie PROJEÇÕES FINANCEIRAS detalhadas.

HISTÓRICO DOS ÚLTIMOS 3 MESES:
${last3MonthsData.map((m, i) => `Mês ${i + 1}: Receitas R$ ${m.income.toFixed(2)}, Despesas R$ ${m.expenses.toFixed(2)}, Saldo R$ ${m.balance.toFixed(2)}`).join('\n')}

MÉDIAS:
- Receita média: R$ ${avgIncome.toFixed(2)}
- Despesa média: R$ ${avgExpenses.toFixed(2)}
- Saldo médio: R$ ${avgBalance.toFixed(2)}

METAS DO USUÁRIO:
- Meta de receita mensal: R$ ${userGoals.monthly_income_goal.toFixed(2)}
- Meta de economia mensal: R$ ${userGoals.savings_goal.toFixed(2)}

TAREFA: Crie projeções para os próximos 6 meses considerando:
1. Tendência atual de receitas e despesas
2. Metas do usuário
3. Cenários: otimista (melhora 10%), realista (mantém), pessimista (piora 10%)

Para cada mês projetado, forneça:
- projected_income (numérico)
- projected_expenses (numérico)
- projected_balance (numérico)
- month_name (string, ex: "Jan/25")

Além disso, forneça:
- summary: resumo da análise em 2-3 frases
- goal_achievement_probability: probabilidade de atingir metas (0-100)
- recommendations: array com 3 recomendações práticas (strings)
- risks: array com 2 principais riscos identificados (strings)
- opportunities: array com 2 oportunidades de melhoria (strings)
`;

    const response = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          projections: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                month_name: { type: 'string' },
                projected_income: { type: 'number' },
                projected_expenses: { type: 'number' },
                projected_balance: { type: 'number' }
              }
            }
          },
          summary: { type: 'string' },
          goal_achievement_probability: { type: 'number' },
          recommendations: { type: 'array', items: { type: 'string' } },
          risks: { type: 'array', items: { type: 'string' } },
          opportunities: { type: 'array', items: { type: 'string' } }
        }
      }
    });

    setProjectionData(response);
    setIsGenerating(false);
  };

  if (!isPremium) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white p-8 rounded-3xl shadow-lg text-center max-w-md"
        >
          <div className="h-16 w-16 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 flex items-center justify-center mx-auto mb-4">
            <TrendingUp className="h-8 w-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Projeções Financeiras</h2>
          <p className="text-slate-500 mb-6">
            Veja para onde suas finanças estão indo nos próximos 6 meses e receba recomendações personalizadas para alcançar suas metas.
          </p>
          <Link to={createPageUrl('Premium')}>
            <Button className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700">
              <Lock className="h-4 w-4 mr-2" />
              Desbloquear Premium
            </Button>
          </Link>
        </motion.div>
      </div>
    );
  }

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value || 0);
  };

  const chartData = last3MonthsData && projectionData 
    ? [...last3MonthsData.map(m => ({ ...m, type: 'real' })), ...projectionData.projections.map(p => ({
        month: p.month_name,
        income: p.projected_income,
        expenses: p.projected_expenses,
        balance: p.projected_balance,
        type: 'projecao'
      }))]
    : [];

  return (
    <div className="min-h-screen bg-slate-50 pb-40">
      {/* Header */}
      <div className="bg-white px-6 pt-6 pb-4 sticky top-0 z-20 shadow-sm">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <Link to={createPageUrl('Home')}>
              <button className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                <ArrowLeft className="h-5 w-5 text-slate-600" />
              </button>
            </Link>
            <TrendingUp className="h-5 w-5 text-violet-500" />
            <h1 className="text-xl font-bold text-slate-800">Projeções</h1>
          </div>
          <PremiumBadge />
        </div>
        <p className="text-sm text-slate-500">
          Planejamento financeiro dos próximos 6 meses
        </p>
      </div>

      {/* Generate Button */}
      <div className="px-6 mt-4">
        <Button
          onClick={generateProjections}
          disabled={isGenerating || !last3MonthsData}
          className="w-full h-14 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 rounded-2xl text-base font-semibold"
        >
          {isGenerating ? (
            <>
              <Sparkles className="h-5 w-5 mr-2 animate-spin" />
              Gerando projeções...
            </>
          ) : (
            <>
              <Sparkles className="h-5 w-5 mr-2" />
              Gerar Projeções
            </>
          )}
        </Button>
      </div>

      {projectionData && (
        <div className="px-6 mt-6 space-y-6">
          {/* Summary */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white p-5 rounded-2xl border border-slate-100"
          >
            <div className="flex items-center gap-2 mb-3">
              <Calendar className="h-5 w-5 text-violet-500" />
              <h3 className="font-semibold text-slate-800">Análise</h3>
            </div>
            <p className="text-sm text-slate-600 leading-relaxed">
              {projectionData.summary}
            </p>
          </motion.div>

          {/* Goal Achievement */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-gradient-to-r from-emerald-500 to-teal-600 p-5 rounded-2xl text-white"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                <span className="font-semibold">Probabilidade de Atingir Metas</span>
              </div>
            </div>
            <p className="text-4xl font-bold mb-1">
              {projectionData.goal_achievement_probability}%
            </p>
            <p className="text-sm opacity-80">
              {projectionData.goal_achievement_probability >= 70 ? 'Excelente!' : projectionData.goal_achievement_probability >= 50 ? 'Bom progresso' : 'Atenção necessária'}
            </p>
          </motion.div>

          {/* Chart */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white p-5 rounded-2xl border border-slate-100"
          >
            <h3 className="font-semibold text-slate-800 mb-4">Projeção de 6 Meses</h3>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip
                  contentStyle={{ borderRadius: 12, border: 'none', boxShadow: '0 4px 6px rgba(0,0,0,0.1)' }}
                  formatter={(value) => formatCurrency(value)}
                />
                <Legend />
                <Line type="monotone" dataKey="income" stroke="#10b981" strokeWidth={2} name="Receitas" />
                <Line type="monotone" dataKey="expenses" stroke="#ef4444" strokeWidth={2} name="Despesas" />
                <Line type="monotone" dataKey="balance" stroke="#8b5cf6" strokeWidth={2} name="Saldo" strokeDasharray="5 5" />
              </LineChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Recommendations */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white p-5 rounded-2xl border border-slate-100"
          >
            <div className="flex items-center gap-2 mb-3">
              <CheckCircle2 className="h-5 w-5 text-emerald-500" />
              <h3 className="font-semibold text-slate-800">Recomendações</h3>
            </div>
            <ul className="space-y-2">
              {projectionData.recommendations.map((rec, index) => (
                <li key={index} className="flex items-start gap-2 text-sm text-slate-600">
                  <span className="text-emerald-500 mt-0.5">•</span>
                  <span>{rec}</span>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Risks */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white p-5 rounded-2xl border border-slate-100"
          >
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle className="h-5 w-5 text-amber-500" />
              <h3 className="font-semibold text-slate-800">Riscos Identificados</h3>
            </div>
            <ul className="space-y-2">
              {projectionData.risks.map((risk, index) => (
                <li key={index} className="flex items-start gap-2 text-sm text-slate-600">
                  <span className="text-amber-500 mt-0.5">⚠</span>
                  <span>{risk}</span>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Opportunities */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-white p-5 rounded-2xl border border-slate-100"
          >
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="h-5 w-5 text-violet-500" />
              <h3 className="font-semibold text-slate-800">Oportunidades</h3>
            </div>
            <ul className="space-y-2">
              {projectionData.opportunities.map((opp, index) => (
                <li key={index} className="flex items-start gap-2 text-sm text-slate-600">
                  <span className="text-violet-500 mt-0.5">✨</span>
                  <span>{opp}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>
      )}
    </div>
  );
}