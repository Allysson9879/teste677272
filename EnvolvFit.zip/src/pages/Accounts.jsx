import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Building2, MoreVertical, Edit2, Trash2, Eye, EyeOff, TrendingUp, TrendingDown, Wallet, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import AccountCard from '@/components/accounts/AccountCard';
import BankAccountForm from '@/components/forms/BankAccountForm';
import EmptyState from '@/components/ui/EmptyState';
import { format, startOfMonth, endOfMonth } from 'date-fns';

export default function Accounts() {
  const [showForm, setShowForm] = useState(false);
  const [editingAccount, setEditingAccount] = useState(null);
  const [deletingAccount, setDeletingAccount] = useState(null);
  const [selectedAccount, setSelectedAccount] = useState(null);

  const queryClient = useQueryClient();

  const { data: accounts = [] } = useQuery({
    queryKey: ['bankAccounts'],
    queryFn: () => base44.entities.BankAccount.list('-created_date', 50),
  });

  const currentMonth = format(new Date(), 'yyyy-MM');
  const startDate = format(startOfMonth(new Date()), 'yyyy-MM-dd');
  const endDate = format(endOfMonth(new Date()), 'yyyy-MM-dd');

  const { data: transactions = [] } = useQuery({
    queryKey: ['transactions', currentMonth],
    queryFn: () => base44.entities.Transaction.filter({
      date: { $gte: startDate, $lte: endDate }
    }, '-date', 500),
  });

  const createAccountMutation = useMutation({
    mutationFn: (data) => base44.entities.BankAccount.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['bankAccounts']);
      setShowForm(false);
      setEditingAccount(null);
    },
  });

  const updateAccountMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.BankAccount.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['bankAccounts']);
      setShowForm(false);
      setEditingAccount(null);
    },
  });

  const deleteAccountMutation = useMutation({
    mutationFn: (id) => base44.entities.BankAccount.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['bankAccounts']);
      setDeletingAccount(null);
    },
  });

  const handleSubmit = (data) => {
    if (editingAccount) {
      updateAccountMutation.mutate({ id: editingAccount.id, data });
    } else {
      createAccountMutation.mutate(data);
    }
  };

  const handleEdit = (account) => {
    setEditingAccount(account);
    setShowForm(true);
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value || 0);
  };

  // Calculate account balance
  const getAccountBalance = (accountId) => {
    const account = accounts.find(a => a.id === accountId);
    if (!account) return 0;

    const accountTransactions = transactions.filter(t => t.bank_account_id === accountId);
    const transactionTotal = accountTransactions.reduce((sum, t) => {
      return sum + (t.type === 'income' ? t.amount : -t.amount);
    }, 0);

    return (account.initial_balance || 0) + transactionTotal;
  };

  const activeAccounts = accounts.filter(a => a.is_active);
  const totalBalance = activeAccounts.reduce((sum, acc) => sum + getAccountBalance(acc.id), 0);

  return (
    <div className="min-h-screen bg-slate-50 pb-40">
      {/* Header */}
      <div className="bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-700 px-6 pt-6 pb-32 text-white">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Link to={createPageUrl('Wallet')}>
              <button className="p-2 hover:bg-white/10 rounded-full transition-colors">
                <ArrowLeft className="h-5 w-5 text-white" />
              </button>
            </Link>
            <h1 className="text-2xl font-bold">Contas Bancárias</h1>
          </div>
          <Button
            onClick={() => {
              setEditingAccount(null);
              setShowForm(true);
            }}
            size="sm"
            className="bg-white/20 hover:bg-white/30 backdrop-blur-sm rounded-full"
          >
            <Plus className="h-4 w-4 mr-2" />
            Adicionar
          </Button>
        </div>

        <p className="text-white/80 text-sm">
          Gerencie suas contas e acompanhe seus saldos
        </p>
      </div>

      {/* Summary Stats */}
      <div className="px-6 -mt-24 mb-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }} 
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl p-6 border border-slate-100 mb-6"
        >
          <p className="text-xs text-slate-500 mb-1">Saldo Total</p>
          <p className="text-3xl font-bold text-slate-800">{formatCurrency(totalBalance)}</p>
          <p className="text-xs text-slate-500 mt-2">{activeAccounts.length} conta(s) ativa(s)</p>
        </motion.div>

        {/* Accounts Carousel */}
        {activeAccounts.length === 0 ? (
          <div className="bg-white rounded-2xl p-8">
            <EmptyState
              icon={Building2}
              title="Nenhuma conta cadastrada"
              description="Adicione suas contas bancárias para controlar seu dinheiro"
              actionLabel="Adicionar Conta"
              onAction={() => setShowForm(true)}
            />
          </div>
        ) : (
          <div className="overflow-x-auto pb-4 -mx-6 px-6 hide-scrollbar">
            <div className="flex gap-4">
              {activeAccounts.map((account) => (
                <div key={account.id} className="flex-shrink-0 w-72">
                  <AccountCard
                    account={account}
                    balance={getAccountBalance(account.id)}
                    onClick={() => setSelectedAccount(selectedAccount?.id === account.id ? null : account)}
                  />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Account Details */}
      <AnimatePresence>
        {selectedAccount && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="px-6 mb-6"
          >
            <div className="bg-white rounded-2xl p-6 border border-slate-100">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-slate-800">Detalhes da Conta</h3>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleEdit(selectedAccount)}>
                      <Edit2 className="h-4 w-4 mr-2" />
                      Editar
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => {
                        updateAccountMutation.mutate({
                          id: selectedAccount.id,
                          data: { ...selectedAccount, is_active: false }
                        });
                        setSelectedAccount(null);
                      }}
                    >
                      <EyeOff className="h-4 w-4 mr-2" />
                      Desativar
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => setDeletingAccount(selectedAccount)}
                      className="text-red-600"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Excluir
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between py-3 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-xl bg-emerald-100 flex items-center justify-center">
                      <Wallet className="h-5 w-5 text-emerald-600" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">Saldo Atual</p>
                      <p className="font-semibold text-slate-800">{formatCurrency(getAccountBalance(selectedAccount.id))}</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between py-3 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-xl bg-blue-100 flex items-center justify-center">
                      <TrendingUp className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">Receitas no Mês</p>
                      <p className="font-semibold text-emerald-600">
                        {formatCurrency(
                          transactions
                            .filter(t => t.bank_account_id === selectedAccount.id && t.type === 'income')
                            .reduce((sum, t) => sum + t.amount, 0)
                        )}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between py-3">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-xl bg-red-100 flex items-center justify-center">
                      <TrendingDown className="h-5 w-5 text-red-600" />
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">Despesas no Mês</p>
                      <p className="font-semibold text-red-600">
                        {formatCurrency(
                          transactions
                            .filter(t => t.bank_account_id === selectedAccount.id && t.type === 'expense')
                            .reduce((sum, t) => sum + t.amount, 0)
                        )}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* All Accounts List */}
      <div className="px-6">
        <h3 className="font-semibold text-slate-800 mb-4">Todas as Contas</h3>
        <div className="space-y-3">
          {accounts.map((account) => (
            <motion.div
              key={account.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`bg-white rounded-2xl p-4 border ${
                account.is_active ? 'border-slate-100' : 'border-slate-200 opacity-60'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4 flex-1">
                  <AccountCard account={account} balance={getAccountBalance(account.id)} onClick={() => setSelectedAccount(account)} isSmall />
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-slate-800 truncate">{account.name}</p>
                    <p className="text-xs text-slate-500">
                      Saldo: {formatCurrency(getAccountBalance(account.id))}
                      {!account.is_active && ' • Desativada'}
                    </p>
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleEdit(account)}>
                      <Edit2 className="h-4 w-4 mr-2" />
                      Editar
                    </DropdownMenuItem>
                    {account.is_active ? (
                      <DropdownMenuItem
                        onClick={() => updateAccountMutation.mutate({
                          id: account.id,
                          data: { ...account, is_active: false }
                        })}
                      >
                        <EyeOff className="h-4 w-4 mr-2" />
                        Desativar
                      </DropdownMenuItem>
                    ) : (
                      <DropdownMenuItem
                        onClick={() => updateAccountMutation.mutate({
                          id: account.id,
                          data: { ...account, is_active: true }
                        })}
                      >
                        <Eye className="h-4 w-4 mr-2" />
                        Ativar
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem
                      onClick={() => setDeletingAccount(account)}
                      className="text-red-600"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Excluir
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Form Modal */}
      <AnimatePresence>
        {showForm && (
          <BankAccountForm
            account={editingAccount}
            onSubmit={handleSubmit}
            onClose={() => {
              setShowForm(false);
              setEditingAccount(null);
            }}
          />
        )}
      </AnimatePresence>

      {/* Delete Dialog */}
      <AlertDialog open={!!deletingAccount} onOpenChange={() => setDeletingAccount(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir conta?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação não pode ser desfeita. A conta será permanentemente excluída.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteAccountMutation.mutate(deletingAccount.id)}
              className="bg-red-600 hover:bg-red-700"
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <style>{`
        .hide-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .hide-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}