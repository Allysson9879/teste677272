import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
  Crown, 
  CheckCircle2, 
  ArrowLeft,
  Clock,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import PixPayment from '@/components/payment/PixPayment';

export default function Checkout() {
  const [user, setUser] = useState(null);
  const [selectedPlan, setSelectedPlan] = useState('yearly');
  const [step, setStep] = useState('plan'); // plan, payment, success
  const [paymentRequestId, setPaymentRequestId] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
      
      // Check if user already has a pending request
      const existingRequests = await base44.entities.PaymentRequest.filter({
        user_email: userData.email,
        status: 'pending'
      });
      
      if (existingRequests.length > 0) {
        setPaymentRequestId(existingRequests[0].id);
        setStep('success');
      }
    };
    loadUser();
  }, []);

  const plans = {
    monthly: {
      name: 'Mensal',
      price: 19.90,
      period: 'mês',
      duration: 30,
    },
    yearly: {
      name: 'Anual',
      price: 118.80,
      period: 'ano',
      duration: 365,
      savings: '50% OFF',
      monthlyEquivalent: 9.90,
    },
  };

  const selectedPlanData = plans[selectedPlan];

  const createPaymentRequest = useMutation({
    mutationFn: async () => {
      // Call backend function to create payment with MercadoPago
      const response = await base44.functions.invoke('createPixPayment', {
        plan_type: selectedPlan,
        amount: selectedPlanData.price,
      });

      return response.data;
    },
  });

  const submitProof = async (file, notes) => {
    // Upload proof file
    const { file_url } = await base44.integrations.Core.UploadFile({ file });

    // Update payment request with proof
    await base44.entities.PaymentRequest.update(paymentRequestId, {
      payment_proof: file_url,
      notes: notes || null,
    });

    setStep('success');
  };

  const [paymentData, setPaymentData] = useState(null);

  const handleContinue = async () => {
    const response = await createPaymentRequest.mutateAsync();
    setPaymentRequestId(response.payment_id);
    setPaymentData(response);
    setStep('payment');
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value || 0);
  };

  if (step === 'success') {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white p-8 rounded-3xl shadow-lg text-center max-w-md w-full"
        >
          <div className="h-16 w-16 rounded-2xl bg-amber-100 flex items-center justify-center mx-auto mb-4">
            <Clock className="h-8 w-8 text-amber-600" />
          </div>
          
          <h2 className="text-2xl font-bold text-slate-800 mb-2">
            Pagamento em Análise
          </h2>
          
          <p className="text-slate-500 mb-6">
            Recebemos seu comprovante! Estamos verificando seu pagamento e você receberá uma confirmação por e-mail em até 24 horas.
          </p>

          <div className="bg-blue-50 p-4 rounded-xl mb-6">
            <p className="text-sm text-blue-700">
              Assim que confirmarmos, seu acesso Premium será liberado automaticamente e você receberá um e-mail de boas-vindas.
            </p>
          </div>

          <Button
            onClick={() => navigate(createPageUrl('Home'))}
            className="w-full bg-emerald-500 hover:bg-emerald-600"
          >
            Voltar ao início
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-32">
      {/* Header */}
      <div className="bg-white px-6 pt-6 pb-4 sticky top-0 z-20 shadow-sm">
        <button
          onClick={() => step === 'payment' ? setStep('plan') : navigate(createPageUrl('Premium'))}
          className="flex items-center gap-2 text-slate-600 hover:text-slate-800 mb-4"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Voltar</span>
        </button>
        
        <div className="flex items-center gap-2">
          <Crown className="h-6 w-6 text-amber-500" />
          <h1 className="text-xl font-bold text-slate-800">Checkout Premium</h1>
        </div>
      </div>

      <div className="px-6 mt-6">
        {step === 'plan' ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h2 className="text-lg font-semibold text-slate-800 mb-4">
              Escolha seu plano
            </h2>

            <div className="space-y-3 mb-6">
              {Object.entries(plans).map(([key, plan]) => (
                <button
                  key={key}
                  onClick={() => setSelectedPlan(key)}
                  className={`w-full p-4 rounded-2xl border-2 transition-all text-left ${
                    selectedPlan === key
                      ? 'border-violet-500 bg-violet-50'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className={`h-5 w-5 rounded-full border-2 flex items-center justify-center ${
                        selectedPlan === key ? 'border-violet-500' : 'border-slate-300'
                      }`}>
                        {selectedPlan === key && (
                          <div className="h-3 w-3 rounded-full bg-violet-500" />
                        )}
                      </div>
                      <span className="font-semibold text-slate-800">{plan.name}</span>
                    </div>
                    {plan.savings && (
                      <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full">
                        {plan.savings}
                      </span>
                    )}
                  </div>
                  
                  <div className="ml-7">
                    <p className="text-2xl font-bold text-slate-800">
                      {formatCurrency(plan.price)}
                    </p>
                    {plan.monthlyEquivalent && (
                      <p className="text-sm text-slate-500">
                        ou {formatCurrency(plan.monthlyEquivalent)}/mês
                      </p>
                    )}
                  </div>
                </button>
              ))}
            </div>

            <div className="bg-slate-100 p-4 rounded-2xl mb-6">
              <h3 className="font-semibold text-slate-800 mb-2">Resumo do pedido</h3>
              <div className="flex justify-between items-center">
                <span className="text-slate-600">Plano {selectedPlanData.name}</span>
                <span className="text-lg font-bold text-slate-800">
                  {formatCurrency(selectedPlanData.price)}
                </span>
              </div>
            </div>

            <Button
              onClick={handleContinue}
              disabled={createPaymentRequest.isPending}
              className="w-full h-14 bg-emerald-500 hover:bg-emerald-600 rounded-2xl text-lg font-semibold"
            >
              {createPaymentRequest.isPending ? 'Processando...' : 'Continuar para pagamento'}
            </Button>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h2 className="text-lg font-semibold text-slate-800 mb-4">
              Pagamento via PIX
            </h2>

            <PixPayment
              amount={selectedPlanData.price}
              planType={selectedPlan}
              paymentData={paymentData}
              onSubmitProof={submitProof}
            />
          </motion.div>
        )}
      </div>
    </div>
  );
}