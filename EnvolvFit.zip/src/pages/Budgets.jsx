import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { format, startOfMonth, endOfMonth } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Plus, Wallet, Trash2, Edit2, MoreVertical, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

import BudgetProgress from '@/components/ui/BudgetProgress';
import BudgetForm from '@/components/forms/BudgetForm';
import EmptyState from '@/components/ui/EmptyState';

export default function Budgets() {
  const [showForm, setShowForm] = useState(false);
  const [editingBudget, setEditingBudget] = useState(null);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const queryClient = useQueryClient();

  const currentDate = new Date();
  const currentMonth = format(currentDate, 'yyyy-MM');
  const startDate = format(startOfMonth(currentDate), 'yyyy-MM-dd');
  const endDate = format(endOfMonth(currentDate), 'yyyy-MM-dd');

  const { data: budgets = [], isLoading } = useQuery({
    queryKey: ['budgets', currentMonth],
    queryFn: () => base44.entities.Budget.filter({ month: currentMonth }),
  });

  const { data: transactions = [] } = useQuery({
    queryKey: ['transactions', startDate, endDate],
    queryFn: () => base44.entities.Transaction.filter({
      date: { $gte: startDate, $lte: endDate },
      type: 'expense'
    }, '-date', 500),
  });

  const createBudget = useMutation({
    mutationFn: (data) => base44.entities.Budget.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['budgets'] });
      setShowForm(false);
    },
  });

  const updateBudget = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Budget.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['budgets'] });
      setEditingBudget(null);
    },
  });

  const deleteBudget = useMutation({
    mutationFn: (id) => base44.entities.Budget.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['budgets'] });
      setDeleteConfirm(null);
    },
  });

  // Calculate spent per category
  const categoryTotals = transactions.reduce((acc, t) => {
    acc[t.category] = (acc[t.category] || 0) + (t.amount || 0);
    return acc;
  }, {});

  const existingCategories = budgets.map(b => b.category);

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value || 0);
  };

  // Calculate totals
  const totalBudget = budgets.reduce((sum, b) => sum + (b.limit || 0), 0);
  const totalSpent = budgets.reduce((sum, b) => sum + (categoryTotals[b.category] || 0), 0);
  const totalRemaining = totalBudget - totalSpent;

  return (
    <div className="min-h-screen bg-slate-50 pb-40">
      {/* Header */}
      <div className="bg-white px-6 pt-6 pb-4 sticky top-0 z-20 shadow-sm">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <Link to={createPageUrl('Home')}>
              <button className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                <ArrowLeft className="h-5 w-5 text-slate-600" />
              </button>
            </Link>
            <h1 className="text-xl font-bold text-slate-800">Orçamentos</h1>
          </div>
          <Button
            onClick={() => setShowForm(true)}
            size="sm"
            className="bg-emerald-500 hover:bg-emerald-600 rounded-xl"
          >
            <Plus className="h-4 w-4 mr-1" />
            Novo
          </Button>
        </div>
        <p className="text-sm text-slate-500 capitalize">
          {format(currentDate, "MMMM 'de' yyyy", { locale: ptBR })}
        </p>
      </div>

      {/* Summary */}
      {budgets.length > 0 && (
        <div className="px-6 mt-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-r from-emerald-500 to-teal-600 p-6 rounded-2xl text-white"
          >
            <div className="flex items-center gap-2 mb-4">
              <Wallet className="h-5 w-5" />
              <span className="font-semibold">Resumo de Orçamentos</span>
            </div>
            
            <div className="grid grid-cols-3 gap-4">
              <div>
                <p className="text-xs opacity-70">Orçamento</p>
                <p className="text-lg font-bold">{formatCurrency(totalBudget)}</p>
              </div>
              <div>
                <p className="text-xs opacity-70">Gasto</p>
                <p className="text-lg font-bold">{formatCurrency(totalSpent)}</p>
                <p className="text-xs opacity-70 mt-1">
                  {totalBudget > 0 ? ((totalSpent / totalBudget) * 100).toFixed(0) : 0}% usado
                </p>
              </div>
              <div>
                <p className="text-xs opacity-70">Disponível</p>
                <p className={`text-lg font-bold ${totalRemaining < 0 ? 'text-red-200' : ''}`}>
                  {formatCurrency(Math.max(0, totalRemaining))}
                </p>
                {totalRemaining < 0 && (
                  <p className="text-xs text-red-200 mt-1">
                    ⚠️ {formatCurrency(Math.abs(totalRemaining))} acima
                  </p>
                )}
              </div>
            </div>

            <div className="mt-4 h-2 bg-white/20 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${Math.min((totalSpent / totalBudget) * 100, 100)}%` }}
                transition={{ duration: 0.5 }}
                className={`h-full rounded-full ${
                  totalSpent > totalBudget ? 'bg-red-400' : 'bg-white'
                }`}
              />
            </div>
          </motion.div>
        </div>
      )}

      {/* Budgets List */}
      <div className="px-6 mt-6">
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-24 bg-white rounded-2xl animate-pulse" />
            ))}
          </div>
        ) : budgets.length === 0 ? (
          <EmptyState
            icon={Wallet}
            title="Nenhum orçamento"
            description="Crie orçamentos para controlar seus gastos por categoria"
            actionLabel="Criar orçamento"
            onAction={() => setShowForm(true)}
          />
        ) : (
          <div className="space-y-3">
            {budgets.map((budget) => (
              <div key={budget.id} className="relative group">
                <BudgetProgress
                  budget={budget}
                  spent={categoryTotals[budget.category] || 0}
                />
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button className="absolute right-4 top-4 p-2 rounded-full opacity-0 group-hover:opacity-100 hover:bg-slate-100 transition-all">
                      <MoreVertical className="h-4 w-4 text-slate-400" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => setEditingBudget(budget)}>
                      <Edit2 className="h-4 w-4 mr-2" />
                      Editar
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={() => setDeleteConfirm(budget)}
                      className="text-red-600"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Excluir
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Tips */}
      <div className="px-6 mt-6">
        <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100">
          <h4 className="font-semibold text-blue-800 mb-2">💡 Dica</h4>
          <p className="text-sm text-blue-700">
            Defina orçamentos para suas principais categorias de gastos. Você receberá alertas quando estiver próximo do limite.
          </p>
        </div>
      </div>

      {/* Budget Form Modal */}
      <AnimatePresence>
        {(showForm || editingBudget) && (
          <BudgetForm
            initialData={editingBudget}
            existingCategories={existingCategories}
            onSubmit={(data) => {
              if (editingBudget) {
                updateBudget.mutate({ id: editingBudget.id, data });
              } else {
                createBudget.mutate(data);
              }
            }}
            onClose={() => {
              setShowForm(false);
              setEditingBudget(null);
            }}
          />
        )}
      </AnimatePresence>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir orçamento?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação não pode ser desfeita. O orçamento será permanentemente removido.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteBudget.mutate(deleteConfirm.id)}
              className="bg-red-600 hover:bg-red-700"
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}