import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { format, startOfMonth, endOfMonth, subMonths } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Bell, ChevronRight, Sparkles, Receipt, TrendingUp, MessageCircle, FileText, Wallet, BarChart3 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

import BalanceCard from '@/components/ui/BalanceCard';
import TransactionItem from '@/components/ui/TransactionItem';
import InsightCard from '@/components/ui/InsightCard';
import QuickAddButton from '@/components/ui/QuickAddButton';
import QuickActions from '@/components/ui/QuickActions';
import EmptyState from '@/components/ui/EmptyState';
import TransactionForm from '@/components/forms/TransactionForm';
import PremiumBadge from '@/components/ui/PremiumBadge';
import WelcomeTour from '@/components/onboarding/WelcomeTour';
import SuccessFeedback from '@/components/ui/SuccessFeedback';
import Tooltip from '@/components/ui/Tooltip';
import PullToRefresh from '@/components/ui/PullToRefresh';
import { BalanceCardSkeleton, TransactionItemSkeleton } from '@/components/ui/LoadingSkeleton';
import { haptics } from '@/components/utils/haptics';

export default function Home() {
  const [user, setUser] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [formInitialType, setFormInitialType] = useState('expense');
  const [showTour, setShowTour] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
      
      // Check if user is new (show tour)
      const hasSeenTour = localStorage.getItem('hasSeenTour');
      if (!hasSeenTour) {
        setShowTour(true);
      }
    };
    loadUser();
  }, []);

  const handleCompleteTour = () => {
    localStorage.setItem('hasSeenTour', 'true');
    setShowTour(false);
  };

  const currentMonth = new Date();
  const startDate = format(startOfMonth(currentMonth), 'yyyy-MM-dd');
  const endDate = format(endOfMonth(currentMonth), 'yyyy-MM-dd');

  const { data: transactions = [], isLoading: loadingTransactions, refetch: refetchTransactions } = useQuery({
    queryKey: ['transactions', startDate, endDate],
    queryFn: () => base44.entities.Transaction.filter({
      date: { $gte: startDate, $lte: endDate }
    }, '-date', 100),
  });

  const { data: insights = [], refetch: refetchInsights } = useQuery({
    queryKey: ['insights'],
    queryFn: () => base44.entities.FinancialInsight.filter({ is_read: false }, '-created_date', 3),
  });

  const { data: bankAccounts = [] } = useQuery({
    queryKey: ['bankAccounts'],
    queryFn: () => base44.entities.BankAccount.filter({ is_active: true }, '-created_date', 10),
  });

  const { data: cards = [] } = useQuery({
    queryKey: ['cards'],
    queryFn: () => base44.entities.Card.list('-created_date', 50),
  });

  const handleRefresh = async () => {
    haptics.light();
    await Promise.all([refetchTransactions(), refetchInsights()]);
    haptics.success();
  };

  // Calculate card expenses
  const getCardExpenses = (cardId) => {
    return transactions
      .filter(t => t.type === 'expense' && t.card_id === cardId)
      .reduce((sum, t) => sum + (t.amount || 0), 0);
  };

  // Calculate account balances
  const getAccountBalance = (accountId) => {
    const account = bankAccounts.find(a => a.id === accountId);
    if (!account) return 0;

    const accountTransactions = transactions.filter(t => t.bank_account_id === accountId);
    const transactionTotal = accountTransactions.reduce((sum, t) => {
      return sum + (t.type === 'income' ? t.amount : -t.amount);
    }, 0);

    // Subtract card expenses from this account
    const accountCards = cards.filter(c => c.bank_account_id === accountId);
    const cardExpenses = accountCards.reduce((sum, card) => {
      return sum + getCardExpenses(card.id);
    }, 0);

    return (account.initial_balance || 0) + transactionTotal - cardExpenses;
  };

  const totalAccountsBalance = bankAccounts.reduce((sum, acc) => sum + getAccountBalance(acc.id), 0);

  const createTransaction = useMutation({
    mutationFn: (data) => base44.entities.Transaction.create(data),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      setShowForm(false);
      setSuccessMessage(
        variables.type === 'income' 
          ? '✅ Receita adicionada com sucesso!' 
          : '✅ Despesa registrada!'
      );
      setShowSuccess(true);
      haptics.success();
    },
  });

  const dismissInsight = useMutation({
    mutationFn: (id) => base44.entities.FinancialInsight.update(id, { is_read: true }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['insights'] });
    },
  });

  // Calculate totals
  const totals = transactions.reduce(
    (acc, t) => {
      if (t.type === 'income') {
        acc.income += t.amount || 0;
      } else {
        acc.expenses += t.amount || 0;
      }
      return acc;
    },
    { income: 0, expenses: 0 }
  );
  const balance = totals.income - totals.expenses;

  const recentTransactions = transactions.slice(0, 5);

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value || 0);
  };

  return (
    <PullToRefresh onRefresh={handleRefresh}>
      <div className="min-h-screen bg-slate-50 pb-32">
        {/* Header */}
        <motion.div 
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="bg-white px-6 pt-6 pb-4 sticky top-0 z-20 shadow-sm backdrop-blur-lg bg-white/95"
        >
        <div className="flex items-center justify-between mb-4">
          <motion.div
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.1, duration: 0.5 }}
          >
            <p className="text-slate-500 text-sm">Olá,</p>
            <h1 className="text-xl font-bold text-slate-800">
              {user?.full_name?.split(' ')[0] || 'Bem-vindo'}
            </h1>
          </motion.div>
          <motion.div 
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.1, duration: 0.5 }}
            className="flex items-center gap-3"
          >
            {user?.plan === 'premium' && <PremiumBadge />}
            <Link
              to={createPageUrl('Notifications')}
              className="relative p-2 rounded-full bg-slate-100 hover:bg-slate-200 transition-all active:scale-95"
            >
              <Bell className="h-5 w-5 text-slate-600" />
              {insights.length > 0 && (
                <motion.span 
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute top-0 right-0 h-2 w-2 bg-red-500 rounded-full"
                />
              )}
            </Link>
          </motion.div>
        </div>

        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="text-sm text-slate-500"
        >
          {format(currentMonth, "MMMM 'de' yyyy", { locale: ptBR })}
        </motion.p>
      </motion.div>

      {/* Balance Card */}
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.6, ease: "easeOut" }}
        className="px-6 mt-4 max-w-lg mx-auto"
      >
        {loadingTransactions ? (
          <BalanceCardSkeleton />
        ) : (
          <Tooltip content="Seu saldo do mês atual" position="bottom">
            <BalanceCard
              balance={balance}
              income={totals.income}
              expenses={totals.expenses}
            />
          </Tooltip>
        )}
      </motion.div>

      {/* Quick Actions */}
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4, duration: 0.6 }}
        className="px-6 mt-5"
      >
        <h2 className="text-sm font-semibold text-slate-400 uppercase tracking-wide mb-3">
          Ações Rápidas
        </h2>
        <QuickActions
          onAddIncome={() => {
            setFormInitialType('income');
            setShowForm(true);
          }}
          onAddExpense={() => {
            setFormInitialType('expense');
            setShowForm(true);
          }}
          onAddRecurring={() => {
            setFormInitialType('expense');
            setShowForm(true);
          }}
        />
      </motion.div>

      {/* Bank Accounts Summary */}
      {bankAccounts.length > 0 && (
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="px-6 mt-5"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-800">Saldo em Contas</h3>
            <Link to={createPageUrl('Wallet')} className="text-xs text-emerald-600 font-medium hover:text-emerald-700 transition-colors">
              Ver todas
            </Link>
          </div>
          <motion.div 
            whileHover={{ scale: 1.01 }}
            className="bg-gradient-to-br from-white to-slate-50 rounded-2xl p-4 border border-slate-100 mb-3 shadow-sm"
          >
            <p className="text-xs text-slate-500 mb-1 font-medium">Total em Contas</p>
            <p className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
              {formatCurrency(totalAccountsBalance)}
            </p>
          </motion.div>
          <div className="space-y-2">
            {bankAccounts.slice(0, 3).map((account, idx) => (
              <Link key={account.id} to={createPageUrl('Wallet')}>
                <motion.div
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.6 + (idx * 0.1) }}
                  whileHover={{ scale: 1.02, x: 4 }}
                  whileTap={{ scale: 0.98 }}
                  className="bg-white rounded-xl p-3 border border-slate-100 flex items-center justify-between hover:shadow-md transition-all"
                >
                  <div>
                    <p className="text-sm font-medium text-slate-800">{account.name}</p>
                    <p className="text-xs text-slate-500 capitalize">
                      {account.account_type === 'checking' ? 'Conta Corrente' : 
                       account.account_type === 'savings' ? 'Poupança' : 'Investimento'}
                    </p>
                  </div>
                  <p className="font-semibold text-slate-800">{formatCurrency(getAccountBalance(account.id))}</p>
                </motion.div>
              </Link>
            ))}
          </div>
        </motion.div>
      )}

      {/* AI Insights */}
      <AnimatePresence>
        {insights.length > 0 && (
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -20, opacity: 0 }}
            transition={{ delay: 0.6, duration: 0.6 }}
            className="px-6 mt-5"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <motion.div
                  animate={{ rotate: [0, 10, -10, 0] }}
                  transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
                >
                  <Sparkles className="h-5 w-5 text-amber-500" />
                </motion.div>
                <h2 className="font-semibold text-slate-800">Insights da IA</h2>
              </div>
              <Link
                to={createPageUrl('Insights')}
                className="text-sm text-emerald-600 font-medium flex items-center gap-1 hover:gap-2 transition-all"
              >
                Ver todos
                <ChevronRight className="h-4 w-4" />
              </Link>
            </div>
            <div className="space-y-3">
              {insights.map((insight, idx) => (
                <motion.div
                  key={insight.id}
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.7 + (idx * 0.1) }}
                >
                  <InsightCard
                    insight={insight}
                    onDismiss={() => dismissInsight.mutate(insight.id)}
                  />
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Quick Links */}
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.7, duration: 0.6 }}
        className="px-6 mt-5"
      >
        <h2 className="text-sm font-semibold text-slate-400 uppercase tracking-wide mb-3">
          Acesso Rápido
        </h2>
        <div className="grid grid-cols-2 gap-2.5">
          {[
            { to: 'Budgets', icon: Wallet, color: 'violet', label: 'Orçamentos', desc: 'Gerencie seus limites' },
            { to: 'Analytics', icon: BarChart3, color: 'blue', label: 'Análises', desc: 'Visualize relatórios' },
            { to: 'FinancialChat', icon: MessageCircle, color: 'emerald', label: 'Concierge IA', desc: 'Chat financeiro' },
            { to: 'Projections', icon: TrendingUp, color: 'amber', label: 'Projeções', desc: 'Planeje o futuro' }
          ].map((item, idx) => (
            <Link key={item.to} to={createPageUrl(item.to)}>
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.8 + (idx * 0.1) }}
                whileHover={{ scale: 1.03, y: -4 }}
                whileTap={{ scale: 0.97 }}
                className="bg-white p-3 rounded-2xl border border-slate-100 hover:shadow-lg hover:border-slate-200 transition-all"
              >
                <motion.div 
                  whileHover={{ rotate: 5, scale: 1.1 }}
                  className={`h-9 w-9 rounded-xl bg-${item.color}-100 flex items-center justify-center mb-2`}
                >
                  <item.icon className={`h-4 w-4 text-${item.color}-600`} />
                </motion.div>
                <p className="font-medium text-slate-800 text-sm">{item.label}</p>
                <p className="text-[11px] text-slate-500 mt-0.5">{item.desc}</p>
              </motion.div>
            </Link>
          ))}
        </div>
      </motion.div>

      {/* Recent Transactions */}
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.8, duration: 0.6 }}
        className="px-6 mt-5 mb-6"
      >
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-slate-800">Últimas Transações</h2>
          <Link
            to={createPageUrl('Transactions')}
            className="text-sm text-emerald-600 font-medium flex items-center gap-1 hover:gap-2 transition-all"
          >
            Ver todas
            <ChevronRight className="h-4 w-4" />
          </Link>
        </div>

        {loadingTransactions ? (
          <div className="space-y-2">
            {[1, 2, 3].map((i) => (
              <TransactionItemSkeleton key={i} />
            ))}
          </div>
        ) : recentTransactions.length === 0 ? (
          <EmptyState
            icon={Receipt}
            title="Nenhuma transação"
            description="Comece adicionando sua primeira receita ou despesa"
            actionLabel="Adicionar transação"
            onAction={() => setShowForm(true)}
          />
        ) : (
          <div className="space-y-2">
            {recentTransactions.map((transaction, idx) => (
              <motion.div
                key={transaction.id}
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.9 + (idx * 0.1) }}
              >
                <TransactionItem
                  transaction={transaction}
                  onClick={() => {}}
                />
              </motion.div>
            ))}
          </div>
        )}
      </motion.div>

      {/* Quick Add Button */}
      <QuickAddButton onClick={() => {
        setFormInitialType('expense');
        setShowForm(true);
      }} />

      {/* Transaction Form Modal */}
      <AnimatePresence>
        {showForm && (
          <TransactionForm
            initialData={{ type: formInitialType }}
            onSubmit={(data) => createTransaction.mutate(data)}
            onClose={() => setShowForm(false)}
          />
        )}
      </AnimatePresence>

      {/* Welcome Tour */}
      <AnimatePresence>
        {showTour && <WelcomeTour onComplete={handleCompleteTour} />}
      </AnimatePresence>

      {/* Success Feedback */}
      <SuccessFeedback
        isVisible={showSuccess}
        message={successMessage}
        onClose={() => setShowSuccess(false)}
        showConfetti={true}
      />
      </div>
    </PullToRefresh>
  );
}