import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { 
  Crown, 
  Sparkles, 
  FileText, 
  Bell, 
  CheckCircle2,
  MessageCircle,
  TrendingUp,
  Target
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const features = [
  {
    icon: Sparkles,
    title: 'Análise Avançada com IA',
    description: 'Detecção de gastos incomuns, otimização de orçamento e insights proativos',
  },
  {
    icon: FileText,
    title: 'Relatórios Personalizados',
    description: 'PDFs com filtros avançados, gráficos e análises profissionais',
  },
  {
    icon: TrendingUp,
    title: 'Projeções Financeiras',
    description: 'Veja onde estará nos próximos 6 meses com base nos seus hábitos',
  },
  {
    icon: MessageCircle,
    title: 'Concierge Financeiro IA',
    description: 'Chat inteligente para tirar dúvidas e receber orientações 24/7',
  },
  {
    icon: Target,
    title: 'Metas Avançadas',
    description: 'Acompanhamento visual de economia e investimentos',
  },
  {
    icon: Bell,
    title: 'Alertas Inteligentes',
    description: 'Notificações proativas de gastos incomuns e riscos',
  },
];

const plans = [
  {
    id: 'monthly',
    name: 'Mensal',
    price: 19.90,
    period: 'mês',
    popular: false,
  },
  {
    id: 'yearly',
    name: 'Anual',
    price: 9.90,
    period: 'mês',
    totalPrice: 118.80,
    savings: '50%',
    popular: true,
  },
];

export default function Premium() {
  const [user, setUser] = useState(null);
  const [selectedPlan, setSelectedPlan] = useState('yearly');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  const isPremium = user?.plan === 'premium';

  if (isPremium) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white p-8 rounded-3xl shadow-lg text-center max-w-md"
        >
          <div className="h-16 w-16 rounded-2xl bg-gradient-to-r from-amber-400 to-orange-500 flex items-center justify-center mx-auto mb-4">
            <Crown className="h-8 w-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Você é Premium!</h2>
          <p className="text-slate-500 mb-6">
            Aproveite todos os recursos exclusivos do plano premium.
          </p>
          <div className="bg-emerald-50 p-4 rounded-xl">
            <CheckCircle2 className="h-6 w-6 text-emerald-500 mx-auto mb-2" />
            <p className="text-sm text-emerald-700">
              Seu plano está ativo
            </p>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-32">
      {/* Hero */}
      <div className="bg-gradient-to-br from-emerald-600 via-teal-600 to-cyan-700 px-6 pt-12 pb-16 text-white text-center relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yLjIwOS0xLjc5MS00LTQtNHMtNCAxLjc5MS00IDQgMS43OTEgNCA0IDQgNC0xLjc5MSA0LTR6bTAtMTBjMC0yLjIwOS0xLjc5MS00LTQtNHMtNCAxLjc5MS00IDQgMS43OTEgNCA0IDQgNC0xLjc5MSA0LTR6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-10" />
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative z-10"
        >
          <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full mb-4">
            <Crown className="h-5 w-5 text-amber-300" />
            <span className="font-semibold">Premium</span>
          </div>
          
          <h1 className="text-3xl font-bold mb-3">
            Controle Total das Suas Finanças
          </h1>
          
          <p className="text-white/80 max-w-md mx-auto">
            Desbloqueie o poder da inteligência artificial para transformar sua vida financeira
          </p>
        </motion.div>
      </div>

      {/* Plans */}
      <div className="px-6 -mt-8 relative z-10">
        <div className="grid grid-cols-2 gap-3">
          {plans.map((plan) => (
            <motion.button
              key={plan.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              onClick={() => setSelectedPlan(plan.id)}
              className={cn(
                "relative p-4 rounded-2xl border-2 transition-all text-left",
                selectedPlan === plan.id
                  ? "border-emerald-500 bg-emerald-50"
                  : "border-slate-200 bg-white hover:border-slate-300"
              )}
            >
              {plan.popular && (
                <span className="absolute -top-2 right-2 bg-gradient-to-r from-amber-400 to-orange-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                  POPULAR
                </span>
              )}
              
              <p className="font-semibold text-slate-800">{plan.name}</p>
              <div className="mt-2">
                <span className="text-2xl font-bold text-slate-800">
                  R$ {plan.price.toFixed(2).replace('.', ',')}
                </span>
                <span className="text-slate-500 text-sm">/{plan.period}</span>
              </div>
              
              {plan.savings && (
                <span className="inline-block mt-2 text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                  Economize {plan.savings}
                </span>
              )}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Features */}
      <div className="px-6 mt-8">
        <h2 className="text-lg font-bold text-slate-800 mb-4">
          O que está incluso
        </h2>
        
        <div className="space-y-3">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-start gap-4 p-4 bg-white rounded-2xl border border-slate-100"
            >
              <div className="h-10 w-10 rounded-xl bg-emerald-100 flex items-center justify-center flex-shrink-0">
                <feature.icon className="h-5 w-5 text-emerald-600" />
              </div>
              <div>
                <h3 className="font-semibold text-slate-800">{feature.title}</h3>
                <p className="text-sm text-slate-500">{feature.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-100 p-6 z-30">
        <Link to={createPageUrl('Checkout')}>
          <Button className="w-full h-14 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 rounded-2xl text-lg font-semibold">
            <Crown className="h-5 w-5 mr-2" />
            Assinar Premium
          </Button>
        </Link>
        <p className="text-center text-xs text-slate-400 mt-2">
          Pagamento via PIX • Ativação em até 24 horas
        </p>
      </div>
    </div>
  );
}