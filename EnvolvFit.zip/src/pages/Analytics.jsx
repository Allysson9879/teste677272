import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { format, startOfMonth, endOfMonth, subMonths, startOfYear, endOfYear } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  PieChart,
  BarChart3,
  Sparkles,
  Lock,
  Calendar,
  Download,
  LineChart as LineChartIcon,
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

import AdvancedCategoryChart from '@/components/charts/AdvancedCategoryChart';
import MonthlyComparisonChart from '@/components/charts/MonthlyComparisonChart';
import TrendChart from '@/components/charts/TrendChart';
import CategoryTrendChart from '@/components/charts/CategoryTrendChart';
import BudgetProgress from '@/components/ui/BudgetProgress';
import PremiumBadge from '@/components/ui/PremiumBadge';
import { getCategoryLabel } from '@/components/ui/CategoryIcon';

export default function Analytics() {
  const [user, setUser] = useState(null);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState('monthly'); // 'monthly' or 'yearly'
  const [compareMode, setCompareMode] = useState('none'); // 'none', 'previous', 'year'

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  const isPremium = user?.plan === 'premium';

  // Date range calculations
  const getDateRange = () => {
    if (viewMode === 'yearly') {
      return {
        start: format(startOfYear(currentDate), 'yyyy-MM-dd'),
        end: format(endOfYear(currentDate), 'yyyy-MM-dd'),
      };
    }
    return {
      start: format(startOfMonth(currentDate), 'yyyy-MM-dd'),
      end: format(endOfMonth(currentDate), 'yyyy-MM-dd'),
    };
  };

  const { start: startDate, end: endDate } = getDateRange();
  const currentPeriod = viewMode === 'yearly' 
    ? format(currentDate, 'yyyy')
    : format(currentDate, 'yyyy-MM');

  // Fetch current period data
  const { data: transactions = [] } = useQuery({
    queryKey: ['transactions', startDate, endDate],
    queryFn: () => base44.entities.Transaction.filter({
      date: { $gte: startDate, $lte: endDate }
    }, '-date', 1000),
  });

  const { data: budgets = [] } = useQuery({
    queryKey: ['budgets', currentPeriod],
    queryFn: () => base44.entities.Budget.filter({ month: currentPeriod }),
    enabled: viewMode === 'monthly',
  });

  // Fetch comparison period data
  const { data: comparisonTransactions = [] } = useQuery({
    queryKey: ['comparison-transactions', compareMode, currentDate],
    queryFn: async () => {
      if (compareMode === 'none') return [];
      
      let compStart, compEnd;
      if (compareMode === 'previous') {
        if (viewMode === 'yearly') {
          const prevYear = new Date(currentDate.getFullYear() - 1, 0, 1);
          compStart = format(startOfYear(prevYear), 'yyyy-MM-dd');
          compEnd = format(endOfYear(prevYear), 'yyyy-MM-dd');
        } else {
          const prevMonth = subMonths(currentDate, 1);
          compStart = format(startOfMonth(prevMonth), 'yyyy-MM-dd');
          compEnd = format(endOfMonth(prevMonth), 'yyyy-MM-dd');
        }
      } else if (compareMode === 'year') {
        const lastYear = new Date(currentDate.getFullYear() - 1, currentDate.getMonth(), 1);
        compStart = format(startOfMonth(lastYear), 'yyyy-MM-dd');
        compEnd = format(endOfMonth(lastYear), 'yyyy-MM-dd');
      }
      
      return base44.entities.Transaction.filter({
        date: { $gte: compStart, $lte: compEnd }
      }, '-date', 1000);
    },
    enabled: compareMode !== 'none',
  });

  // Fetch trend data (last 12 months or years)
  const { data: trendData = [] } = useQuery({
    queryKey: ['trend-data', viewMode],
    queryFn: async () => {
      const periods = viewMode === 'yearly' ? 5 : 12;
      const allData = [];
      
      for (let i = periods - 1; i >= 0; i--) {
        const date = viewMode === 'yearly'
          ? new Date(currentDate.getFullYear() - i, 0, 1)
          : subMonths(new Date(), i);
        
        const periodStart = viewMode === 'yearly'
          ? format(startOfYear(date), 'yyyy-MM-dd')
          : format(startOfMonth(date), 'yyyy-MM-dd');
        
        const periodEnd = viewMode === 'yearly'
          ? format(endOfYear(date), 'yyyy-MM-dd')
          : format(endOfMonth(date), 'yyyy-MM-dd');

        const data = await base44.entities.Transaction.filter({
          date: { $gte: periodStart, $lte: periodEnd }
        }, '-date', 1000);

        const income = data.filter(t => t.type === 'income').reduce((sum, t) => sum + (t.amount || 0), 0);
        const expense = data.filter(t => t.type === 'expense').reduce((sum, t) => sum + (t.amount || 0), 0);

        allData.push({
          period: viewMode === 'yearly' ? format(date, 'yyyy') : format(date, 'MMM/yy', { locale: ptBR }),
          income,
          expense,
          balance: income - expense,
        });
      }
      
      return allData;
    },
  });

  // Category trend data
  const { data: categoryTrendData = [] } = useQuery({
    queryKey: ['category-trend', viewMode],
    queryFn: async () => {
      const periods = viewMode === 'yearly' ? 3 : 6;
      const allData = [];
      
      for (let i = periods - 1; i >= 0; i--) {
        const date = viewMode === 'yearly'
          ? new Date(currentDate.getFullYear() - i, 0, 1)
          : subMonths(new Date(), i);
        
        const periodStart = viewMode === 'yearly'
          ? format(startOfYear(date), 'yyyy-MM-dd')
          : format(startOfMonth(date), 'yyyy-MM-dd');
        
        const periodEnd = viewMode === 'yearly'
          ? format(endOfYear(date), 'yyyy-MM-dd')
          : format(endOfMonth(date), 'yyyy-MM-dd');

        const data = await base44.entities.Transaction.filter({
          date: { $gte: periodStart, $lte: periodEnd },
          type: 'expense'
        }, '-date', 1000);

        const categoryData = {
          period: viewMode === 'yearly' ? format(date, 'yyyy') : format(date, 'MMM', { locale: ptBR }),
        };

        data.forEach(t => {
          categoryData[t.category] = (categoryData[t.category] || 0) + (t.amount || 0);
        });

        allData.push(categoryData);
      }
      
      return allData;
    },
  });

  const navigatePeriod = (direction) => {
    if (viewMode === 'yearly') {
      setCurrentDate(new Date(currentDate.getFullYear() + (direction === 'prev' ? -1 : 1), 0, 1));
    } else {
      setCurrentDate(direction === 'prev' 
        ? subMonths(currentDate, 1) 
        : subMonths(currentDate, -1)
      );
    }
  };

  // Calculate totals
  const calculateTotals = (txns) => {
    return txns.reduce(
      (acc, t) => {
        if (t.type === 'income') {
          acc.income += t.amount || 0;
        } else {
          acc.expenses += t.amount || 0;
        }
        return acc;
      },
      { income: 0, expenses: 0 }
    );
  };

  const totals = calculateTotals(transactions);
  const comparisonTotals = compareMode !== 'none' ? calculateTotals(comparisonTransactions) : null;

  // Category totals
  const categoryTotals = transactions
    .filter(t => t.type === 'expense')
    .reduce((acc, t) => {
      acc[t.category] = (acc[t.category] || 0) + (t.amount || 0);
      return acc;
    }, {});

  const topCategories = Object.entries(categoryTotals)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5);

  // Get top expense categories for trend chart
  const topCategoriesForTrend = Object.keys(categoryTotals)
    .sort((a, b) => categoryTotals[b] - categoryTotals[a])
    .slice(0, 5);

  // Metrics
  const savingsRate = totals.income > 0 ? ((totals.income - totals.expenses) / totals.income) * 100 : 0;
  const balance = totals.income - totals.expenses;

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value || 0);
  };

  const getComparisonLabel = () => {
    if (compareMode === 'previous') {
      return viewMode === 'yearly' ? 'Ano Anterior' : 'Mês Anterior';
    }
    return 'Mesmo Período Ano Passado';
  };

  const calculatePercentChange = (current, previous) => {
    if (previous === 0) return 0;
    return ((current - previous) / previous) * 100;
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-32">
      {/* Header */}
      <div className="bg-white px-6 pt-6 pb-4 sticky top-0 z-20 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-bold text-slate-800">Análises Financeiras</h1>
          {isPremium && <PremiumBadge />}
        </div>

        {/* View Mode & Period Selector */}
        <div className="flex items-center gap-3 mb-3">
          <Select value={viewMode} onValueChange={setViewMode}>
            <SelectTrigger className="w-32 h-9 rounded-xl text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="monthly">Mensal</SelectItem>
              <SelectItem value="yearly">Anual</SelectItem>
            </SelectContent>
          </Select>

          <div className="flex items-center justify-between flex-1 bg-slate-100 rounded-xl px-2">
            <button
              onClick={() => navigatePeriod('prev')}
              className="p-2 rounded-lg hover:bg-white transition-colors"
            >
              <ChevronLeft className="h-4 w-4 text-slate-600" />
            </button>
            <h2 className="text-sm font-semibold text-slate-800 capitalize">
              {viewMode === 'yearly' 
                ? format(currentDate, 'yyyy')
                : format(currentDate, "MMM 'de' yyyy", { locale: ptBR })
              }
            </h2>
            <button
              onClick={() => navigatePeriod('next')}
              className="p-2 rounded-lg hover:bg-white transition-colors"
            >
              <ChevronRight className="h-4 w-4 text-slate-600" />
            </button>
          </div>
        </div>

        {/* Comparison Mode */}
        <Select value={compareMode} onValueChange={setCompareMode}>
          <SelectTrigger className="w-full h-9 rounded-xl text-sm">
            <SelectValue placeholder="Comparar com..." />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">Sem Comparação</SelectItem>
            <SelectItem value="previous">
              {viewMode === 'yearly' ? 'Ano Anterior' : 'Mês Anterior'}
            </SelectItem>
            <SelectItem value="year">Mesmo Período Ano Passado</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Summary Cards */}
      <div className="px-6 mt-4 space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-gradient-to-br from-emerald-500 to-teal-600 p-4 rounded-2xl text-white">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="h-5 w-5" />
              <span className="text-xs opacity-80">Receitas</span>
            </div>
            <p className="text-2xl font-bold mb-1">{formatCurrency(totals.income)}</p>
            {comparisonTotals && (
              <div className="flex items-center gap-1 text-xs">
                <span className="opacity-80">{getComparisonLabel()}:</span>
                <span className="font-semibold">
                  {calculatePercentChange(totals.income, comparisonTotals.income) > 0 ? '+' : ''}
                  {calculatePercentChange(totals.income, comparisonTotals.income).toFixed(1)}%
                </span>
              </div>
            )}
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }} className="bg-gradient-to-br from-red-500 to-rose-600 p-4 rounded-2xl text-white">
            <div className="flex items-center gap-2 mb-2">
              <TrendingDown className="h-5 w-5" />
              <span className="text-xs opacity-80">Despesas</span>
            </div>
            <p className="text-2xl font-bold mb-1">{formatCurrency(totals.expenses)}</p>
            {comparisonTotals && (
              <div className="flex items-center gap-1 text-xs">
                <span className="opacity-80">{getComparisonLabel()}:</span>
                <span className="font-semibold">
                  {calculatePercentChange(totals.expenses, comparisonTotals.expenses) > 0 ? '+' : ''}
                  {calculatePercentChange(totals.expenses, comparisonTotals.expenses).toFixed(1)}%
                </span>
              </div>
            )}
          </motion.div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white p-4 rounded-xl border border-slate-100">
            <p className="text-xs text-slate-500 mb-1">Saldo do Período</p>
            <p className={`text-2xl font-bold ${balance >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
              {formatCurrency(balance)}
            </p>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="bg-white p-4 rounded-xl border border-slate-100">
            <p className="text-xs text-slate-500 mb-1">Taxa de Poupança</p>
            <p className={`text-2xl font-bold ${savingsRate >= 20 ? 'text-emerald-600' : savingsRate >= 10 ? 'text-amber-600' : 'text-red-600'}`}>
              {savingsRate.toFixed(0)}%
            </p>
          </motion.div>
        </div>
      </div>

      {/* Trend Chart */}
      {trendData.length > 0 && (
        <div className="px-6 mt-6">
          <div className="bg-white p-4 rounded-2xl border border-slate-100">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-slate-800">Evolução Financeira</h3>
              <LineChartIcon className="h-5 w-5 text-slate-400" />
            </div>
            <TrendChart data={trendData} type="area" />
          </div>
        </div>
      )}

      {/* Charts Tabs */}
      <div className="px-6 mt-6">
        <Tabs defaultValue="categories" className="w-full">
          <TabsList className="w-full bg-slate-100 rounded-xl p-1">
            <TabsTrigger value="categories" className="flex-1 rounded-lg text-xs sm:text-sm">
              <PieChart className="h-4 w-4 mr-1 sm:mr-2" />
              Categorias
            </TabsTrigger>
            <TabsTrigger value="trend" className="flex-1 rounded-lg text-xs sm:text-sm">
              <BarChart3 className="h-4 w-4 mr-1 sm:mr-2" />
              Tendências
            </TabsTrigger>
            <TabsTrigger value="comparison" className="flex-1 rounded-lg text-xs sm:text-sm">
              <Calendar className="h-4 w-4 mr-1 sm:mr-2" />
              Histórico
            </TabsTrigger>
          </TabsList>

          <TabsContent value="categories" className="mt-4">
            <div className="bg-white p-4 rounded-2xl border border-slate-100">
              <h3 className="font-semibold text-slate-800 mb-4">Despesas por Categoria</h3>
              <AdvancedCategoryChart data={Object.entries(categoryTotals).map(([name, value]) => ({ name, value }))} />
            </div>

            {topCategories.length > 0 && (
              <div className="mt-4 bg-white p-4 rounded-2xl border border-slate-100">
                <h3 className="font-semibold text-slate-800 mb-4">Top 5 Categorias</h3>
                <div className="space-y-3">
                  {topCategories.map(([category, amount], index) => {
                    const percentage = (amount / totals.expenses) * 100;
                    return (
                      <div key={category}>
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-3">
                            <span className="text-sm text-slate-400 w-6">#{index + 1}</span>
                            <span className="font-medium text-slate-700">{getCategoryLabel(category)}</span>
                          </div>
                          <div className="text-right">
                            <span className="font-semibold text-slate-800">{formatCurrency(amount)}</span>
                            <span className="text-xs text-slate-500 ml-2">{percentage.toFixed(0)}%</span>
                          </div>
                        </div>
                        <div className="w-full bg-slate-100 rounded-full h-2">
                          <div 
                            className="bg-gradient-to-r from-emerald-500 to-teal-600 h-2 rounded-full transition-all" 
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="trend" className="mt-4">
            {categoryTrendData.length > 0 && topCategoriesForTrend.length > 0 && (
              <div className="bg-white p-4 rounded-2xl border border-slate-100">
                <h3 className="font-semibold text-slate-800 mb-4">
                  Tendência por Categoria
                </h3>
                <CategoryTrendChart data={categoryTrendData} categories={topCategoriesForTrend} />
              </div>
            )}
          </TabsContent>

          <TabsContent value="comparison" className="mt-4">
            <div className="bg-white p-4 rounded-2xl border border-slate-100">
              <h3 className="font-semibold text-slate-800 mb-4">
                {viewMode === 'yearly' ? 'Últimos 5 Anos' : 'Últimos 12 Meses'}
              </h3>
              <MonthlyComparisonChart data={trendData} />
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Budgets - Only for monthly view */}
      {viewMode === 'monthly' && (
        <div className="px-6 mt-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-slate-800">Orçamentos do Mês</h3>
            <Link
              to={createPageUrl('Budgets')}
              className="text-sm text-emerald-600 font-medium"
            >
              Gerenciar
            </Link>
          </div>

          {budgets.length === 0 ? (
            <div className="bg-white p-6 rounded-2xl border border-slate-100 text-center">
              <p className="text-slate-500 mb-3">Nenhum orçamento definido</p>
              <Link to={createPageUrl('Budgets')}>
                <Button size="sm" className="bg-emerald-500 hover:bg-emerald-600">
                  Criar orçamento
                </Button>
              </Link>
            </div>
          ) : (
            <div className="space-y-3">
              {budgets.map((budget) => (
                <BudgetProgress
                  key={budget.id}
                  budget={budget}
                  spent={categoryTotals[budget.category] || 0}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* AI Analysis - Premium Feature */}
      <div className="px-6 mt-6">
        <div className="bg-gradient-to-r from-violet-500 to-purple-600 p-6 rounded-2xl text-white relative overflow-hidden">
          <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-white/10" />
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="h-5 w-5" />
              <span className="font-semibold">Análise com IA</span>
            </div>
            <p className="text-sm opacity-90 mb-4">
              Receba insights personalizados sobre seus hábitos financeiros e dicas para economizar.
            </p>
            {isPremium ? (
              <Link to={createPageUrl('Insights')}>
                <Button className="bg-white text-violet-600 hover:bg-white/90">
                  Ver Insights
                </Button>
              </Link>
            ) : (
              <Link to={createPageUrl('Premium')}>
                <Button className="bg-white text-violet-600 hover:bg-white/90">
                  <Lock className="h-4 w-4 mr-2" />
                  Desbloquear Premium
                </Button>
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}