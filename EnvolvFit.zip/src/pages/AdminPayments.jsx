import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  Clock,
  CheckCircle2,
  XCircle,
  ExternalLink,
  Shield,
  Search,
  Filter,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

export default function AdminPayments() {
  const [user, setUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [confirmAction, setConfirmAction] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  // Only admins can access
  const isAdmin = user?.role === 'admin';

  const { data: allRequests = [], isLoading } = useQuery({
    queryKey: ['payment-requests'],
    queryFn: () => base44.entities.PaymentRequest.list('-created_date', 100),
    enabled: isAdmin,
  });

  const confirmPayment = useMutation({
    mutationFn: async (requestId) => {
      const request = allRequests.find(r => r.id === requestId);
      
      // Update payment request
      await base44.entities.PaymentRequest.update(requestId, {
        status: 'confirmed',
        confirmed_at: new Date().toISOString(),
      });

      // Find user and update to premium
      const users = await base44.asServiceRole.entities.User.filter({
        email: request.user_email
      });

      if (users.length > 0) {
        await base44.asServiceRole.entities.User.update(users[0].id, {
          plan: 'premium',
          plan_expires_at: request.expires_at,
        });
      }

      // TODO: Send confirmation email
      // await base44.integrations.Core.SendEmail({
      //   to: request.user_email,
      //   subject: 'Pagamento Confirmado - Premium Ativado! 🎉',
      //   body: `Olá ${request.user_name}!\n\nSeu pagamento foi confirmado e seu plano Premium está ativo!\n\nAproveite todos os recursos exclusivos.`
      // });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['payment-requests'] });
      setConfirmAction(null);
    },
  });

  const rejectPayment = useMutation({
    mutationFn: async (requestId) => {
      await base44.entities.PaymentRequest.update(requestId, {
        status: 'rejected',
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['payment-requests'] });
      setConfirmAction(null);
    },
  });

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value || 0);
  };

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="bg-white p-8 rounded-3xl shadow-lg text-center max-w-md">
          <Shield className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-slate-800 mb-2">Acesso Restrito</h2>
          <p className="text-slate-500">
            Apenas administradores podem acessar esta página.
          </p>
        </div>
      </div>
    );
  }

  const filteredRequests = allRequests.filter(req => 
    req.user_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    req.user_email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const pendingRequests = filteredRequests.filter(r => r.status === 'pending');
  const confirmedRequests = filteredRequests.filter(r => r.status === 'confirmed');
  const rejectedRequests = filteredRequests.filter(r => r.status === 'rejected');

  const RequestCard = ({ request }) => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white p-4 rounded-2xl border border-slate-100"
    >
      <div className="flex items-start justify-between mb-3">
        <div>
          <p className="font-semibold text-slate-800">{request.user_name}</p>
          <p className="text-sm text-slate-500">{request.user_email}</p>
        </div>
        <Badge className={cn(
          request.status === 'pending' && "bg-amber-100 text-amber-800",
          request.status === 'confirmed' && "bg-emerald-100 text-emerald-800",
          request.status === 'rejected' && "bg-red-100 text-red-800"
        )}>
          {request.status === 'pending' && 'Pendente'}
          {request.status === 'confirmed' && 'Confirmado'}
          {request.status === 'rejected' && 'Rejeitado'}
        </Badge>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-3">
        <div>
          <p className="text-xs text-slate-500">Plano</p>
          <p className="font-medium text-slate-700">
            {request.plan_type === 'monthly' ? 'Mensal' : 'Anual'}
          </p>
        </div>
        <div>
          <p className="text-xs text-slate-500">Valor</p>
          <p className="font-medium text-slate-700">{formatCurrency(request.amount)}</p>
        </div>
        <div>
          <p className="text-xs text-slate-500">Data</p>
          <p className="font-medium text-slate-700">
            {format(new Date(request.created_date), "dd/MM/yyyy", { locale: ptBR })}
          </p>
        </div>
        <div>
          <p className="text-xs text-slate-500">PIX</p>
          <p className="font-medium text-slate-700">{request.pix_key}</p>
        </div>
      </div>

      {request.notes && (
        <div className="bg-slate-50 p-3 rounded-xl mb-3">
          <p className="text-xs text-slate-500 mb-1">Observações</p>
          <p className="text-sm text-slate-700">{request.notes}</p>
        </div>
      )}

      {request.payment_proof && (
        <a
          href={request.payment_proof}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-700 mb-3"
        >
          <ExternalLink className="h-4 w-4" />
          Ver comprovante
        </a>
      )}

      {request.status === 'pending' && (
        <div className="flex gap-2">
          <Button
            onClick={() => setConfirmAction({ type: 'confirm', request })}
            className="flex-1 bg-emerald-500 hover:bg-emerald-600"
          >
            <CheckCircle2 className="h-4 w-4 mr-2" />
            Confirmar
          </Button>
          <Button
            onClick={() => setConfirmAction({ type: 'reject', request })}
            variant="outline"
            className="flex-1 text-red-600 border-red-200 hover:bg-red-50"
          >
            <XCircle className="h-4 w-4 mr-2" />
            Rejeitar
          </Button>
        </div>
      )}

      {request.status === 'confirmed' && request.confirmed_at && (
        <p className="text-xs text-emerald-600">
          Confirmado em {format(new Date(request.confirmed_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
        </p>
      )}
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-slate-50 pb-32">
      {/* Header */}
      <div className="bg-white px-6 pt-6 pb-4 sticky top-0 z-20 shadow-sm">
        <div className="flex items-center gap-2 mb-4">
          <Shield className="h-6 w-6 text-violet-600" />
          <h1 className="text-xl font-bold text-slate-800">Gerenciar Pagamentos</h1>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input
            placeholder="Buscar por nome ou e-mail..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 rounded-xl border-slate-200"
          />
        </div>
      </div>

      {/* Stats */}
      <div className="px-6 mt-4 grid grid-cols-3 gap-3">
        <div className="bg-white p-3 rounded-xl border border-slate-100 text-center">
          <Clock className="h-5 w-5 text-amber-500 mx-auto mb-1" />
          <p className="text-xl font-bold text-slate-800">{pendingRequests.length}</p>
          <p className="text-xs text-slate-500">Pendentes</p>
        </div>
        <div className="bg-white p-3 rounded-xl border border-slate-100 text-center">
          <CheckCircle2 className="h-5 w-5 text-emerald-500 mx-auto mb-1" />
          <p className="text-xl font-bold text-slate-800">{confirmedRequests.length}</p>
          <p className="text-xs text-slate-500">Confirmados</p>
        </div>
        <div className="bg-white p-3 rounded-xl border border-slate-100 text-center">
          <XCircle className="h-5 w-5 text-red-500 mx-auto mb-1" />
          <p className="text-xl font-bold text-slate-800">{rejectedRequests.length}</p>
          <p className="text-xs text-slate-500">Rejeitados</p>
        </div>
      </div>

      {/* Requests List */}
      <div className="px-6 mt-6">
        <Tabs defaultValue="pending" className="w-full">
          <TabsList className="w-full bg-slate-100 rounded-xl p-1">
            <TabsTrigger value="pending" className="flex-1 rounded-lg">
              Pendentes ({pendingRequests.length})
            </TabsTrigger>
            <TabsTrigger value="confirmed" className="flex-1 rounded-lg">
              Confirmados
            </TabsTrigger>
            <TabsTrigger value="rejected" className="flex-1 rounded-lg">
              Rejeitados
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="mt-4">
            {isLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-48 bg-white rounded-2xl animate-pulse" />
                ))}
              </div>
            ) : pendingRequests.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                <Clock className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>Nenhuma solicitação pendente</p>
              </div>
            ) : (
              <div className="space-y-3">
                {pendingRequests.map(request => (
                  <RequestCard key={request.id} request={request} />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="confirmed" className="mt-4">
            {confirmedRequests.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                <CheckCircle2 className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>Nenhum pagamento confirmado ainda</p>
              </div>
            ) : (
              <div className="space-y-3">
                {confirmedRequests.map(request => (
                  <RequestCard key={request.id} request={request} />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="rejected" className="mt-4">
            {rejectedRequests.length === 0 ? (
              <div className="text-center py-12 text-slate-500">
                <XCircle className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>Nenhum pagamento rejeitado</p>
              </div>
            ) : (
              <div className="space-y-3">
                {rejectedRequests.map(request => (
                  <RequestCard key={request.id} request={request} />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Confirmation Dialog */}
      <AlertDialog 
        open={!!confirmAction} 
        onOpenChange={() => setConfirmAction(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {confirmAction?.type === 'confirm' ? 'Confirmar pagamento?' : 'Rejeitar pagamento?'}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {confirmAction?.type === 'confirm' 
                ? 'O usuário receberá acesso Premium imediatamente e será notificado por e-mail.'
                : 'O usuário será notificado sobre a rejeição do pagamento.'}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (confirmAction?.type === 'confirm') {
                  confirmPayment.mutate(confirmAction.request.id);
                } else {
                  rejectPayment.mutate(confirmAction.request.id);
                }
              }}
              className={cn(
                confirmAction?.type === 'confirm' 
                  ? "bg-emerald-600 hover:bg-emerald-700" 
                  : "bg-red-600 hover:bg-red-700"
              )}
            >
              {confirmAction?.type === 'confirm' ? 'Confirmar' : 'Rejeitar'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}