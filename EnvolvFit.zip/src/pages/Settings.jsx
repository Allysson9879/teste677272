import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import {
  User,
  Bell,
  Shield,
  HelpCircle,
  LogOut,
  ChevronRight,
  Crown,
  Moon,
  Mail,
  Target,
  Wallet,
  MessageCircle,
  TrendingUp,
  FileText,
  Link as LinkIcon,
} from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import PremiumBadge from '@/components/ui/PremiumBadge';

export default function Settings() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showGoalsModal, setShowGoalsModal] = useState(false);
  const [goals, setGoals] = useState({
    monthly_income_goal: '',
    savings_goal: '',
  });

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
      setGoals({
        monthly_income_goal: userData.monthly_income_goal?.toString() || '',
        savings_goal: userData.savings_goal?.toString() || '',
      });
      setIsLoading(false);
    };
    loadUser();
  }, []);

  const updateSettings = async (updates) => {
    const updated = { ...user, ...updates };
    await base44.auth.updateMe(updates);
    setUser(updated);
  };

  const handleSaveGoals = async () => {
    await updateSettings({
      monthly_income_goal: parseFloat(goals.monthly_income_goal) || null,
      savings_goal: parseFloat(goals.savings_goal) || null,
    });
    setShowGoalsModal(false);
  };

  const handleLogout = () => {
    base44.auth.logout('/');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-500" />
      </div>
    );
  }

  const isPremium = user?.plan === 'premium';

  return (
    <div className="min-h-screen bg-slate-50 pb-32">
      {/* Header */}
      <div className="bg-white px-6 pt-6 pb-6">
        <h1 className="text-xl font-bold text-slate-800 mb-6">Configurações</h1>

        {/* User Profile */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4"
        >
          <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center text-white text-2xl font-bold">
            {user?.full_name?.[0]?.toUpperCase() || 'U'}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="font-bold text-slate-800 truncate">{user?.full_name || 'Usuário'}</h2>
              {isPremium && <PremiumBadge />}
            </div>
            <p className="text-sm text-slate-500 truncate">{user?.email}</p>
          </div>
        </motion.div>
      </div>

      {/* Premium Card */}
      {!isPremium && (
        <div className="px-6 mt-4">
          <Link to={createPageUrl('Premium')}>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gradient-to-r from-violet-500 to-purple-600 p-5 rounded-2xl text-white flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-white/20 flex items-center justify-center">
                  <Crown className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-semibold">Seja Premium</p>
                  <p className="text-xs opacity-80">Desbloqueie recursos exclusivos</p>
                </div>
              </div>
              <ChevronRight className="h-5 w-5" />
            </motion.div>
          </Link>
        </div>
      )}

      {/* Settings Sections */}
      <div className="px-6 mt-6 space-y-6">
        {/* Premium Features */}
        <div>
          <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wide mb-3">
            Recursos Premium
          </h3>
          <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden divide-y divide-slate-100">
            <Link to={createPageUrl('FinancialChat')} className="w-full flex items-center justify-between p-4 hover:bg-slate-50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-emerald-100 flex items-center justify-center">
                  <MessageCircle className="h-5 w-5 text-emerald-600" />
                </div>
                <div className="text-left">
                  <p className="font-medium text-slate-800">Concierge Financeiro</p>
                  <p className="text-xs text-slate-500">Chat com IA 24/7</p>
                </div>
              </div>
              <ChevronRight className="h-5 w-5 text-slate-400" />
            </Link>

            <Link to={createPageUrl('Projections')} className="w-full flex items-center justify-between p-4 hover:bg-slate-50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-violet-100 flex items-center justify-center">
                  <TrendingUp className="h-5 w-5 text-violet-600" />
                </div>
                <div className="text-left">
                  <p className="font-medium text-slate-800">Projeções Financeiras</p>
                  <p className="text-xs text-slate-500">Planeje os próximos 6 meses</p>
                </div>
              </div>
              <ChevronRight className="h-5 w-5 text-slate-400" />
            </Link>

            <Link to={createPageUrl('Reports')} className="w-full flex items-center justify-between p-4 hover:bg-slate-50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-blue-100 flex items-center justify-center">
                  <FileText className="h-5 w-5 text-blue-600" />
                </div>
                <div className="text-left">
                  <p className="font-medium text-slate-800">Relatórios em PDF</p>
                  <p className="text-xs text-slate-500">Gerar relatórios personalizados</p>
                </div>
              </div>
              <ChevronRight className="h-5 w-5 text-slate-400" />
            </Link>
          </div>
        </div>

        {/* Goals & Bank Integration */}
        <div>
          <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wide mb-3">
            Finanças
          </h3>
          <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden divide-y divide-slate-100">
            <button
              onClick={() => setShowGoalsModal(true)}
              className="w-full flex items-center justify-between p-4 hover:bg-slate-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-amber-100 flex items-center justify-center">
                  <Target className="h-5 w-5 text-amber-600" />
                </div>
                <div className="text-left">
                  <p className="font-medium text-slate-800">Definir metas</p>
                  <p className="text-xs text-slate-500">Receita e economia mensal</p>
                </div>
              </div>
              <ChevronRight className="h-5 w-5 text-slate-400" />
            </button>

            <Link to={createPageUrl('BankIntegration')} className="w-full flex items-center justify-between p-4 hover:bg-slate-50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-emerald-100 flex items-center justify-center">
                  <LinkIcon className="h-5 w-5 text-emerald-600" />
                </div>
                <div className="text-left">
                  <p className="font-medium text-slate-800">Integração Bancária</p>
                  <p className="text-xs text-slate-500">Conectar via Open Finance</p>
                </div>
              </div>
              <ChevronRight className="h-5 w-5 text-slate-400" />
            </Link>
          </div>
        </div>

        {/* Notifications */}
        <div>
          <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wide mb-3">
            Notificações
          </h3>
          <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden divide-y divide-slate-100">
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-blue-100 flex items-center justify-center">
                  <Bell className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <p className="font-medium text-slate-800">Alertas de orçamento</p>
                  <p className="text-xs text-slate-500">Quando atingir limites</p>
                </div>
              </div>
              <Switch
                checked={user?.notifications_enabled !== false}
                onCheckedChange={(checked) => updateSettings({ notifications_enabled: checked })}
              />
            </div>

            <div className="flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-violet-100 flex items-center justify-center">
                  <Mail className="h-5 w-5 text-violet-600" />
                </div>
                <div>
                  <p className="font-medium text-slate-800">Relatório semanal</p>
                  <p className="text-xs text-slate-500">Resumo por e-mail</p>
                </div>
              </div>
              <Switch
                checked={user?.weekly_report_enabled === true}
                onCheckedChange={(checked) => updateSettings({ weekly_report_enabled: checked })}
              />
            </div>
          </div>
        </div>

        {/* Support */}
        <div>
          <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wide mb-3">
            Suporte
          </h3>
          <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden divide-y divide-slate-100">
            <button className="w-full flex items-center justify-between p-4 hover:bg-slate-50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-amber-100 flex items-center justify-center">
                  <HelpCircle className="h-5 w-5 text-amber-600" />
                </div>
                <div className="text-left">
                  <p className="font-medium text-slate-800">Central de ajuda</p>
                  <p className="text-xs text-slate-500">Perguntas frequentes</p>
                </div>
              </div>
              <ChevronRight className="h-5 w-5 text-slate-400" />
            </button>

            <button className="w-full flex items-center justify-between p-4 hover:bg-slate-50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-slate-100 flex items-center justify-center">
                  <Shield className="h-5 w-5 text-slate-600" />
                </div>
                <div className="text-left">
                  <p className="font-medium text-slate-800">Privacidade</p>
                  <p className="text-xs text-slate-500">Termos e políticas</p>
                </div>
              </div>
              <ChevronRight className="h-5 w-5 text-slate-400" />
            </button>
          </div>
        </div>

        {/* Logout */}
        <Button
          onClick={handleLogout}
          variant="outline"
          className="w-full h-14 rounded-2xl text-red-600 border-red-200 hover:bg-red-50 hover:border-red-300"
        >
          <LogOut className="h-5 w-5 mr-2" />
          Sair da conta
        </Button>

        <p className="text-center text-xs text-slate-400">
          Versão 1.0.0
        </p>
      </div>

      {/* Goals Modal */}
      <Dialog open={showGoalsModal} onOpenChange={setShowGoalsModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Target className="h-5 w-5 text-emerald-500" />
              Metas Financeiras
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Meta de receita mensal</Label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">R$</span>
                <Input
                  type="number"
                  placeholder="0,00"
                  value={goals.monthly_income_goal}
                  onChange={(e) => setGoals({ ...goals, monthly_income_goal: e.target.value })}
                  className="pl-12 h-12 rounded-xl"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Meta de economia mensal</Label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">R$</span>
                <Input
                  type="number"
                  placeholder="0,00"
                  value={goals.savings_goal}
                  onChange={(e) => setGoals({ ...goals, savings_goal: e.target.value })}
                  className="pl-12 h-12 rounded-xl"
                />
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button
              onClick={handleSaveGoals}
              className="w-full bg-emerald-500 hover:bg-emerald-600"
            >
              Salvar metas
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}