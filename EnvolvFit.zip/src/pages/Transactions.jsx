import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { format, startOfMonth, endOfMonth, subMonths, addMonths } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import {
  ChevronLeft,
  ChevronRight,
  Filter,
  Search,
  Trash2,
  Edit2,
  MoreVertical,
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

import TransactionItem from '@/components/ui/TransactionItem';
import TransactionForm from '@/components/forms/TransactionForm';
import QuickAddButton from '@/components/ui/QuickAddButton';
import EmptyState from '@/components/ui/EmptyState';
import AdvancedFilters from '@/components/transactions/AdvancedFilters';
import { Receipt } from 'lucide-react';
import { haptics } from '@/components/utils/haptics';

export default function Transactions() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [showForm, setShowForm] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState(null);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 20;
  const [filters, setFilters] = useState({
    type: 'all',
    category: 'all',
    minAmount: '',
    maxAmount: '',
    bankAccount: 'all',
    card: 'all',
  });
  const queryClient = useQueryClient();

  const startDate = format(startOfMonth(currentDate), 'yyyy-MM-dd');
  const endDate = format(endOfMonth(currentDate), 'yyyy-MM-dd');

  const { data: transactions = [], isLoading, refetch: refetchTransactions } = useQuery({
    queryKey: ['transactions', startDate, endDate],
    queryFn: () => base44.entities.Transaction.filter({
      date: { $gte: startDate, $lte: endDate }
    }, '-date', 500),
  });

  const { data: bankAccounts = [] } = useQuery({
    queryKey: ['bankAccounts'],
    queryFn: () => base44.entities.BankAccount.filter({ is_active: true }, '-created_date', 50),
  });

  const { data: cards = [] } = useQuery({
    queryKey: ['cards'],
    queryFn: () => base44.entities.Card.list('-created_date', 50),
  });

  const handleRefresh = async () => {
    haptics.light();
    await refetchTransactions();
    haptics.success();
  };

  const createTransaction = useMutation({
    mutationFn: (data) => base44.entities.Transaction.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      setShowForm(false);
    },
  });

  const updateTransaction = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Transaction.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      setEditingTransaction(null);
    },
  });

  const deleteTransaction = useMutation({
    mutationFn: (id) => base44.entities.Transaction.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      setDeleteConfirm(null);
    },
  });

  const navigateMonth = (direction) => {
    haptics.selection();
    setCurrentDate(direction === 'prev' 
      ? subMonths(currentDate, 1) 
      : addMonths(currentDate, 1)
    );
  };

  const filteredTransactions = transactions.filter((t) => {
    // Type filter
    if (filters.type !== 'all' && t.type !== filters.type) return false;
    
    // Category filter
    if (filters.category !== 'all' && t.category !== filters.category) return false;
    
    // Amount range filter
    if (filters.minAmount && t.amount < parseFloat(filters.minAmount)) return false;
    if (filters.maxAmount && t.amount > parseFloat(filters.maxAmount)) return false;
    
    // Bank account filter
    if (filters.bankAccount !== 'all' && t.bank_account_id !== filters.bankAccount) return false;
    
    // Card filter
    if (filters.card !== 'all' && t.card_id !== filters.card) return false;
    
    // Search query
    if (searchQuery && !t.description?.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    
    return true;
  });

  // Group by date
  const groupedTransactions = filteredTransactions.reduce((groups, transaction) => {
    const date = transaction.date;
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(transaction);
    return groups;
  }, {});

  const sortedDates = Object.keys(groupedTransactions).sort((a, b) => 
    new Date(b) - new Date(a)
  );

  // Pagination
  const totalPages = Math.ceil(sortedDates.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedDates = sortedDates.slice(startIndex, endIndex);

  // Reset page when filters change
  React.useEffect(() => {
    setCurrentPage(1);
  }, [filters, searchQuery, currentDate]);

  return (
    <div className="min-h-screen bg-slate-50 pb-40">
      {/* Header */}
      <div className="bg-white px-6 pt-6 pb-4 sticky top-0 z-20 shadow-sm">
        <h1 className="text-xl font-bold text-slate-800 mb-4">Transações</h1>

        {/* Month Selector */}
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => navigateMonth('prev')}
            className="p-2 rounded-full hover:bg-slate-100 transition-colors"
          >
            <ChevronLeft className="h-5 w-5 text-slate-600" />
          </button>
          <h2 className="text-lg font-semibold text-slate-800 capitalize">
            {format(currentDate, "MMMM 'de' yyyy", { locale: ptBR })}
          </h2>
          <button
            onClick={() => navigateMonth('next')}
            className="p-2 rounded-full hover:bg-slate-100 transition-colors"
          >
            <ChevronRight className="h-5 w-5 text-slate-600" />
          </button>
        </div>

        {/* Search & Filter */}
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <Input
              placeholder="Buscar transações..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 rounded-xl border-slate-200"
            />
          </div>
          <Button 
            variant="outline" 
            size="icon" 
            className="rounded-xl"
            onClick={() => setShowAdvancedFilters(true)}
          >
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Transactions List */}
      <div className="px-6 mt-4">
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="h-20 bg-white rounded-2xl border border-slate-100 animate-pulse" />
            ))}
          </div>
        ) : sortedDates.length === 0 ? (
          <EmptyState
            icon={Receipt}
            title="Nenhuma transação"
            description="Adicione sua primeira transação do mês"
            actionLabel="Adicionar transação"
            onAction={() => setShowForm(true)}
          />
        ) : (
          <>
            <div className="space-y-6">
              {paginatedDates.map((date) => (
                <div key={date}>
                  <h3 className="text-sm font-medium text-slate-500 mb-2 px-1">
                    {format(new Date(date), "EEEE, d 'de' MMMM", { locale: ptBR })}
                  </h3>
                  <div className="space-y-2">
                    {groupedTransactions[date].map((transaction) => (
                      <div key={transaction.id} className="relative group">
                        <TransactionItem
                          transaction={transaction}
                          onClick={() => setEditingTransaction(transaction)}
                        />
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <button className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full opacity-0 group-hover:opacity-100 hover:bg-slate-100 transition-all">
                              <MoreVertical className="h-4 w-4 text-slate-400" />
                            </button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => setEditingTransaction(transaction)}>
                              <Edit2 className="h-4 w-4 mr-2" />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              onClick={() => setDeleteConfirm(transaction)}
                              className="text-red-600"
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Excluir
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-2 mt-8 mb-6">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                  className="rounded-xl"
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                
                <div className="flex items-center gap-1">
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                    <button
                      key={page}
                      onClick={() => setCurrentPage(page)}
                      className={`h-8 w-8 rounded-lg font-medium transition-all ${
                        currentPage === page
                          ? 'bg-emerald-500 text-white'
                          : 'text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      {page}
                    </button>
                  ))}
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                  disabled={currentPage === totalPages}
                  className="rounded-xl"
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Quick Add Button */}
      <QuickAddButton onClick={() => setShowForm(true)} />

      {/* Advanced Filters */}
      <AdvancedFilters
        isOpen={showAdvancedFilters}
        onClose={() => setShowAdvancedFilters(false)}
        filters={filters}
        onFiltersChange={setFilters}
        bankAccounts={bankAccounts}
        cards={cards}
      />

      {/* Transaction Form Modal */}
      <AnimatePresence>
        {(showForm || editingTransaction) && (
          <TransactionForm
            initialData={editingTransaction}
            onSubmit={(data) => {
              if (editingTransaction) {
                updateTransaction.mutate({ id: editingTransaction.id, data });
              } else {
                createTransaction.mutate(data);
              }
            }}
            onClose={() => {
              setShowForm(false);
              setEditingTransaction(null);
            }}
          />
        )}
      </AnimatePresence>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir transação?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação não pode ser desfeita. A transação será permanentemente removida.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteTransaction.mutate(deleteConfirm.id)}
              className="bg-red-600 hover:bg-red-700"
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}